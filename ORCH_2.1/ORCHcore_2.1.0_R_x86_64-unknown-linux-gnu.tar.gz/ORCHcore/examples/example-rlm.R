##
# This example shows how you can convert a simple R code into a 1 mapper job
# and execute it on Hadoop cluster. Note that the only advantage at this case
# is that you deligate computation to another host and if this host has more
# memory/CPU power you can run it on larger datasets.
##

# Linear model in vanilla R.
x <- lm(speed~dist, cars)
print("--- Client lm:")
print(summary(x))
layout(matrix(1:4,2,2))
plot(x)

# Same linear model but configured as map-only job.
# Note that this will take some time due to Hadoop overhead.
kv <- hadoop.run(
    data = cars,
    mapper = function(k, v) {
        x <- lm(speed~dist, v)
        x$call <- format(x$call)
        orch.keyval(0, orch.pack(model=x))
    },
    reducer <- function(k, v) {
        orch.keyvals(k, v)
    },
    config = new("mapred.config",
        job.name = "lm1",
        map.tasks = 1,
        map.split = 0,
        map.input = "data.frame",
        map.output = data.frame(key=0, val=""))
)
x <- orch.unpack(kv$val2)$model
x$terms <- terms(x$terms)
print("--- Mapper lm:")
print(summary(x))
layout(matrix(1:4,2,2))
plot(x)
