##
# Parallel model building and graph generation example. The predicted values 
# and png graphs are written in HDFS, which are then accessed from R.
# The partiioning of data happens in the mapper depending on the values of 
# Petal.Length of iris data set
##
cat('Running groupapply example.', '\n')

dfs <- hdfs.put(iris)
res <- NULL
dfs.res <- hadoop.run(
    dfs,
    mapper = function(key, vals) {
        outkey <- 0
        if (vals$Petal.Length < 2.0)
          outkey <- 1
        else if (vals$Petal.Length < 4.0)
          outkey <- 2
        else
          outkey <- 3
  
        keyval(outkey, vals)
    },
    reducer = function(key, vals) {
        dat <- do.call(rbind.data.frame, vals)
        mod = lm(Petal.Length ~ Sepal.Length+Petal.Width, data=dat)
        fname <- paste("fit-",key,".png",sep="")
        png(fname)
        plot(mod)
        dev.off()
        hdfs.dir <- paste(hdfs.root(), pngdir, as.character(key), sep="/")
        dfs.id <- hdfs.id(hdfs.dir, force=T)
        #remove pre-existing directories
        if(hdfs.exists(dfs.id)) {
          hdfs.rmdir(dfs.id)
        }
        dfs.id <- hdfs.mkdir(dfs.id)
        x <- hdfs.upload(
            filename = fname,
            dfs.name = dfs.id, 
            nosplit = T, 
            overwrite = T, 
            attach = F)
        pred <- predict(mod, dat)
        keyval(NULL, orch.pack(predict=pred, pngfile=x[1]))
    },
    export = orch.export(pngdir="pngfiles"),
    config = new("mapred.config",
        job.name = "groupapply",
        hdfs.access = T)
)

res <- hdfs.get(dfs.res)
finalres = list()
for (i in 1:nrow(res)) {
    finalres[[i]] <- orch.unpack(res[i,])
}
print(finalres)
# create dfs id from the dir paths
y <- hdfs.id(finalres[[1]]$pngfile)
# copy from HDFS to local
z <- hdfs.download(y)
print(z)
