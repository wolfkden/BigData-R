examples <- list.files('examples', pattern='^example-.+.R')
for (t in paste('examples', examples, sep='/')) {
    source(t)
}
