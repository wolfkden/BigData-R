##
#' This as an initial "naive" implementation of linear model out-of-core QR
#' by Dmitry Golovashkin. Runs on Hadoop with multiple mapper and only one
#' reducer to merge all results at the end. Does not contrtol mapper input
#' size, e.g. it can fail if number of rows is not enough (depends on the
#' input number of columns and formula).
##
cat("Runnning linear model example.\n")

dfs.dat <- hdfs.put(iris)
formula <- 'Petal.Width ~ Sepal.Length + Sepal.Width + Petal.Length - 1'

dfs.res <- hadoop.run(
    dfs.dat,
    mapper = function(keys, vals) {
        # To data.frame
        vals <- lapply(vals, as.data.frame)
        df <- data.frame()
        for (val in vals) {
            df <- rbind(df, val)
        }
        
        # Intercept
        formula <- formula(formula)
        if (length(formula) < 3) {
            stop("'formula' must be a formula object with a response and explanatory variables")
        }
        terms <- terms(formula(formula), data=df)
        intercept <- attr(terms, "intercept")
        
        # Extract model frame
        model <- model.frame(formula, data=df)
        y <- as.matrix(x=model[1], ncol=1)
        yy <- t(y) %*% y
        nRows <- nrow(y)
        ySum <- sum(y)
        
        if (intercept == 1) {
            model[1] <- 1
        } else {
            model <- model[-1]
        }
        
        factor <- qr(model)
        q <- qr.Q(qr=factor, complete=FALSE)
        r <- qr.R(qr=factor, complete=FALSE)
        qy <- t(q) %*% y

        # Output result
        keyval(0, orch.pack(
            r = r, 
            qy = qy, 
            yy = yy, 
            nRows = nRows, 
            ySum = ySum))
    },
    reducer = function(key, vals) {
        x <- orch.unpack(vals[[1]])
        r <- x$r
        qy <- x$qy
        yy <- x$yy
        nRows <- x$nRows
        nvals <- length(vals)
        if (nvals > 1) {
            for (i in 2:nvals) {
                x <- orch.unpack(vals[[i]])
                factor <- qr(rbind(x$r, r))
                q <- qr.Q(qr=factor, complete=F)
                r <- qr.R(qr=factor, complete=F)
                qy <- t(q) %*% rbind(x$qy, qy)
                yy <- yy + x$yy
                nRows <- nRows + x$nRows
            }
        }
        keyval(NULL, orch.pack(
            r = r, 
            qy = qy, 
            yy = yy, 
            nRows = nRows))
    },
    export = orch.export(formula),
    config = new("mapred.config",
        job.name = "lmqr",
        map.input = "list",
        map.split = 0,
        map.valkey = FALSE,
        map.output = data.frame(key=0, val=''))
        #reduce.output = data.frame(key=0, val=''))
)

orch.lm.stat <- function(nColumns, tolerance, r, b)
{
    coefficients <- mat.or.vec(nr=nColumns, nc=1)
    rank <- nColumns
    
    for (col in nColumns:1) {
        d <- r[col, col]
        
        if (abs(d) > tolerance) {
            alpha <- b[col] / d
            coefficients[col] = alpha
            
            if (col == 1) {
                break;
            }
            
            colMinusOne <- col - 1
            for (row in 1:colMinusOne) {
                b[row] <- b[row] - alpha * r[row, col]
            }
        } else {
            coefficients[col] <- NA
            rank <- rank - 1
        }
    }
    
    return(list(coefficients=coefficients, rank=rank))
}

res <- hdfs.get(dfs.res)
res <- orch.unpack(res[1,])
fit <- orch.lm.stat(nColumns=3, tolerance=1E-7, r=res$r, b=res$qy)
cat(sprintf("Model rank %d, yy %.10E, nRows %d", fit$rank, res$yy, res$nRows),"\n")
cat('Model coefficients',"\n")
cat(fit$coefficients,"\n")
