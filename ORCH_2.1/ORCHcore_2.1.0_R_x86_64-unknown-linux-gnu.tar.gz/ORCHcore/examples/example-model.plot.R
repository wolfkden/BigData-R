##
# Parallel model building and graph generation example. The predicted values 
# and png graphs are written in HDFS, which are then accessed from R.
##
cat('Running model building and graph example.', '\n')

dfs <- hdfs.put(iris, key='Species')
res <- NULL
dfs.res <- hadoop.run(
    dfs,
    mapper = function(key, vals) {
        keyval(key, vals)
    },
    reducer = function(key, vals) {
        dat <- do.call(rbind.data.frame, vals)
        mod = lm(Petal.Length ~ Sepal.Length+Petal.Width, data=dat)
        fname <- paste("fit-",key,".png",sep="")
        png(fname)
        plot(mod)
        dev.off()
        hdfs.dir <- paste(hdfs.root(), pngdir, as.character(key), sep="/")
        dfs.id <- hdfs.id(hdfs.dir, force=T)
        #remove pre-existing directories
        if(hdfs.exists(dfs.id)) {
          hdfs.rmdir(dfs.id)
        }
        dfs.id <- hdfs.mkdir(dfs.id)
        x <- hdfs.upload(
            filename = fname,
            dfs.name = dfs.id, 
            nosplit = T, 
            overwrite = T, 
            attach = F)
        pred <- predict(mod, dat)
        keyval(NULL, orch.pack(predict=pred, pngfile=x[1]))
    },
    export = orch.export(pngdir="pngfiles"),
    config = new("mapred.config",
        job.name = "model-plot",
        hdfs.access = T)
)

res <- hdfs.get(dfs.res)
finalres = list()
for (i in 1:nrow(res)) {
    finalres[[i]] <- orch.unpack(res[i,])
}
print(finalres)
# create dfs id from the dir paths
y <- hdfs.id(finalres[[1]]$pngfile)
# copy from HDFS to local
z <- hdfs.download(y)
print(z)
