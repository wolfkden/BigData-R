##
# A simple example of how to run mapper in "list" mode with unlimited number of
# records at once. Input dataset - cars. Filter cars with with "dist" > 30 and 
# get mean "dist" for each in the mapper. Reducer just merges all the results 
# together.
##
cat('Running example of data.frame mapper input:','\n')

cars.dfs <- hdfs.put(cars, key='speed')
x <- hadoop.run(
    cars.dfs,
    mapper = function(keys, vals) {
        dist <- 0
        speed <- 0
        n <- 0
        for (i in 1:dim(vals)[1]) {
            x <- vals[i,]
            if (x$dist > 30 && x$speed < 20) {
                dist <- dist + x$dist
                speed <- speed + x$speed
                n <- n + 1
            }
        }
        dist <- dist / n
        speed <- speed / n
        keyval(speed, dist)
    },
    reducer = function(key, vals) {
        X <- 0
        for (x in vals) {
            X <- X + x$dist
        }
        X <- X / length(vals)
        keyval(key, X)
    },
    config = new("mapred.config",
        map.input = "data.frame",
        map.split = 0,
        map.valkey = TRUE,
        map.output = data.frame(speed=0, dist=0))
)
res <- hdfs.get(x)
print(res)
