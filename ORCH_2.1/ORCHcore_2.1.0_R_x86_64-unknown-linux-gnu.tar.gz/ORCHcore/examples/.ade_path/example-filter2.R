##
# A simple example of how to operate with values only. Input dataset - cars.
# Filter cars with with "dist" > 30 and "speed" > 14 in mapper and get mean 
# "speed" and "dist" in reducer. Output is only one vaue pair.
##
cat('Running cars filtering and mean example #2:','\n')

cars.dfs <- hdfs.put(cars)
x <- hadoop.run(
    cars.dfs,
    mapper = function(key, val) {
        if (val$dist > 30 && val$speed > 14) {
            orch.keyval(key, val)
        }
        else {
            (NULL)
        }
    },
    reducer = function(key, vals) {
        speed <- 0
        dist <- 0
        for (x in vals) {
            dist <- dist + x$dist
            speed <- speed + x$speed
        }
        dist <- dist / length(vals)
        speed <- speed / length(vals)
        orch.keyval(key, c(dist, speed))
    }
)
print(hdfs.get(x))
