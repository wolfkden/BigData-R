##
#' Simple example of logistic regression using ORCH framework. Does number of
#' iteration convoluting group centers and forming k-means. Can visualise the
#' results or print each iteration for debugging.
##
cat('Runnning k-means example.\n')

kmeans <- function(
        points, 
        ncenters, 
        iterations = 10, 
        distfun = NULL, 
        plot = F, 
        debug = F)
{
    if (plot) {
        library(ggplot2)
    }
    if(is.null(distfun)) { 
        distfun <- function(a,b) {
            norm(as.matrix(a-b), type = 'F')
        }
    }  
    mapf <- data.frame(key=0, val1=0, val2=0)
    dfs.points <- hdfs.put(points)
    dfs.centers <- hadoop.exec(
        dfs.id = dfs.points,
        mapper = function(k,v) {
            keyval(sample(1:ncenters,1), v)
        },
        reducer = function(k,vv) {
            vv <- sapply(vv, unlist)
            keyval(NULL, c(mean(vv[1,]), mean(vv[2,])))
        },
        export = orch.export(ncenters),
        config = new("mapred.config", 
            job.name = "k-means.1",
            map.output = mapf)
    )
    if (plot) {
        pdf <- rmr:::to.data.frame(do.call(c,values(hdfs.get(points))))
    }
    for (i in 1:iterations) {
        centers <- hdfs.get(dfs.centers)
        if (debug) {
            cat("iteration", i, "\n")
            print(centers)
        }
        if (plot) {
            png(paste(Sys.time(), "png", sep = "."))
            gg <- ggplot(data = pdf, 
                aes(x=val1, y=val2, size = .1, alpha = .1) + 
                geom_point() +
                geom_point(
                    data = centers, 
                    aes(x = val1, y = val2, size = .3, alpha = 1), 
                    color = "red"))
            print(gg)
            dev.off()
        }
        dfs.centers <- hadoop.exec(
            dfs.id = dfs.points,
            mapper =  function(k,v) {
                v <- unlist(v)
                distances <- apply(centers, 1, function(c) distfun(c,v))
                keyval(which.min(distances), v)
            },
            reducer = function(k,vv) {
                vv <- sapply(vv, unlist)
                keyval(NULL, c(mean(vv[1,]), mean(vv[2,])))
            },
            export = orch.export(distfun, ncenters, centers),
            config = new("mapred.config", 
                job.name = paste("k-means.", i, sep=''),
                map.output = mapf)
        )
    }
    centers <- hdfs.get(dfs.centers)
    if (debug) {
        cat("result\n")
        print(centers)
    }
    (centers)
}

# Generate a random points for k-means clustering test.
input <- data.frame(
    x = sapply(1:1000, function(i) 
        rnorm(1, mean = i%%3, sd = 0.1)), 
    y = sapply(1:1000, function(i) 
        rnorm(1, mean = i%%4, sd = 0.1)))

# Run clustering with 12 initial centers.
centers <- kmeans(input, 12, iterations = 5)
print(centers)
