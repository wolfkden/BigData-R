##
# An example of how to load a local file into HDFS. Input dataset - cars.
# Filter cars with with "dist" > 30 and "speed" > 14 in mapper and get mean 
# "speed" and "dist" in reducer. Output is only one vaue pair.
##
cat('Running cars filtering and mean example #3:','\n')

tmpf <- tempfile(tmpdir='/tmp')
write.csv(cars, row.names=F, file=tmpf)
cars.dfs <- hdfs.upload(tmpf, header=T)
x <- hadoop.run(
    cars.dfs,
    mapper = function(key, val) {
        if (val[[1]] > 14 && val[[2]] > 30) {
            orch.keyval(key, val)
        }
        else {
            (NULL)
        }
    },
    reducer = function(key, vals) {
        speed <- 0
        dist <- 0
        for (x in vals) {
            speed <- speed + x[[1]]
            dist <- dist + x[[2]]
        }
        dist <- dist / length(vals)
        speed <- speed / length(vals)
        orch.keyval(key, c(dist, speed))
    }
)
unlink(tmpf)
print(readLines(hdfs.download(x)))
