##
# A simple example of how to do a tera-sort trip. Input dataset is just a 
# bunch of random values. Mapper is swapping key and value places and reducer
# gets sorted data for free and swaps it back in place. Note that sorting is
# lexicographical dues to text input-output format.
##
cat('Running TeraSort example:','\n')

dat <- data.frame(id=rnorm(1000))
x <- hadoop.run(
    dat,
    mapper = function(key, val) {
        keyval(val$id, '')
    },
    reducer = function(key, vals) {
        keyval(NULL, key)
    },
    config = new("mapred.config", 
        map.output = data.frame(key=0, val='')
    )
)
print(head(x))
