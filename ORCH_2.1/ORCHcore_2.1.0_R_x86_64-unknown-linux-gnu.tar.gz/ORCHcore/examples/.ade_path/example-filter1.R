##
# A simple example of how to operate with key-values. Input dataset - cars.
# Filter cars with with "dist" > 30 in mapper and get mean "dist" for each 
# "speed" in reducer.
##
cat("Running cars filtering and mean example #1:\n")

cars.dfs <- hdfs.put(cars, key='speed')
x <- hadoop.run(
    cars.dfs,
    mapper = function(key, val) {
        if (val$dist > 30) {
            orch.keyval(key, val)
        }
        else {
            (NULL)
        }
    },
    reducer = function(key, vals) {
        X <- 0
        for (x in vals) {
            X <- X + x$dist
        }
        X <- X / length(vals)
        orch.keyval(key, X)
    },
    config = new("mapred.config", 
        map.tasks = 1,
        reduce.tasks = 1
    )
)
print(hdfs.get(x))
