##
# A simple example of how to run mapper in "list" mode with unlimited number of
# records at once. Input dataset - cars. Filter cars with with "dist" > 30 and 
# get mean "dist" for each in the mapper. Reducer just merges all the results 
# together.
##
cat('Running example of data.frame reducer input','\n')

cars.dfs <- hdfs.put(cars)
x <- hadoop.run(
    cars.dfs,
    mapper = function(key, val) {
        orch.keyval(key, val)
    },
    reducer = function(key, vals) {
        orch.keyval(1, length(vals))
    },
    config = new("mapred.config",
        reduce.input = "list",
        reduce.split = 9,
        reduce.output = data.frame(key=0, count=0L))
)
res <- hdfs.get(x)
print(res)
