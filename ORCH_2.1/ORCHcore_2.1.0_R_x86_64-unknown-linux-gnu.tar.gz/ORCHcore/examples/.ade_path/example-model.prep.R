##
# This example shows how to run a distributed model data preparation. 
# Distributes data across several map tasks, each task executes ‘model.frame’
# function on a slice of input data set and outputs a ‘data.frame’ with the 
# variables needed to use the ‘formula’. Reducers merge the data.frames into
# one output data set.
##

dfs.iris <- hdfs.put(iris)
num.reducers <- 10
formula <- iris$Sepal.Length ~ 1 + I(iris$Sepal.Width*iris$Petal.Length) + 
    exp(iris$Petal.Length) + log(iris$Petal.Length)

# Same linear model but configured as map-only job.
# Note that this will take some time due to Hadoop overhead.
dfs.out <- hadoop.exec(
    dfs.id = dfs.iris,
    mapper = function(k, v) {
        vals <- model.frame(formula, v)
        key <- sample(num.reducers, 1)
        orch.keyvals(key, vals)
    },
    reducer <- function(k, vv) {
        orch.keyvals(k, vv)
    },
    export = orch.export(formula, num.reducers),
    config = new("mapred.config",
        job.name = "model.prep",
        map.split = 0,
        map.input = "data.frame",
        map.output = data.frame(key=0, v1=0, v2=0, v3=0, v4=0),
        reduce.output = data.frame(key=0, v1=0, v2=0, v3=0, v4=0)
    )
)
x <- hdfs.get(dfs.out)[2:5]
print(x)
