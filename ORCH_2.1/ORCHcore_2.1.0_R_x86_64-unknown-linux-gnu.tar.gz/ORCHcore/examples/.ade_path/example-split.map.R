##
# A simple example of how to run mapper in "list" mode with unlimited number of
# records at once. Input dataset - cars. Filter cars with with "dist" > 30 and 
# get mean "dist" for each in the mapper. Reducer just merges all the results 
# together.
##
cars.dfs <- hdfs.put(cars)

cat('Running example of list splitting in mapper','\n')
x1 <- hadoop.run(
    cars.dfs,
    mapper = function(keys, vals) {
        orch.keyval(1, c(length(vals), 1))
    },
    reducer = function(key, vals) {
        count <- 0
        splits <- 0
        for (x in vals) {
            count <- count + x$count
            splits <- splits + x$splits
        }
        orch.keyval(NULL, c(count, splits))
    },
    config = new("mapred.config",
        map.input = "list",
        map.split = 9,
        map.output = data.frame(key=0, count=0, splits=0),
        reduce.output = data.frame(key=0, count=0, splits=0))
)
res1 <- hdfs.get(x1)
print(res1)

cat('Running example of data.frame splitting in mapper','\n')
x2 <- hadoop.run(
    cars.dfs,
    mapper = function(keys, vals) {
        orch.keyval(1, c(dim(vals)[1], 1))
    },
    reducer = function(key, vals) {
        count <- 0
        splits <- 0
        for (x in vals) {
            count <- count + x$count
            splits <- splits + x$splits
        }
        orch.keyval(NULL, c(count, splits))
    },
    config = new("mapred.config",
        map.input = "data.frame",
        map.split = 7,
        map.output = data.frame(key=0, count=0, splits=0),
        reduce.output = data.frame(key=0, count=0, splits=0))
)
res2 <- hdfs.get(x2)
print(res2)
