##
# One dimension logistic regression with gradien descent
# Tweak the iterations and alpha value as appropriate
##
cat("Running logistic regression.\n")

input <- hdfs.put(cars)
mapred.logreg <- function(input, iterations=3, alpha=0.1)
{
    plane <- 0
    g <- function(z) 1/(1 + exp(-z))
    mapf <- data.frame(val1=1, val2=1)
    for (i in 1:iterations) {
        gradient <- hadoop.run(
            input,
            mapper = function(k, v) {
                keyval(1, v$speed * v$dist * g(-v$speed * (plane * v$dist)))
            },
            reducer = function(k, vv) {
                vv <- sapply(vv, unlist)
                keyval(k, sum(vv))
            },
            export = orch.export(plane, g),
            config = new("mapred.config", 
                job.name = "logistic.regression",
                map.output = mapf)
        )
        gradient <- hdfs.get(gradient)
        plane <- plane + alpha * gradient$val2
    }
    (plane)
}

plane <- mapred.logreg(input)
print(plane)

