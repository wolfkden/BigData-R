##
# This example shows how to do a sum operation in mapReduce. Essentially it's
# a "hello world" application because this is one of the simpliest operations
# you can do. It (ab)uses shaffle-sort capability of Hadoop in the reduce
# phase and gets all input data aggregated in one reducer at the end.
##

# Sum up a vector of numeric values.
# Aggregates all values in one reducer.
kv <- hadoop.run(
    data = data.frame(x=c(1,2,3)),
    mapper = function(k, v) {
        orch.keyval(0, v)
    },
    reducer <- function(k, vv) {
        V <- 0
        for (v in vv) {
            V <- V + v[[1]]
        }
        orch.keyval(k, V)
    },
    job.name = "sum"
)
x <- kv[2]
print(x)

# Sum up all columns of a data.frame.
# Aggregates all values in one reducer.
kv <- hadoop.run(
    data = cars,
    mapper = function(k, v) {
        orch.keyval(0, v)
    },
    reducer <- function(k, vv) {
        V <- c(0, 0)
        for (v in vv) {
            V <- V + unlist(v)
        }
        orch.keyval(k, V)
    },
    job.name = "sum"
)
x <- kv[2:3] # remove key
print(x)
