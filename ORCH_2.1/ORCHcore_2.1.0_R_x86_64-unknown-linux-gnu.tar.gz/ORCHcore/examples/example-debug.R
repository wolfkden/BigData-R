##
# A simple example of how to debug your mapReduce code. Input dataset cars.
# Shows how to enable debugging: see init and final functions, and to output 
# log messages: see orch.dlog.* function calls through the code. Messages
# can be seen in the job log.
##
cat("Running mapReduce debug example.\n")

cars.dfs <- hdfs.put(cars, key="speed")
orch.dryrun(T)
orch.dbg.on('all')
orch.dbg.output()
x <- hadoop.run(
    cars.dfs,
    init = function() {
        orch.dbg.on('all')
        orch.dbg.output(stderr())
    },
    mapper = function(key, x) {
        if (key == 20) {
            orch.keyval(key, x)
        }
        else {
            orch.dlog.info("removing k=%g,v=%g", key, x$dist)
            (NULL)
        }
    },
    reducer = function(key, vals) {
        X <- 0
        na <- 0
        orch.dlog.info("key=%g", key)
        for (x in vals) {
            if (is.na(x$dist)) {
                na <- na+1
            }
            else {
                X <- X + x$dist
            }
        }
        if (na > 0) {
            orch.dlog.warning("%g NA values skipped", na)
        }
        X = X / (length(vals) - na)
        orch.dlog.info("val=%g", X)
        orch.keyval(key, X)
    },
    final = function() {
        orch.dbg.output()
        orch.dbg.off()
    }
)
orch.dbg.off()
orch.dryrun(F)
print(hdfs.get(x))
