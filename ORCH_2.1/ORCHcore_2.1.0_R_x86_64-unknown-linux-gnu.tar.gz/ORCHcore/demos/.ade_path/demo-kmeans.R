##
# Perform K-means clustering using a mapReduce version of Lloyd's algorithm.
##

##
#' Creates cluster ids (clusters) and distance from centroids (distance)
#' for a given partition of the overall data based on an initial set of
#' cluster centroids.
#' 
#' @param x an ore.frame
#' @param param a matrix of cluster centers
##
kmeansScorer <- function(x, param)
{
    if (!is.matrix(param)) {
        param <- as.matrix(param)
    }
    if (ncol(x) != ncol(param) || any(is.na(param))) {
        stop("ncol(x) != ncol(param) || any(is.na(param))")
    }
    n <- nrow(x)
    cluster  <- rep(NA_integer_, n)
    distance <- rep(NA_real_, n)
    if (nrow(x) == 0 || nrow(param) == 0) {
        # bad input?
        data.frame(cluster = cluster, distance = distance)
    }
    else {
        xmat <- t(as.matrix(x))
        distMat <- matrix(NA_real_, n, nrow(param))
        for (i in 1:nrow(param)) {
            distMat[,i] <- colSums((xmat - param[i,])^2)
        }
        cluster <- max.col(- distMat, ties.method = "random")
        distance <- distMat[cbind(1:n, cluster)]
        data.frame(cluster = cluster, distance = distance)
    }
}

##
#' Calculates cluster centroids (centers) and observation counts (sizes)
#' for a given partition of the overall data based on an initial set of
#' cluster centroids.
#' 
#' @param x an ore.frame
#' @param param a matrix of cluster centers
##
mapper <- function(k,v)
{
    param <- centers
    if (!is.matrix(param)) {
        param <- as.matrix(param)
    }
    if (ncol(v) != ncol(param) || any(is.na(param))) {
        stop("ncol(v) != ncol(param) || any(is.na(param))")
    }
    x <- na.omit(v)
    size <- rep(0, nrow(param))
    if (nrow(x) != 0 && nrow(param) != 0) {
        cluster <- kmeansScorer(x, param)[["cluster"]]
        for (i in 1:nrow(param)) {
            xsub <- x[cluster == i, , drop = FALSE]
            size[i] <- nrow(xsub)
            if (size[i] > 0) {
                param[i,] <- colMeans(xsub)
            }
        }
    }
    orch.keyval(1, orch.pack(centers = param, size = size))
}

##
#' Combines results from kmeansMapper parallel jobs to form overall
#' cluster centroids (centers) and observation counts (sizes)
#' @param results  a list of lists containing centers and sizes
##
reducer <- function(k,v)
{
    results <- lapply(v,function(x){orch.unpack(x)})
    combine2 <- function(x, y) {
        sums <- x$centers * x$size + y$centers * y$size
        size <- x$size + y$size
        list(centers = sums/size, size = size)
    }
    res <- Reduce(combine2, results)
    orch.keyval(NULL, orch.pack(centers = res$centers))
}

# Run configuration.
iterations <- 1
ncenters <- 6
centers <- data.frame(
    x = rnorm(ncenters),
    y = rnorm(ncenters))

# Generate a random points for k-means clustering test.
points <- data.frame(
    x = sapply(1:1000, function(i) 
        rnorm(1, mean = i%%3, sd = 0.1)),
    y = sapply(1:1000, function(i) 
        rnorm(1, mean = i%%4, sd = 0.1)))

dfs.points <- hdfs.put(points)
# Do "iterations".
for (i in 1:iterations) {
    if (i > 1) {
        res <- hdfs.get(dfs.centers)
        results <- lapply(as.list(res$val),
                          function(x){orch.unpack(as.character(x))})
        centers = results[[1]]$centers
        
       if (length(results[[1]]) > 1) {
            centers = do.call(rbind, 
                lapply(results[[1]],
                    function(x) {
                        as.data.frame(x$centers)
                    }))
        }
    }
    
   cat("centers\n")
   print(centers)
   cat("removing NaNs if any\n")
   centers <- centers[complete.cases(centers),]
    
   dfs.centers <- hadoop.exec(
    dfs.id = dfs.points,
    mapper =  mapper,
    reduce = reducer,
    export = orch.export(centers, kmeansScorer),
    config = new("mapred.config",
        job.name = sprintf("k-means.%g", i),
        map.input = "data.frame",
        map.split = 0, # all rowal
        map.tasks = 1,
        min.split.size = 1,
        map.output = data.frame(key=0, val=''),
        reduce.output = data.frame(key=0, val=''))
    )
}

# Retrieve the final result of clustering.
res <- hdfs.get(dfs.centers)
results <- lapply(as.list(res$val),function(x){orch.unpack(as.character(x))})
centers <- results[[1]]$centers
if (length(results[[1]]) > 1) {
    centers <- do.call(rbind, 
        lapply(results[[1]],
            function(x) {
                as.data.frame(x$centers)
            }))
}
cat("final centroids\n")
print(centers)
