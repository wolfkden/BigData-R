##
# Calculate Euclidian distance similarity measures amongst movies based on user
# ratings.
#
# @param movies an HDFS file with numeric columns UserID, MovieID, Ratings
#     where UserID is the key and MovieID nad Ratings are values.
# @return HDFS ID of the a file with results.
##
mapred.distance <- function(movies)
{
    if (!is.hdfs.id(movies)) {
        dfs.movie <- hdfs.put(movies, key="UserID")
    }
    else {
        dfs.movie <- movies
    }

    ##
    #' STEP 1: UserID is the key.
    #' **************************
    #' Mapper is a pass-through
    #' Each reducer gets all the (MovieID,Ratings) pair for an user and perform 
    #' the pairwise squared differences and output a list of list of the following 
    #' form:
    #'   for user1/reducer1 ( we can potentially remove m1m1 differences):
    #'   key=m1  : val=list((diffm1m1)^2, (diffm1m2)^2,.....(diffm1mn)^2 
    #'   key=m2  : val=list((diffm2m1)^2,....................(diffm2mn)^2
    #'   .......
    #'   key=mn  : val=list((diffmnm1)^2,.....................(diffmnmn)^2
    #' note, here 'n' is the number of movies sceen by the user, (not all the 
    #' movies in the data set)
    ##
    dfs.step1out <- hadoop.exec(
        dfs.id = dfs.movie,
        mapper = function(k,v) {
            #no-op
            orch.keyval(k,v)
        },
        reducer = function(k,vals) {
            Rating  <- unlist(lapply(vals, `[[`, "Rating"), use.names = FALSE)
            MovieID <- unlist(lapply(vals, `[[`, "MovieID"), use.names = FALSE)
            sqdiff  <- outer(Rating, Rating, FUN = "-")^2
            dimnames(sqdiff) <- list(MovieID, MovieID)
            out <- c()
            for(i in 1:length(vals)) {
                out[i] <- orch.keyval(MovieID[i], 
                    orch.pack(diflist = (sqdiff[i,])))
            }
            (out)
        },
        config = new("mapred.config",
            job.name = "dist-matrix.step1",
            map.split = 1,
            map.valkey = FALSE,
            map.tasks = 1000,
            reduce.tasks = 500,
            reduce.output = data.frame(key=0, val=''))
    )

    ##
    #' STEP2: MovieID is the key.
    #' **************************
    #' Mapper is again a pass-throug, with the movie-id as the key.
    #' In reducer for each movie-id, we get a list of squared differences (see 
    #' above), for only those users who have rated it. We perform the summation 
    #' over this list of list when we find a MovieID match by looping through 
    #' this list multiple times to create a final list of summated list of the 
    #' form:
    #'   for reducer getting movie-id m1:
    #'   key=m1  value=list(1/(1+sum((diffm1m1)^2) over all users),...
    #'                      1/(1+sum((diffm1mm)^2) over all users))
    #'   mth reducer (=no. of unique movies)
    #'   .......
    #' 
    #'   key=mm  value=list(1/(1+sum((diffm1m1)^2) over all users),...
    #'                      1/(1+sum((diffm1mm)^2) over all users))
    #' 
    #' Note: The implementation is not optimal (lots of for loops). 
    ##
    dfs.final <- hadoop.exec(
        dfs.id = dfs.step1out,
        mapper = function(k,v) {
            # pass-through
            orch.keyval(k,v)
        },
        reducer = function(k,vals) {
            vals <- lapply(vals, function(x) orch.unpack(x)[[1L]])
            #--- final all movies in the data
            movies <- unlist(lapply(vals, names), use.names = FALSE)
            movies <- sort(unique(movies))
            #--- initialize sum of squared differences to 0
            sumsqdiffs <- rep.int(0, length(movies))
            names(sumsqdiffs) <- movies
            #--- perform the summation
            for (i in seq_len(length(vals))) {
                x <- vals[[i]]
                nms <- names(x)
                sumsqdiffs[nms] <- x + sumsqdiffs[nms]
            }
            #--- convert to similarity measure
            res <- 1/(1 + sqrt(sumsqdiffs))
            #--- output result
            orch.keyval(k, orch.pack(res = as.list(res)))
        },
        config = new("mapred.config",
            job.name = "dist-matrix.step2",
            map.split = 1,
            map.valkey = FALSE,
            map.tasks = 1000,
            reduce.tasks = 500,
            map.output = data.frame(key=0, val=''),
            reduce.output = data.frame(key=0, val=''))
    )

    (dfs.final)
}

# Sample the output result.
dfs.res <- mapred.distance(movies)
res <- hdfs.sample(dfs.res, lines=5)

# Get the list of distance calculation. The result will be a frame of 5 
# movies with each entry a list of movie distances the ones which do not 
# appear in the result, have non existant cell value (1/(1+0) = 1) for 
# that m[i,j] combination in the matrix.
dim(res)

# Show the sampled output. 
# 1. MovieID for first which the distance is calculated with all the other movies:
print("MovieID:")
res[1,1]

# 2. List of MovieID and Rating value for MovieID res[1,1]:
print("Distance with other movies:")
orch.unpack(res[1,2])
