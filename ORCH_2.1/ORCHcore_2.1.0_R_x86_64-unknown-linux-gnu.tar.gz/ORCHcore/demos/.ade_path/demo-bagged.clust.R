##
# Simple example for doing "bagging" with two level clustering the mapper does 
# kmeans for subset of data the reducer combines the centroids generated from 
# the mappers into a hierarchical cluster (single linkage) and stores the 
# hclust object on HDFS, which can then be used by the R user for voting.
# The algorithm can be found at: http://epub.wu.ac.at/1272/1/document.pdf
##
mapred.hclust <- function(
        points, 
        ncenters = 6, 
        iterations = 10)
{
    dfs.points <- if (is.hdfs.id(points)) points else hdfs.put(points)
    dfs.centers <- hadoop.exec(
        dfs.id = dfs.points,
        mapper = function(k, v)
        {
            x <- kmeans(v, ncenters, iter.max=iterations)
            orch.keyval(1, orch.pack(centroids=as.data.frame(x$centers)))
        },
        reducer = function(k, vals)
        {
            centroids <- do.call(fast.rbind, 
                lapply(vals, function(x) {
                    orch.unpack(x)$centroids
                }))
            d <- dist(centroids)
            clust <- hclust(d, method="single")
            clust$call <- as.character(clust$call)
            orch.keyval(NULL, orch.pack(final.clust=clust))
        },
        export = orch.export(ncenters, iterations),
        config = new("mapred.config",
            job.name = "hcluster",
            map.input = "data.frame",
            map.split = 0, # all rows
            map.tasks = 1, # only one mapper 
            min.split.size = 1, # force splitting
            map.output = data.frame(key=0, val=''),
            reduce.output = data.frame(key=0, val=''))
    )
    
    # res is a hierarchical cluster 
    res <- hdfs.get(dfs.centers)
    val1 <- orch.unpack(as.character(res$val))
    (val1$final.clust)
}

# Generate a random points for k-means clustering test.
points <- data.frame(
    x = sapply(1:1000, function(i) 
        rnorm(1, mean = i%%3, sd = 0.1)), 
    y = sapply(1:1000, function(i) 
        rnorm(1, mean = i%%4, sd = 0.1)))

# Calculate the final hierarchical cluster from the input set
finalclust <- mapred.hclust(points)
print(finalclust)
