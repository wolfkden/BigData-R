##
# This algorithm computes the essential statstics needed for PCA calculation 
# of a data-set by creating  a tree of mupliple map-reduce jobs, reducing the 
# number of records to process at each stage. The final map-reduce does the 
# final merge of its inputs to generate the statistics for the whole data set.
#
#
# STEPS:
# PHASE 1: This phase consist of a map-reduce job which computes a set of 
# statistics (mean, number of observations and cross-product of item-ids) 
# of a partion of the input data. The mappers compute the above statistics 
# for the part of the dataset it recieves, # then the reducers merge the 
# statistics from all the mappers.
#
# PHASE 2: This is the second phase, where map reduce jobs are submitted in 
# a loop thus merging the outputs of the previous job results and reducing 
# the number of reducers at each iteration. 
#
# eg. In phase 1, if the number of mappers and reducers are set to 1000 and 
# 256 respectively, the phase 2 takes in the 256 reducer outputs and merges 
# them in step of 2 resulting in the following number of reducers in each 
# iteration: 128, 64, 32, 16, 8, 4, 2, 1. The mappers in phase 2 just do 
# random assignments of records to the reducers which then performs the 
# merges.
##

orch.cov <- function(formula=~., data, numReducers = 1)
{
    # Reducer taking in N vals (sufficient stats for PCA) and merging them 
    # into 1 output stat. It users R's Reduce operator for the reduction 
    # operation. The reducer is shared between Phase I and II.
    reducer <- function(key, vals)
    {
        combine2 <- function(e1, e2)
        {
            n <- e1$n + e2$n
            delta <- e2$mean - e1$mean
            list(n = n,
                mean = e1$mean + delta * (e2$n/n),
                sumsq = e1$sumsq + e2$sumsq +
                    outer(delta, delta, FUN = "*") * ((e1$n * e2$n)/n))
        }
        
        inp <- lapply(vals,function(x) orch.unpack(x)[[1L]])
        # filter out zero length/null elements
        keep <- sapply(inp,function(x) {length(x)!=0 && !is.null(x$n) && 
            !is.null(x$mean) && !is.null(x$sumsq)})
        
        inp <- inp[keep]
        
        #stats <- Reduce(combine2, lapply(inp,function(x) orch.unpack(x)[[1L]]))
        stats <- Reduce(combine2, inp)
        orch.keyval(key, orch.pack(stats = stats))
    }
    
    numReducers <- as.integer(numReducers)[1L]
    if (is.na(numReducers) || numReducers < 1L) {
        numReducers <- 1L
    }
    
    # Phase I MapReduce job.
    dfs.res <- hadoop.run(
        data,
        # mapper performing the first set of statistic generation for thr 
        # portion of input data sets it received
        mapper = function(keys, vals)
        {
            vals <- do.call(fast.rbind, lapply(vals, as.data.frame))   
            # Create derived variables.
            vals <- as.matrix(model.frame(formula, data = vals))
            
            # Compute the sufficient statistics.
            n <- nrow(vals)
            mean <- colMeans(vals)
            crossp <- crossprod(scale(vals, center = mean, scale = FALSE))
            stats <- list(n = n, mean = mean, sumsq = crossp)
            
            # Output result.
            key <- sample(numReducers, 1)
            orch.keyval(key, orch.pack(stats = stats))
        },
        reducer = reducer,
        export  = orch.export(formula, numReducers),
        config  = new("mapred.config",
            job.name   = sprintf("cov_%d_reducers", numReducers),
            map.input  = "list",
            map.split  = 1000,
            map.valkey = FALSE,
            map.tasks  = 1500,
            min.split.size = 1,
            reduce.tasks = numReducers,
            map.output    = data.frame(key=0, val=''),
            reduce.output = data.frame(key=0, val=''))
    )
    
    # Phase II MapReduce jobs.
    # Keep deviding the number of reducers by 2 at each step and merge the 
    # results of the mapreduce-job of the previous iteration, thus reducing 
    # the number of output statistics by a factor of 2 at each step. Of 
    # course, you can vary the step width as you need (2 is not a fixed value).
    while (numReducers >= 2L) {
        numReducers.save <- numReducers
        numReducers <- numReducers %/% 2L
        dfs.res <- hadoop.run(
            dfs.res,
            mapper = function(keys, vals)
                keyval(sample(numReducers, 1), vals),
            reducer = reducer,
            export  = orch.export(numReducers),
            config  = new("mapred.config",
                job.name   = sprintf("cov_%d_reducers", numReducers),
                map.split  = 1,
                map.valkey = FALSE,
                map.tasks  = numReducers.save,
                min.split.size = 1,
                reduce.tasks = numReducers,
                map.output    = data.frame(key=0, val=''),
                reduce.output = data.frame(key=0, val=''))
        )
    }
    
    # Return the result.
    (dfs.res)
}

# x is the matrix user X item matrix in HDFS
#change numReducers according to data size
res <- orch.cov(data=x,numReducers=256)

# PCA calculation.
finalres <- orch.unpack(hdfs.get(res))
covmat <- finalres$stats$sumsq/(finalres$stats$n-1)
pca <- princomp(covmat=covmat)
