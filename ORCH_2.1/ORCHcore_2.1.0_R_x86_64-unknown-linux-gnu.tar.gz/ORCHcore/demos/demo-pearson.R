##
# Calculate Pearson's correlation amongst movies based on user ratings.
#
# @param movies an HDFS file with numeric columns UserID, MovieID, Ratings
#     where UserID is the key and MovieID nad Ratings are values.
# @return HDFS ID of the a file with results.
##
mapred.pearson <- function(movies)
{
    if (!is.hdfs.id(movies)) {
        dfs.movie <- hdfs.put(movies, key="UserID")
    }
    else {
        dfs.movie <- movies
    }

    dfs.step1out <- hadoop.exec(
        dfs.id  = dfs.movie,
        mapper  = function(k, vals) orch.keyval(k, vals),
        reducer = function(k, vals)
        {
            movie <- unlist(lapply(vals, `[[`, "MovieID"), use.names = FALSE)
            rating <- unlist(lapply(vals, `[[`, "Rating"),  use.names = FALSE)
            avgrating <- tapply(rating, movie, mean)
            movie <- as.integer(names(avgrating))
            rating <- unname(avgrating)
            output <- lapply(seq_len(length(vals)),
                function(i)
                {
                    key <- movie[i]
                    keep <- which(movie > key)
                    if (length(keep) == 0) {
                        NULL
                    }
                    else {
                        val  <- cbind(MovieID = movie[keep],
                            Rating1 = rating[movie == key],
                            Rating2 = rating[keep])
                        orch.keyval(key, orch.pack(mat = val))[[1]]
                    }
                })
            keep <- !unlist(lapply(output, is.null), use.names = FALSE)
            output[keep]
        },
        config = new("mapred.config",
            job.name = "pearson-cor-1",
            map.split = 1,
            map.valkey = FALSE,
            map.tasks = 300,
            reduce.tasks = 200,
            reduce.output = data.frame(key=0, val=''))
    )
    
    hadoop.exec(
        dfs.id  = dfs.step1out,
        mapper  = function(k, vals) orch.keyval(k, vals),
        reducer = function(k, vals)
        {
            vals <- do.call(rbind,
                lapply(vals, function(x) orch.unpack(x)[[1L]]))
            vals <- as.data.frame(vals)
            cors <- unlist(lapply(split(vals[,c("Rating1", "Rating2")],
                vals[,"MovieID"]),
                function(x) cor(x[,1L], x[,2L])))
            val  <- data.frame(Movie1 = as.integer(k),
                Movie2 = as.integer(names(cors)),
                Cor = unname(cors))
            orch.keyval(k, orch.pack(cor = val))
        },
        config = new("mapred.config",
            job.name = "pearson-cor-2",
            map.split = 1,
            map.valkey = FALSE,
            map.tasks = 300,
            reduce.tasks = 200,
            map.output = data.frame(key=0, val=''),
            reduce.output = data.frame(key=0, val=''))
    )
}

#res <- pearsonRIM(dfs.final)
