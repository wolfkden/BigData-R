# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' @name Oracle R Connector for Hadoop
#' @docType package
#' 
#' ORCH performance library. This is a collection of performance measuring
#' functions for R code profiling. The functions try to balance between 
#' usability and minimal performance degradation but it is not wise to put
#' them in every line of R code. The whole performance suit can be switched
#' off eliminating any affect on the code performance.
#' 
#' Essentially this is the control point to enable or disable
#' profiling of R code. Replacing of this function with an empty one disables
#' collection of performance measurements.
##

###############################
# DO NOT INCLUDE AND SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

if (!exists('.orch.perf.env') || 
    is.null(.orch.perf.env$init))
{
    # Enables profiling of ORCH code.
    .orch.perf.env <- new.env()
    .orch.perf.env$enable <- F
    .orch.perf.env$init <- T
    
    # Performance functions invocation cost.
    # Very specific for every host, use orch.perf.tune()
    .orch.perf.env$start.cost <- 0.00002
    .orch.perf.env$stop.cost <- 0.0003
    .orch.perf.env$overhead <- 0.00001
}

setClass("orch.perf.marker", contains=c("vector"))
setClass("orch.perf.timer", contains=c("vector"))

##
#' This overloads substraction of two timers which is used if one timer was
#' profiling a sub-routine of already profiled block of code.
#' @example:
#'     orch.perf.start()
#'     for (i in 1:10000) {
#'         orch.perf.start(t2)
#'         rnorm(1)
#'         orch.perf.stop(t.rnorm, t2)
#'     }
#'     orch.perf.stop(t.for)
#'     t.for <- t.for - t.rnorm
##
"-.orch.perf.timer" <- function(l, r)
{
    l[1] <- l[1] - r[1]
    l
}

##
#' Start a block of code to be profiled. Must be followed by orch.perf.stop()
#' call which collects timing and drops timing object \p tm.
#' 
#' @param tm Optional timing marker. Timing object stores start time and gets
#'     removed after block timing is measured. If you don't specify the object
#'     a default object will be created for you.
#' 
#' @seealso orch.perf.stop
##
orch.perf.start <- function(tm)
{
    if (missing(tm)) {
        tmName <- ".__tm__"
    } else {
        tmName <- deparse(substitute(tm))
    }
    assign(tmName, new("orch.perf.marker", c(
        secs = unname(proc.time()[3]), 
        cost = unname(.orch.perf.env$start.cost))), 
        envir=parent.frame())
}

##
#' This function does exactly the same as "timer <- timer + proc.time() - tm"
#' but also tries to compensate timing measurement for the cost of this and
#' previous orch.prof.start() calls.
#' 
#' @param timer Performance timer which accumulates all measures. If the
#'     variable does not exist then a new one will be created automatically.
#' @param tm Optional timing marker created by orch.perf.start(). This
#'     object gets deleted after timing is added to \p timer (if ]p resume
#'     is not set to TRUE).
#' @param resume Do not stop timer \p tm from counting, e.g. do not delete it. 
#'     The next orch.perf.stop() invocation will use it and include previously 
#'     count section too. Beware of double-counting!
#' 
#' @seealso orch.perf.start
#' @seealso orch.perf.log
##
orch.perf.stop <- function(timer, tm, resume=FALSE)
{
    # Retrieve the timing marker created by orch.perf.start.
    stopTime <- as.numeric(proc.time()[3])
    if (missing(tm)) {
        # use default timing marker
        tmName <- ".__tm__"
        tm <- get(tmName, envir=parent.frame())
    }
    else {
        # user custom timing marker
        tmName <- deparse(substitute(tm))
    }
    
    # Measure timing-overhead and cost of measurement itself,
    # accumulate timing measurements in a parent variable.
    cost <- .orch.perf.env$stop.cost + tm[2]
    delta <- stopTime - tm[1] - .orch.perf.env$overhead
    if (delta < 0) {
        # we can't time < 0
        delta <- 0
    }
    timerName <- deparse(substitute(timer))
    if (!exists(timerName, envir=parent.frame())) {
        # reset 0 timer if it's its first use
        timer <- orch.perf.t()
    }
    assign(timerName, new("orch.perf.timer", c(
        time = unname(timer[1] + delta),
        cost = unname(timer[2] + cost),
        calls = unname(timer[3] + 1))),
        envir = parent.frame())

    # Adjust timing marker cost to prevent double counting.
    if (resume) {
        # Adjust timing marker cost to prevent double counting.
        # Second stop() must not count in the start() cost again.
        assign(tmName, new("orch.perf.marker", c(
                secs = as.numeric(tm), 
                cost = 0)),
            envir=parent.frame())
    }
    else {
        # Remove the original timing marker to prevent its usage,
        # e.g. it will prevent 
        rm(list=tmName, 
            envir=parent.frame())
    }
}

##
#' Same as stopping and then starting the timer again. Just a readability
#' function rolling 2 calls into one.
#' 
#' @seealso orch.perf.start
#' @seealso orch.perf.stop
##
orch.perf.stopstart <- function(timer, tm)
{
    orch.perf.stop(timer, tm, F)
    orch.perf.start(tm)
}

##
#' Creates new performance timer or returns an existing one. \p timer is the 
#' object to create or to return if already exists. If timer is not specified
#' then always creates a new timer object.
#' 
#' @example
#'     orch.perf.t(my_timer) # created new
#'     my_timer <- orch.perf.t() # created new
#'     orch.perf.t(my_timer) # returned existing
#' 
#' @seealso orch.perf.stop
#' @seealso orch.perf.log
##
orch.perf.t <- function(timer)
{
    if (missing(timer)) {
        timer <- new("orch.perf.timer", 
            c(time=0, cost=0, calls=0))
    }
    else {
        timer <- try(timer, silent=T)
        if (inherits(timer, "try-error")) {
            timer <- new("orch.perf.timer", 
                c(time=0, cost=0, calls=0))
        }
    }
    timer
}

##
#' Logs performance measurements. Message can be specified to describe the 
#' object. If message is not specified then "var timing XXX sec" is used. If 
#' message has no "%s" tags then the object size is appended to the end.
#' 
#' @param msg Custom log message or a timer object if \p t is missing.
#' @param timer Timer object, obtained via orch.perf.stop(), or just number 
#'     of seconds passed as numeric. If a timer object is passed the the log
#'     will include number of iterations of the profiled R code block.
#' @param indent Indentation of the log message.
#' 
#' @seealso orch.perf.stop
##
orch.perf.log <- function(msg, timer, indent=0)
{
    if (missing(msg)) {
        orch.dlog.stop("missing message or timer")
    }
    if (missing(timer)) {
        timer <- try(msg, silent=T)
        if (inherits(timer, "try-error")) {
            # timing was not measured, use 0sec.
            tName <- deparse(substitute(msg))
            timer <- orch.perf.t()
            msg <- sprintf("%s timing %%s", tName)
        }
        else if (is.character(msg)) {
            # only message, no timing. header?
            timer <- orch.perf.t()
        }
        else {
            # only timing, no message. use default.
            tName <- deparse(substitute(msg))
            timer <- msg
            msg <- sprintf("%s timing %%s", tName)
        }
    }
    else {
        # message and timing, format the message.
        msg <- null.to(msg, '')
        if (!grepl("%s", msg, fixed=T)) {
            msg <- sprintf("%s %%s", strim(msg))
        }
    }
    timer <- try(timer, silent=T)
    if (inherits(timer, "try-error")) {
        timer <- orch.perf.t()
    }
    if (length(timer) == 1) {
        timerStr <- sprintf("%.3f sec", timer)
    }
    else {
        timing <- timer['time'] 
        callsN <- timer['calls'] 
        timerStr <- sprintf("%.3f sec, %g call%s", 
            timing, callsN,
            ifelse(callsN != 1, 's', ''))
    }
    str <- sprintf(msg, timerStr)
    orch.dlog(orch.dbgTrace, str, indent=indent)
}

##
#' This function tries to figure out automatically the overhead of running
#' profiling of your code. It will run the specified \p it number of 
#' iterations of profiled R code and collect timings and then configure
#' profiling settings accordingly.
#' 
#' @param it Number of iterations, higher = more precise results.
#' @param print Print out cost sampling results.
#' 
#' @seealso orch.perf.start
#' @seealso orch.perf.stop
##
orch.perf.tune <- function(it = 3*10^3, print = TRUE)
{
    # Collect cost of using profiling functions.
    idle <- system.time(
            lapply(seq_len(it), function(x) {
                    1}))
    start <- system.time(
            lapply(seq_len(it), function(x) {
                    orch.perf.start(); 
                    1})) 
        - idle
    stop <- system.time(
            lapply(seq_len(it), function(x) {
                    orch.perf.start();
                    orch.perf.stop(ttt);
                    1}))
        - start - idle
        
    # Collect overhead of timing measurements. E.g. how much profiling 
    # closure adds to the measured value of timing. Don't forget to disable
    # overhead compensation first.
    .orch.perf.env$overhead <- 0
    timer <- orch.perf.t()
    for (i in seq_len(it)) {
        orch.perf.start();
        orch.perf.stop(timer);
    }
    
    # Update profiling environment.
    .orch.perf.env$start.cost <- as.numeric(start[3] / it)
    .orch.perf.env$stop.cost <- as.numeric(stop[3] / it)
    .orch.perf.env$overhead <- as.numeric(timer['time'] / it)
    
    # Log changes in profiling options.
    orch.dlog.info("profiling tuned:")
    orch.dlog.info("| start cost = %f", .orch.perf.env$start.cost)
    orch.dlog.info("| stop cost  = %f", .orch.perf.env$stop.cost)
    orch.dlog.info("| overhead   = %f", .orch.perf.env$overhead)
    
    # Optionally display measurements too.
    if (print) {
        cat("start cost:", .orch.perf.env$start.cost, "\n")
        cat("stop cost :", .orch.perf.env$stop.cost, "\n")
        cat("overhead  :", .orch.perf.env$overhead, "\n")
    }
}

##
#' Enables or disables ORCH profiling. Profiling can slower execution ORCH 2x 
#' or more. Switching profiling OFF will replace all profile function with
#' empty body function eliminating its overhead.
##
orch.perf.on <- function(on=T)
{
    if (on) {
        .orch.perf.env$enable <- T
        assign("orch.perf.start", .orch.perf.env$orch.perf.start, pos=1)
        assign("orch.perf.stop", .orch.perf.env$orch.perf.stop, pos=1)
        assign("orch.perf.log", .orch.perf.env$orch.perf.log, pos=1)
        assign("orch.perf.tune", .orch.perf.env$orch.perf.tuneup, pos=1)
    }
    else {
        .orch.perf.env$enable <- F
        assign("orch.perf.start", function(t) {}, pos=1)
        assign("orch.perf.stop", function(timer, t) {}, pos=1)
        assign("orch.perf.log", function(msg, timer, i=0) {}, pos=1)
        assign("orch.perf.tune", function(it=0) {}, pos=1)
    }
}

##
#' Returns TRUE if ORCH profiling is enabled.
##
orch.perf.enabled <- function()
{
    .orch.perf.env$enable
}

##
# Store profiling functions in the environment hash. This allows to switch
# on and off ORCH profiling feature on-flight at any time.
##
.orch.perf.env$orch.perf.start <- orch.perf.start
.orch.perf.env$orch.perf.stop <- orch.perf.stop
.orch.perf.env$orch.perf.log <- orch.perf.log
.orch.perf.env$orch.perf.tuneup <- orch.perf.tune
orch.perf.on(.orch.perf.env$enable)
