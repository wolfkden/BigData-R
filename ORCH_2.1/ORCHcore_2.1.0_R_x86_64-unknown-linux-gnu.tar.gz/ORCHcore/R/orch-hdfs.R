# Copyright (c) 2012, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' @name Oracle R Connector for Hadoop
#' @docType package
#' 
#' ORCH HDFS abstraction layer.
##

###############################
# DO NOT INCLUDE AND SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

## ------------------------------------------------------------------------- ##
##                         HDFS PRIVATE FUNCTIONS                            ##
## ------------------------------------------------------------------------- ##

##
#' Prompt user with question 'q' and wait till he enters y/yes or n/no.
#' Example: .orch.prompt('Are you sure?') -> "Are you sure? [yes] "
##
.orch.prompt <- function(q)
{
    # By default just ask Y/N?
    if (missing(q)) {
        q <- ''
    }
    
    # Prompt.
    cat(paste(q, " [yes] ",sep=''))
    orch.dlog.info("user prompt: \"%s\"", q)
    ret <- TRUE
    while (T) {
        # read and normalize 1 line 
        line <- readLines(n=1)
        input <- strim(tolower(as.character(line)))
        orch.dlog.info("user entered \"%s\"", input)
        if (length(input) == 0 || (nchar(input[1])==0)) {
            # user just hit Enter
            input <- "y"
        }
        if (!grepl("^(y|n|yes|no)$", input)) {
            # wrong answer
            cat("Please answer 'yes' or 'no' ")
            next
        }
        if (grepl("^n", input)) {
            # 'n' or 'no' was received
            ret <- FALSE
        }
        break
    }
    orch.dlog.info("prompt result = %s", ret)
    ret
}

##
#' Does the file name start with '_.' ?
#' @TODO (vlad) rewrite .dfs.path.filter
##
.dfs.path.filter <- function(filename)
{
  # split '<dir_path>/<filename> into <dire_path>, <filename> and
  # filter out the ones which start with '_'|'.' (special Hadoop files).
  p <- strsplit(filename, '/', fixed=T)[[1]]
  regexpr('^[_.]', p[length(p)])[1] < 0
}

##
#' Verifies that Hadoop software is installed locally or on a remote machine 
#' and you have access to its HDFS facilities. Will run a set of sample
#' commands to verify health of HDFS.
#'
#' @return TRUE if Hadoop's HDFS is up and running.
#' @return FALSE if Hadoop's HDFS is dead + prints out an error message.
##
.dfs.check <- function()
{
    err <- NULL

    # Try a simple HDFS "free space" command to validate that HDFS is 
    # functional. Analyse output and identify the error if any.
    orch.dlog.info("executing minimal HDFS checks")
    out <- .hal.dfs.df("/")
    if (length(out) == 1) {
        if (.sh.match(out, 'not found', any=T)) {
            err <- "HDFS is not installed or configured"
        } else {
            err <- "something's wrong with HDFS"
        }
    }
    else if (length(out) == 0 ||
            regexpr('^Filesystem.+$', out[1])[1] <= 0) {
        err <- 'unexpected response from HDFS'
    }
    
    # Run a minimalistic HDFS I/O test to validate that we actually can
    # use ORCH HDFS APIs. This a little bit slows down ORCH startup but
    # provides much higher level of confidence that ORCH is in healthy.
    if (is.null(err)) {
        orch.dlog.info("executing minimal HDFS I/O tests")
        x <- hdfs.put(1, dfs.name=hdfs.id(.orch.tmphdfs("/tmp"), force=T))
        if (is.null(x)) {
            err <- "put test data into HDFS"
        }
        else {
            y <- hdfs.get(x)
            if (is.null(x)) {
                err <- "get test data from HDFS"
            }
            else {
                if (y != 1) {
                    err <- "validate HDFS data consistency"
                }
            }
            if (hdfs.rm(x) == FALSE) {
                err <- "remove test data from HDFS"
            }
        }
        if (!is.null(err)) {
            err <- paste0("failed to ", err)
        }
    }
                    
    # Report back HDFS status.
    if (!is.null(err)) {
        if (.sh.error() != 0) {
            orch.dloge(err, cat=T)
            ret <- F
        }
        else {
            orch.dlogw(err, cat=T)
            ret <- T
        }
    }
    else {
        orch.dlog.info("HDFS is functional", cat=T)
        ret <- T
    }
    ret
}

##
#' Returns TRUE if \p x is actually an R "dfs.id" object. This guarantees that
#' the object is valid, exists and contains metadata stored alongside with the
#' data.
##
.is.dfs.id <- function(x)
{
    type <- attr(x, 'dfs.id', exact=T)
    !is.null(type) && type
}

##
#' Returns TRUE if \p x is actually an R "dfs.id" object OR a string path to
#' an HDFS object. If the function returns FALSE then .dfs.path(x) will fail.
##
.is.dfs.id_or_path <- function(x)
{
    .is.dfs.id(x) || (
        is.character(x) &&
        regexpr(' ', x, fixed=T)[1] < 0
    )
}

##
#' Returns TRUE if \p x is a result of .dfs.path() function.
##
.is.dfs.path <- function(x)
{
    type <- attr(x, 'dfs.path', exact=T)
    !is.null(type) && type
}

##
#' Returns TRUE if \p x is a non HDFS string object.
##
.is.dfs.str <- function(x)
{
    is.character(x) &&
        length(attributes(x)) == 0
}

##
#' Converts HDFS path to R "dfs.id" objects. Accepts absolute path(e.g. 
#' dfs.path() result), relative path (e.g. string) and itself (e.g. dfs.id() 
#' result). If \p dfs.x is of a wrong type or malformed then returns NULL.
#'
#' @param dfs.x HDFS object identifier | its name
#' @param stop invoke stop() id \p dfs.id is invalid
#'
#' @return R HDFS object which points to an HDFS resource.
#' @return NULL wrong type or malformed \p dfs.x
#' @attention Internal format of the object is a subject to change, use API!
##
.as.dfs.id <- function(dfs.x, stop=T)
{
    # Check input preconditions.
    if (missing(dfs.x)) {
        # no ID = unique ID
        dfs.x <- .orch.uid()
    }
    else if (.is.dfs.id(dfs.x)) {
        # nothing to do
        return(dfs.x)
    }
    if (!.is.dfs.path(dfs.x)) {
        # expand to full path
        dfs.x <- .dfs.path(dfs.x)
    }
    
    # Make the HDFS object pointer.
    .assert(.is.dfs.path(dfs.x))
    dfs.id <- dfs.x[[1]]
    
    # All done, mark as "id" type.
    attr(dfs.id, 'dfs.id') <- T
    dfs.id
}

##
#' Return the root directory of HDFS for the current user.
#' @param subdir add sub-directory to the HDFS root path (optional)
#' @TODO (vlad) Works for local HDFS but would it work for remote?
##
.dfs.root <- function(subdir)
{
    path <- sprintf('/user/%s', .sh('whoami'))
    if (!missing(subdir)) {
        path <- sprintf('%s/%s', path, subdir)
    }
    path
}

##
#' Return HDFS full path of the R \p dfs.x object. Accepts R HDFS object (e.g.
#' dfs.id() result), relative path (e.g. string) and itself (e.g. dfs.path() 
#' result). If \p dfs.x is of a wrong type or malformed then returns NULL.
#'
#' @param dfs.x HDFS object identifier | its name
#' @param stop invoke stop() id \p dfs.id is invalid
#'
#' @return "normalized" full path to HDFS object.
#' @return NULL wrong type or malformed \p dfs.id
##
.dfs.path <- function(dfs.x, stop=F)
{
    if (missing(dfs.x)) {
        # no path == root
        dfs.x <- '/'
    }
    else if (.is.dfs.path(dfs.x)) {
        # nothing to do
        return(dfs.x)
    }
    else if (.is.dfs.id(dfs.x)) {
        # full path already known
        path <- dfs.x[[1]]
    }
    else if (is.character(dfs.x)) {
        # expand to full path
        path <- ''
        if (substr(dfs.x,1,1) == '/') {
            path <- .dfs.root()
        }
        else {
            path <- hdfs.pwd()
        }
        if (dfs.x != '') {
            path <- paste(path, dfs.x, sep='/')
        }
        #else {
        #    path <- dfs.x
        #}
    }
    else {
        orch.dloge('wrong input type', stop=stop)
        return(NULL)
    }
    
    # All done, mark as "path" type.
    p <- .scrub.path(path)
    attr(p, 'dfs.path') <- T
    (p)
}

##
#' ???
##
.dfs.mkpath <- function(dfs.x, dfs.y)
{
    dfs.z <- .scrub.path(paste(dfs.x, dfs.y, sep='/'))
    attributes(dfs.z) <- attributes(dfs.x)
    (dfs.z)
}

##
#' Return HDFS relative to the root path of the R \p dfs.x object. 
#' If \p dfs.x is of a wrong type or malformed then returns NULL.
#'
#' @param dfs.x HDFS object identifier | its name
#' @param stop invoke stop() id \p dfs.id is invalid
#'
#' @return "normalized" relative path to HDFS object.
#' @return NULL wrong type or malformed \p dfs.id
##
.dfs.cwd <- function(dfs.x, stop=F)
{
    if (missing(dfs.x)) {
        # no path == user home
        path <- paste("user", .orch.whoami(), sep='/')
    }
    else if (.is.dfs.str(dfs.x))
    {
        dfs.x <- strim(dfs.x)
        if (begins(dfs.x, '/')) {
            # this is absolute path
            path <- substr(dfs.x, 2, nchar(dfs.x))
        }
        else if (begins(dfs.x, '~')) {
            if (substr(dfs.x,2,2) %in% c('/','')) {
                # this is the current user's home path
                user <- .orch.whoami()
                dfs.x <- substr(dfs.x, 3, nchar(dfs.x))
            }
            else {
                # this is another user's home path
                dfs.x <- substr(dfs.x, 2, nchar(dfs.x))
                div <- regexpr("/", dfs.x, fixed=T)
                if (div < 0) {
                    user <- dfs.x
                    dfs.x <- NULL
                }
                else {
                    user <- substr(dfs.x, 1, div-1)
                    dfs.x <- substr(dfs.x, div+1, nchar(dfs.x))
                }
            }
            path <- paste("user", user, dfs.x, sep='/')
        }
        else {
            # this is relative path
            cwd <- .orch.env$hdfs.cwd
            sep <- ifelse(cwd != '' && dfs.x != '', '/', '')
            path <- paste(cwd, dfs.x, sep=sep)
        }
    }
    else if (.is.dfs.path(dfs.x))
    {
        root <- .dfs.root()
        # this is a DFS obj with full path
        if (!begins(dfs.x, root)) {
            orch.dlog.stop("path is not in user's HDFS root", cat=T)
        }
        # (!) if root path is '.*/' trim one symbol less
        ii <- ifelse (ends(root, '/'), 1, 2)
        path <- substring(dfs.x, nchar(root)+ii)
    }
    else {
        orch.dloge('wrong input type', stop=stop)
        return(NULL)
    }
    
    # All done, mark as "cwd" type.
    p <- .scrub.path(path)
    attr(p, 'dfs.cwd') <- TRUE
    .assert(!begins(p, '/'))
    p
}

##
#' Return the root directory of HDFS for the current user.
#' @param subdir add sub-directory to the HDFS root path (optional)
#' @TODO (vlad) Works for local HDFS but would it work for remote?
##
.dfs.user.root <- function(subdir)
{
    path <- sprintf('/user/%s', .orch.whoami())
    if (!missing(subdir)) {
        path <- sprintf('%s/%s', path, subdir)
    }
    (path)
}

##
#' Return the currently configured as working HDFS root directory.
#' @param subdir add sub-directory to the HDFS root path (optional)
##
.dfs.root <- function(subdir)
{
    if (is.null(.orch.env$hdfs.root)) {
        .orch.env$hdfs.root <- .dfs.user.root()
    }
    path <- .orch.env$hdfs.root
    if (!missing(subdir)) {
        path <- sprintf('%s/%s', path, subdir)
    }
    (path)
}

##
#' Tries to rebuild lost metadata so this HDFS object can be used with
#' ORCH interface. Runs data analysis and returns meta description.
#' 
#' @param dfs.id HDFS object ID.
#' @param key.sep Key field separator character, "\t" default.
#' @param value.sep Value field separator character, "," default.
#' @param keyi Key column #, -1 = no key, 0 = NULL key.
#' @param trim Trim tailing empty columns.
#' @return Metadata as is should be stored in __ORCH_META__.
##
.dfs.extract.meta <- function(
    dfs.id, 
    key.sep = .orch.env$key.sep,
    value.sep = .orch.env$val.sep,
    keyi = NULL,
    trim = FALSE)
{
    # Sample data types.
    types1 <- .dfs.sample.types(
        dfs.id = dfs.id, 
        key.sep = key.sep, 
        val.sep = value.sep,
        undef = T, 
        level = 1)
    if (length(types1) == 0) {
        # if level 1 sampling failed this means that it tried _every_ part 
        # file and none of them has produces any sampling results. 
        orch.dloge("failed to extract data types from \"%s\"", 
            dfs.id, stop=T, cat=T)
    }
    if (any(types1 == '?')) {
        orch.dlog.debug("trying deep sampling, level=%d", 
            .orch.env$sample.level)
            types1 <- .dfs.sample.types(
                dfs.id = dfs.id, 
                key.sep = key.sep, 
                val.sep = value.sep, 
                undef = T, 
                level = .orch.env$sample.level)
    }
    
    # Trim option removes trailing fields suspected to be empty. This is
    # a known artifact of running ORCH on data with one or no values. Note that
    # we want to keep at least one column even if it's empty to preserve a
    # special case of "" value output.
    types2 <- types1[types1 != '']
    if (trim) {
        trimPos <- 1
        for (i in rev(seq_along(types2)[-1])) {
            if (!(types2[i] %in% c('', '?'))) {
                trimPos <- i
                break
            }
        }
        if (trimPos != length(types2)) {
            orch.dlog.debug("trimming to %d column%s", trimPos, .s(trimPos))
            length(types2) <- trimPos
        }
        else {
            trim <- FALSE
        }
    }
    
    # Convert sampled types into R types.
    for (i in seq_along(types2)) {
        tt <- types2[i]
        if (tt == '?') {
            types2[i] <- "character"
        }
        else if (tt == 'c') {
            types2[i] <- "character"
        }
        else if (tt == 'n') {
            types2[i] <- "numeric"
        }
        else if (tt == 'l') {
            types2[i] <- "logical"
        }
        else {
            orch.dlog.stop("bug")
        }
        orch.dlog.debug('type[%d] = %s', 
            i, types2[i])
    }
    
    # Identify key column index.
    .assert(length(types1) > 0)
    if (is.null(keyi)) {
        if (types1[1] == '') {
            keyi <- -1
            orch.dlog.debug('oops, no key found')
        }
        else if (types1[1] == '?') {
            keyi <- 0
            orch.dlog.debug('hmm, key is empty')
        }
        else {
            keyi <- 1
            orch.dlog.debug('yeah, field 1 is key')
        }
    }
    else {
        if (keyi < 0 && types1[1] != '') {
            orch.dlog.stop("key field was identified")
        }
        else if (keyi == 0 && types1[1] != '?') {
            orch.dlog.stop("not NULL key field was identified")
        }
        else if (keyi > 0 && types1[1] %in% c('', '?')) {
            orch.dlog.stop("key field was not identified")
        }
    }
    
    # Fix types metafield if key is missing. At this case sampled 
    # types contain one redundant data type NULL at pos [1].
    if (keyi == 0 && length(types2) > 0) {
        .assert(types2[1] == "character")
        types2 <- types2[-1]
    }

    # Assign default names to columns.
    if (length(types2) > 0) {
        names <- paste0('val', seq_along(types2))
    }
    else {
        orch.dlogw("oops, no data columns found")
        names <- character(0)
    } 
    
    # Write out restored metadata.
    meta <- list()
    attr(meta, "orch.kvs") <- TRUE
    attr(meta, "orch.types") <- types2
    attr(meta, "orch.names") <- names
    attr(meta, "orch.class") <- "data.frame"
    attr(meta, "orch.keyi") <- keyi
    attr(meta, "orch.rownamei") <- 0
    attr(meta, "orch.origin") <- "HDFS"
    attr(meta, "orch.key.sep") <- key.sep
    attr(meta, "orch.value.sep") <- value.sep
    attr(meta, "orch.trim") <- trim
    orch.dlog.attr(meta)
    
    # Return text object with metadata.
    .paste.meta(meta)
}

##
#' Samples the HDFS object and tries to figure out data types.
#' Returns a vector of: 
#'     'c' = char, 
#'     'n' = number, 
#'     'l' = number,
#' only if undef = T: 
#'     '?' = unknown type
#'     ''  = column missing
#'
#' @param dfs.id HDFS object ID
#' @param key.sep Key field separator character, "\t" default.
#' @param val.sep Value field separator character, "," default.
#' @param undef Allows undefined (e.g. '?' amd '') types to be returned, 
#'     otherwise will replace all undefined with char type (e.g. 'c') and
#'     remove missing (e.g. '') columns. You want to use this option if
#'     you need do not have any special handling of '?' and '' types.
#' @param level Sampling level to deparse the file content.
#' 
#' @return a vector with sampled data types
#' @return NULL if file can not be sampled
##
.dfs.sample.types <- function(
        dfs.id, 
        key.sep = .orch.env$key.sep,
        val.sep = .orch.env$val.sep,
        undef = TRUE,
        level = 1)
{
    # Level of sampling determines how many "part" files we are going
    # to read and parse. Level can't be higher than number of parts.
    parts <- rev(.dfs.list(dfs.id))
    if (length(parts) < level) {
        orch.dlogw("can't sample \"%s\" %d past%s, only %d",
            dfs.id, level, .s(level), length(parts))
    }
    if (length(parts) == 0) {
        orch.dloge("object \"%s\" contains no data files", 
            dfs.id, stop=T, cat=T)
    }
    
    # Select one or several files for parsing.
    sampleLines <- c()
    parts <- parts[sample(length(parts))]
    for (fname in parts) {
        tailLines <- hdfs.ftail(dfs.id, fname, n=0, tail=F)
        if (length(tailLines) > 0) {
            sampleLines <- c(sampleLines, tailLines)
            level <- level - 1
            if (level == 0) {
                break
            }
        }
        else {
            orch.dlog.debug("can't sample \"%s\", skipped", fname)
        }
    }
    if (level > 0) {
        orch.dlogw("sampling is missing %d part%s", 
            level, .s(level))
    }
    if (is.null(sampleLines)) {
        # epic fail of "dfs -tail" command here 
        orch.dloge("object \"%s\" is too large for sampling", 
            dfs.id, stop=T, cat=T)
    }
    
    orch.dlogv2(level,
        key.sep, 
        val.sep, 
        undef)
    
    # Parse N lines to determine datatypes.
    fmt <- c()
    lastN <- 0
    for (s in sampleLines) {
        key <- NA # no key
        if (key.sep != '') {
            tabPos <- regexpr(key.sep, s, fixed=T)[[1]]
            if (tabPos > 0) {
                key <- substr(s, 1, tabPos-1)
                s <- substr(s, tabPos+1, nchar(s))
            }
        }
        fields <- strsplit.eol(s, val.sep)[[1]]
        fields <- strim(c(key, fields))
        n <- length(fields)
        if (n > lastN) {
            fmt <- rep(NA, n)
        }
        lastN <- n
        if (n < 1) {
            next
        }
        for (i in 1:n) {
            if (!is.na(fmt[i]) && fmt[i] == 'c') {
                # no point in refining "char" type
                next
            }
            f <- fields[i]
            if (is.na(f)) {
                # bad input detected
                next
            }
            if (f == '') {
                if (is.na(fmt[i])) {
                    # possible empty field
                    fmt[i] <- ''
                }
                next
            }
            numTry <- suppressWarnings(as.numeric(f))
            if (!is.na(numTry)) {
                fmt[i] <- 'n'
            }
            else {
                logTry <- suppressWarnings(as.logical(f))
                if (!is.na(logTry)) {
                    fmt[i] <- 'l'
                }
                else {
                    .assert(f != '')
                    fmt[i] <- 'c'
                }
            }
        }
    }
    # at this point format has:
    # 'c' = character
    # 'n' = numeric
    # 'l' = logical
    # ''  = empty
    # NA  = failed

    # Fix unidentified data types.
    if (undef) {
        undefType <- '?'
        missType <- ''
    }
    else {
        undefType <- 'c'
        missType <- NULL
    }
    i <- 0
    fmt <- sapply(fmt, function(x) {
        i <<- i + 1
        if (is.na(x)) {
            orch.dlogw("missing column %d, using '%s' instead", 
                i, missType)
            missType
        }
        else if (x == '') {
            orch.dlogw("can't sample type of column %d, using '%s' instead", 
                i, undefType)
            undefType
        } 
        else {
            x
        }
    })
    
    # All done, enjoy.
    orch.dlog.debug('sampled meta = %s', paste(fmt,collapse=','))
    unlist(fmt)
}

##
#' List all hdfs files located in directory pointed by dfs.id which do not
#' start with '_'
##
.dfs.list <- function(dfs.id)
{
    dfsPath <- .dfs.path(dfs.id, stop=T)
    dfsFiles <- .hal.dfs.ls(dfsPath)
    if (.sh.error() != 0) {
        NULL
    }
    else {
        parts <- c()
        for (f in dfsFiles) {
            isPart <- .dfs.path.filter(f)
            if (isPart) {
                path <- rev(strsplit(f, ' ')[[1]])[1]
                file <- rev(strsplit(path, '/')[[1]])[1]
                parts <- c(parts, file)
            }
        }
        sort(parts)
    }
}

##
#' Return ORCH metadata HDFS filename.
##
.dfs.meta.file <- function(colN)
{
    sprintf("__ORCH_META__", colN)
}

##
#' Return ORCH factor levels HDFS filename.
##
.dfs.levels.file <- function(colN)
{
    sprintf("__ORCH_LEVELS_%d__", colN)
}

##
#' Returns HDFS input location.
#'
#' This function takes in one of the following as input:
#'     1 HDFS id coresponding to the HDFS directory containing the input file.
#'     2 An R object (data.frame, matrix, or vector) containing the input. 
#'       The contents will be copied over to an HDFS file.
#'     3 An ORE frame.
#'     4 A file on the local file system.
#' and returns the HDFS id coresponding to the HDFS directory containing
#' the input file. Data movement may be involved if data does not deside in
#' HDFS already. 
#'
#' @param x either an HDFS id or an R object or a local file.
#' @return HDFS id coresponding to the HDFS directory containing
#'     content of the input object
#' 
#' @seealso hdfs.put
#' @seealso hdfs.push
#' @seealso hdfs.upload
##
.dfs.from.any <- function(x)
{
    # Copy data to HDFS if needed.
    if (is.hdfs.id(x)) {
        dfs.x <- x
    }
    else if (is.data.frame(x) || is.matrix(x) || is.vector(x)) {
        dfs.x <- hdfs.put(x, rownames=FALSE)
    }
    else if (is.ore.frame(x)) {
        dfs.x <- hdfs.push(x)
    }
    else if (file.access(x, mode=4)) {
        dfs.x <- hdfs.upload(x)
    }
    else {
        orch.dlog.stop("%s is not supported", class(x))
        dfs.x <- NULL
    }
    
    # Check that everything's OK.
    if (!.is.dfs.id(dfs.x) || !hdfs.exists(dfs.x)) {
       orch.dlog.stop("failed to move [%s] to HDFS", deparse(substitute(x)))
       dfs.x <- NULL
    }
    
    # All good.
    dfs.x
}

##
#' Returns a _sorted_ list of data files in an HDFS directory.
#' 
#' @param dfs.id HDFS object identifier.
#' @param cat Show error messages to a user.
#' @return vector of file names | NULL.
##
.dfs.list.data.files <- function(
    dfs.id, 
    cat = FALSE)
{
    dfsFiles <- hdfs.ls(.dfs.path(dfs.id), pattern="^[^_.]")
    if (is.null(dfsFiles)) {
        orch.dloge("HDFS object \"%s\" has no data files", dfs.id, cat=cat)
        NULL
    }
    else {
        sort(dfsFiles)
    }
}

##
#' Returns one data file from an HDFS directory.
#' 
#' @param dfs.id HDFS object identifier.
#' @param last TRUE if the last file is required. 
#' @param cat Show error messages to a user.
#' @return file name | NULL.
##
.dfs.find.data.file <- function(
    dfs.id, 
    last = FALSE, 
    cat = FALSE)
{
    dfsFiles <- .dfs.list.data.files(dfs.id, cat)
    if (!is.null(dfsFiles)) {
        if (last) {
            dfsFiles[length(dfsFiles)]
        } else {
            dfsFiles[1]
        }
    }
    else {
        NULL
    }
}

##
#' create the map.output parameter from the input metadata
##
.orch.outputmeta <- function(input)
{
 mdata     <- hdfs.mget(input)
 if (is.null(mdata)) {
   orch.dlog.stop("metadata is null")
 }
 columns   <- .parse.meta(list(), mdata)
 colNames  <- attr(columns, "orch.names")
 colTypes  <- attr(columns, "orch.types")
 dfstr <- sprintf("data.frame(%s, stringsAsFactors = FALSE)",
                   paste(colNames,"=",
                     sapply(colTypes, function(x)
                                         switch(x,"numeric"=,"integer"= 0,
                                          "logical"=TRUE,
                                          "character"="''",
                                          "factor"="as.factor('')", "''"),
                                          USE.NAMES=FALSE),
                   sep="",
                   collapse=","))
 # return the data frame
 eval(parse(text = dfstr))
}

## ------------------------------------------------------------------------- ##
##                          HDFS PUBLIC FUNCTIONS                            ##
## ------------------------------------------------------------------------- ##

##
#' Establishes connection to Hadoop's HDFS.
#' @attention Available only in ORCH v2.0 and above.
#'
#' By default ORCH uses default HDFS connection as it's configures in local
#' Hadoop client setup (see <hadoop_dir>/conf/hdfs-site.xml). Client can switch
#' to another HDFS cluster if required via this function.
#' After the connection is established it is validated by reading file system 
#' properties. Displays connection attributes and error message if there was a
#' problem detected.
#' There are two connection modes: local and ssh. In the local mode ORCH expects 
#' Hadoop client software to be installed on the local machine and available via 
#' the command line. If the ssh mode ORCH will use ssh tunneling to execute 
#' Hadoop HDFS commands on a remote machine as configured by the rest of options.
#'
#' @param host the host name or IP address of the Hadoop NameNode
#' @param user the Hadoop user name (ssh only)
#' @param passwd the Hadoop password, default NONE (ssh only)
#' @param mode 'local'|'ssh' mode, see description
#' @param proto HDFS connection protocol to use (local only)
#' @param secure prompt user to enter a password, default TRUE (ssh only)
#'
#' @return TRUE if connection was successfully established and validated
#' @return FALSE if connection has failed
#'
#' @seealso hdfs.disconnect
#' @seealso hdfs.reconnect
##
hdfs.connect <- function(
    host = NULL,
    user = NULL,
    passwd = NULL,
    proto = 'hdfs',
    mode = 'local',
    secure = T)
{
    orch.dlog.stop('not implemented')
    #' @TODO (vlad) implement hdfs.connect()
}

##
#' Disconnect from Hadoop's HDFS.
#' @attention Available only in ORCH v2.0 and above.
#'
#' Drops connection to HDFS. It rolls back connection to the default one as
#' it's setup in the local Hadoop client configuration.
#'
#' @return HDFS connection object. The object can be used to connect to 
#'     HDFS once again with hdfs.reconnect function. If the HDFS wasn't 
#'     connected then returns NULL.
#'
#' @seealso hdfs.connect
#' @seealso hdfs.reconnect
##
hdfs.disconnect <- function()
{
    orch.dlog.stop('not implemented')
    #' @TODO (vlad) implement hdfs.disconnect()
}

##
#' Reconnects to the previous disconnected Hadoop HDFS.
#'
#' After the HDFS connection was reset ORCH preserves all its attributes. 
#' You can reconnect to the previously disconnected HDFS session and continue 
#' R<->HDFS data transfer operations with this function.
#' Reconnection is less expencive than hdfs.connect because it does not 
#' perform extensive connectivity checks as the initial connect does. Only 
#' a quick connection test is performed.
#'
#' @param dfs.con the stored HDFS connection (result of hdfs.disconnect)
#' @return TRUE if reconnection was successfully established and validated
#'     or FALSE if reconnection has failed.
#'
#' @seealso hdfs.connect
#' @seealso hdfs.disconnect
##
hdfs.reconnect <- function(dfs.con)
{
    orch.dlog.stop('not implemented')
    #' @TODO (vlad) implement hdfs.reconnect()
}

##
#' Displays information about current HDFS connection.
#'
#' @seealso hdfs.connect
#' @seealso hdfs.disconnect
#' @seealso hdfs.reconnect
##
hdfs.info <- function()
{
    orch.dlog.stop('not implemented')
    #' @TODO (vlad) implement hdfs.info()
}

##
#' Copies data from RDBMS to HDFS.
#'
#' The input object is of ore.frame type and returns a HDFS object identifier 
#' which can be used in further HDFS/Hadoop function calls. Pushing of data is
#' normally done by starting a number of map-reduce jobs which pull data out
#' of the database in parallel and store it into HDFS set of files.
#'
#' If orch.connect() was invoked in secure mode, then, this API will prompt 
#' the user to enter database password. The password is held encrypted in 
#' memory and transferred to an on-disk configuration file for use by sqoop. 
#' This is the way sqoop is invoked in general in the batch mode as well. If 
#' orch.connect() was invoked in secure=F mode,then the password entered 
#' earlier would have been kept encrypted in memory and transferred to the 
#' sqoop configuration file on disk. The configuration file gets destroyed 
#' automatically once sqoop has read it. This is made possible by the fact 
#' that we create the configuration file as a temporary-unlinked file on 
#' Linux.
#'
#' @attention Data copying is executed synchronously and large datasets can 
#'     "hang" R environment for a while. Asynchnous push function will be 
#'     available in the next release.
#
#' @param x ore.frame to push into HDFS
#' @param dfs.name custom name to assign the HDFS object
#' @param overwrite allows overwriting of HDFS objects with the same name
#' @param driver choose RDBMS to HDFS data transfer driver, "sqoop" by default
#' @param split.by specifies the column to use for data partitioning (optional)
#'
#' @return HDFS object identifier if data was successfully exported or NULL 
#'     if transfer error has occured.
#
#' @seealso hdfs.pull
#' @seealso hdfs.put
#' @seealso hdfs.get
##
hdfs.push <- function(
        x,
        key = NULL,
        dfs.name = NULL,
        sep = ',',
        overwrite = FALSE,
        driver = 'sqoop',
        split.by = NULL)
{
    # Check inputs.
    .orch.test.special.stop(x, "ore.frame", is.ore.frame)
    .orch.ntest.input.stop(key, "string")
    .orch.ntest.input.stop(dfs.name, "string")
    .orch.test.input.stop(sep, "string")
    .orch.test.input.stop(overwrite, "logical")
    .orch.test.input.stop(driver, "word")
    .orch.ntest.input.stop(split.by, "string")
    if (!.orch.is.hivetable(x)) {
        orch.dlog.stop("input [x] cannot be a HIVE table")
    }
   
    # Set defaults.
    if (is.null(dfs.name)) {
        dfs.name <- .orch.uid()
        orch.dlog.debug("HDFS object name is not specified, using \"%s\"", dfs.name)
    }
	
    # Check that we have the requested driver.
    pushFn <- sprintf('.%s.push', driver)
    if (!exists(pushFn)) {
        orch.dlog.stop("driver for %s is not available", driver)
        return (NULL)
    }
    
    cols <- names(x)
    coln <- length(cols)
    orch.dlogv(coln)
    
    # We need to split column for Sqoop to run a query export.
    if (is.null(split.by)) {
        split.by <- 'ROWNUM'
    }
    else if (is.numeric(split.by)) {
        if (split.by < 1 || split.by > coln) {
            stop("split column index is out of bounds")
        }
        split.by <- cols[split.by]
    }
    else {
        if (!any(cols==split.by)) {
            stop("split column name is invalid")
        }
    }
    
    # Identify the key column.
    keyi <- 0
    if (!is.null(key)) {
        if (is.numeric(key)) {
            keyi <- key
            if (keyi < 1 || keyi > coln) {
                orch.dlog.stop("key column index is out of bounds")
            }
        }
        else {
            keyi <- which(cols == key)
            if (is.na(keyi)) {
                orch.dlog.stop("invalid key column name")
            }
        }
    }
    orch.dlogv(keyi)
    
    # This piece of code was stolen from ORE :-).
    qry <- paste(
        "select * from (",
        "with", paste(x@dataQry, collapse=','),
        "select", paste('"', names(x), '"', sep='', collapse=','),
        "from", sprintf("obj%s", x@dataObj),
        "where $CONDITIONS)")
    if (is.null(dfs.name)) {
        dfs.name <- .orch.uid()
    }
    
    # Move key column to the front, e.g. row 1.
    if (keyi > 1) {
        keyCols <- paste(
            c(cols[keyi], 
                cols[1:(keyi-1)]),
            sep=',',
            collapse=',')
        if (keyi < coln) {
            keyCols <- paste(
                c(keyCols, 
                    cols[(keyi+1):coln]), 
                sep=',',
                collapse=',')
        }
        qry <- paste(
            'select', keyCols,
            'from (', qry, ')',
            sep=' ')
    }
    
    # Okay, now let's try to import data into HDFS.
    orch.dlogq(qry)
    dfs.id <- do.call(pushFn, list(
            db.query = qry, 
            dfs.name = .dfs.path(dfs.name), 
            overwrite = overwrite, 
            split.by = split.by,
            sep = sep))
    if (!hdfs.exists(dfs.id)) {
        # @TODO: (vlad) log message here
        dfs.id <- NULL
    }
    
    # Attach metadata to the HDFS object.
    if (!is.null(dfs.id)) {
        # "keyval"-type metadata
        attr(x, 'orch.kvs') <- TRUE
        attr(x, 'orch.names') <- colnames(x)
        attr(x, 'orch.rownamei') <- 0
        attr(x, 'orch.class') <- "data.frame"
        attr(x, 'orch.types') <- x@desc$Sclass
        attr(x, 'orch.keyi') <- -1 #no key
        attr(x, 'orch.key.sep') <- sep
        attr(x, 'orch.value.sep') <- sep
        # ore.frame specific attributes
        attr(x, 'orch.desc.name') <- x@desc$name
        attr(x, 'orch.desc.Sclass') <- x@desc$Sclass
        attr(x, 'orch.desc.type') <- x@desc$type
        attr(x, 'orch.desc.len') <- x@desc$len
        attr(x, 'orch.desc.precision') <- x@desc$precision
        attr(x, 'orch.desc.scale') <- x@desc$scale
        attr(x, 'orch.desc.isVarLength') <- x@desc$isVarLength
        attr(x, 'orch.desc.nullOK') <- x@desc$nullOK
        # write __METADATA__ file, returns NULL if failed
        dfs.id <- hdfs.mput(
            dfs.id = dfs.id,
            meta = .paste.meta(x))
    }
    
    # All good.
    dfs.id
}

##
#' Copies data from HDFS to RDBMS.
#'
#' Input object is a HDFS object identifier and the function returns an 
#' ore.frame object which points to a new table with loaded data from HDFS.
#' Pulling of data is normally done by starting a number of map-reduce jobs 
#' which read data from HDFS and insert into the database in parallel.
#'
#' If orch.connect() was invoked in secure mode, then, this API will prompt 
#' the user to enter database password. The password is held encrypted in 
#' memory and transferred to an on-disk configuration file for use by sqoop. 
#' This is the way sqoop is invoked in general in the batch mode as well. If 
#' orch.connect() was invoked in secure=F mode,then the password entered 
#' earlier would have been kept encrypted in memory and transferred to the 
#' sqoop configuration file on disk. The configuration file gets destroyed 
#' automatically once sqoop has read it. This is made possible by the fact 
#' that we create the configuration file as a temporary-unlinked file on 
#' Linux.
#'
#' @attention Data copying is executed synchronously and large datasets can 
#'     "hang" R environment for a while. Asynchronous push function will be 
#'     available in the next release.
#'
#' @param dfs.id HDFS object identifier
#' @param sep HDFS value fields separator
#' @param db.name optional database table name
#' @param overwrite remove an existing table, FALSE by default
#' @param driver database export driver, "sqoop" by defalut
#'
#' @return ore.frame object pointing to the exported dataset or NULL is 
#'     something went terribly wrong.
#'
#' @seealso hdfs.push
#' @seealso hdfs.put
#' @seealso hdfs.get
##
hdfs.pull <- function(
    dfs.id,
    db.name = NULL,
    overwrite = FALSE,
    driver = 'sqoop')
{
    # Check inputs.
    .orch.test.special.stop(dfs.id, "HDFS object", .is.dfs.id)
    .orch.ntest.input.stop(db.name, "string")
    .orch.test.input.stop(overwrite, "logical")
    .orch.test.input.stop(driver, "string")
    
	# Set defaults and normalize input values.
	if (is.null(db.name)) {
		db.name <- basename(dfs.id)
		orch.dlog.debug("using HDFS object name \"%s\" as RDBMS name", db.name)
	}
	db.name <- oraname(db.name)
	dfs.name <- .dfs.path(dfs.id)
	
    # Check that we have the requested driver.
    pullFn <- sprintf('.%s.pull',driver)
    if (!exists(pullFn)) {
        orch.dlog.stop("driver for %s is not available", driver)
        return (NULL)
    }
    
    meta <- hdfs.mget(dfs.id)
    if (is.null(meta)) {
        # Sample and set SQL datatypes.
        orch.dlogw("missing metadata, sampling")
        key.sep <- .orch.env$key.sep
        val.sep <- .orch.env$val.sep
        fmt <- .dfs.sample.types(dfs.id, 
            key.sep = key.sep,
            val.sep = val.sep,
            undef = F)
        for (i in 1:length(fmt)) {
            if (fmt[i] == 'c') {
                fmt[i] <- 'VARCHAR2(1000)'
            }
            else if (type[i] == 'n') {
                type[i] <- 'NUMBER'
            }
            else if (type[i] == 'l') {
                type[i] <- 'BOOLEAN'
            }
            else {
                orch.dlogw("column #%d dropped from SQL CREATE", i)
                type[i] <- NA
            }
        }
        # Format query specification.
        spec <- ''
        for (i in 1:length(fmt)) {
            spec <- paste(spec, 
                ',', 'VAL', i, 
                ' ', fmt[i], 
                sep = '')
        }
        spec <- substring(spec, 2)
    }
    else
    {
        # User metadata to set SQL datatypes.
        x <- .parse.meta(list(), meta)
        
        # Read delimiters.
        key.sep <- attr(x, "orch.key.sep")
        val.sep <- attr(x, "orch.value.sep")
        if (is.null(key.sep)) {
            key.sep <- .orch.env$key.sep
            orch.dlogw("missing key separator, used default %s", key.sep)
        }
        if (is.null(val.sep)) {
            val.sep <- .orch.env$val.sep
            orch.dlogw("missing value separator, used default %s", val.sep)
        }
        if (key.sep != val.sep) {
            orch.dlog.stop("%s%s",
                "this object can not be exported to RDBMS, ",
                "different key and value delimiters")
            return (NULL)
        }
        
        # Read column types.
        type <- attr(x, 'orch.desc.type')
        if (is.null(type)) {
            fmt <- .dfs.sample.types(dfs.id, 
                key.sep = key.sep,
                val.sep = val.sep,
                undef = F)
            for (i in 1:length(type)) {
                if (type[i] == 'c') {
                    type[i] <- 'VARCHAR2'
                }
                else if (type[i] == 'n') {
                    type[i] <- 'NUMBER'
                }
                else if (type[i] == 'l') {
                    type[i] <- 'BOOLEAN'
                }
                else {
                    orch.dlogw("column #%d dropped from SQL CREATE", i)
                    type[i] <- NA
                }
            }
            type <- type[!is.na(type)]
        }
        len <- attr(x, 'orch.desc.len')
        if (is.null(len)) {
            len <- rep(1000, length(type))
        }
        prcs <- attr(x, 'orch.desc.precision')
        if (is.null(prcs)) {
            prcs <- rep(0, length(type))
        }
        scale <- attr(x, 'orch.desc.scale')
        if (is.null(scale)) {
            scale <- rep(0, length(type))
        }
        name <- attr(x, 'orch.names')
        if (is.null(name)) {
            name <- rep('', length(type))
            for (i in 1:length(type)) {
                name[i] <- sprintf('VAL%d', i)
            }
        }
        # Format query specification.
        spec <- ''
        for (i in 1:length(type)) {
            if (type[i] == 'VARCHAR2') {
                sqlType <- sprintf('VARCHAR2(%d)', len[i])
            }
            else if (type[i] == 'NUMBER') {
                if (!prcs[i]) {
                    numFmt <- 'NUMBER'
                }
                else if (!scale[i]) {
                    numFmt <- 'NUMBER(%d)'
                }
                else if (prcs[i] == 38 && 
                    scale[i] == 127) {
                    # fix for ore.frame description
                    numFmt <- 'NUMBER'
                }
                else {
                    numFmt <- 'NUMBER(%d,%d)'
                }
                sqlType <- sprintf(numFmt, prcs[i], scale[i])
            }
            else {
                sqlType <- sprintf(
                    paste('%s', 
                        ifelse(len[i]!='', '(%d)', ''), 
                        sep=''), 
                    type[i], len[i])
            }
            spec <- paste(spec, 
                ',', name[i], 
                ' ', sqlType,
                sep='')
        }
        spec <- substring(spec, 2)
    }
    
    # Execute import!
    do.call(pullFn, list(
            dfs.id = dfs.id,
            db.spec = spec,
            db.name = db.name, 
            overwrite = overwrite,
            sep = val.sep))
}

##
#' Uploads a local file into HDFS.
#
#' This is the simplest and fastest possible way to transfer data to HDFS from 
#' a local storage. It just replicates the local file into HDFS directory. By 
#' default the HDFS directory get a unique ID and the HDFS file(s) is named 
#' "part-0000x". If the local file is larger then \p split.size bytes the file 
#' automatically gets split into several parts.
#' 
#' Delimiters \p key.sep and \p value.sep are specified only as a "hint". ORCH 
#' will copy a local file as-is anyway and will automatically create its 
#' metadata with the delimiters specified. The content of the file copied into 
#' HDFS will not change. If you specify incorrect set of delimiters then attach 
#' of the copied will fail. If you do not specify the delimiters then current 
#' defaults will be used.
#'
#' @param filename Local file name to put to HDFS.
#' @param dfs.name How to name the HDFS directory or dfs.id.
#' @param overwrite Replace HDFS directory if already exists.
#' @param split.size Size if bytes of each "part-*" HDFS file or 0 to do not split.
#' @param key.sep key field separator character, "\t" default.
#' @param value.sep value field separator character, "," default.
#' @param header TRUE if local file has header (1st line).
#' @param attach Automatically attach the uploaded file as HDFS object.
#'
#' @return HDFS object ID of the loaded data | NULL if error
#' @note The loaded data gets metadata generated automatically.
#'
#' @seealso hdfs.download
#' @seealso hdfs.put
#' @seealso hdfs.get
##
hdfs.upload <- function(
    filename,
    dfs.name = NULL, 
    overwrite = FALSE,
    split.size = .orch.env$split.size,
    key.sep = .orch.env$key.sep,
    value.sep = .orch.env$val.sep,
    header = FALSE,
    attach = TRUE)
{
    # Check input parameters
    .orch.test.input.stop(filename, "string")
    .orch.ntest.input.stop(dfs.name, "string")
    .orch.test.input.stop(overwrite, "logical")
    .orch.ntest.input.stop(split.size, "numeric")
    .orch.test.input.stop(header, "logical")
    .orch.test.input.stop(attach, "logical")
    
    # Don't remove those files:
    persist <- filename
    
    # Remove header line if files have one (param [header]). To remove 1st 
    # line we have to copy the whole file(s) to a temporary one via awk.
    ok <- T
    if (header) {
        files <- c()
        for (f in filename) {
            if (!file.exists(f)) {
                orch.dloge("file does not exist")
                ok <- F
                break
            }
            tmpf <- .orch.tmpfile()
            out <- .sh('awk \'{if (NR>1) print $0}\' "%s" > "%s"', f, tmpf)
            if (out != '') {
                orch.dloge('preprocessing error')
                ok <- F
                break
            }
            files <- c(files, tmpf)
        }
        if (!ok && !.orch.env$keep.tmp) {
            for (f in files) {
                .sh('rm -rf "%s"', f)
            }
            return(NULL)
        }
        else {
            filename <- files
        }
    }
    
    # Split the input file(s) into smaller parts. The splitting is relying on
    # approximation that a line lenght is normally distributed accross the file
    # e.g. n-lines vs size correlation is close to linear.
    files <- c()
    ok <- T
    for (f in filename)
    {
        fi <- file.info(f)
        if (is.na(fi$size)) {
            stop("file does not exist")
        }
        if (split.size > 0 && fi$size > split.size)
        {
            # Compute one part size as # of lanes per part.
            out <- .sh('wc -l "%s"', f)
            if (.sh.error() != 0) {
                orch.dlog.stop("failed to count number of lines in \"%s\"", 
                    f, cat=T)
            }
            lineCnt <- as.numeric(strsplit(strim(out), ' ')[[1]][1])
            if (is.na(lineCnt)) {
                orch.dlog.stop("unexpected result of counting number of lines in \"%s\"", 
                    f, cat=T)
            }
            partCnt <- round(fi$size / split.size) + 1
            splitLn <- round(lineCnt / partCnt)
            
            # Split file into N parts at newline character.
            tmpf <- .orch.tmpfile()
            out <- .sh('split -l %.0f "%s" "%s"', splitLn, f, tmpf)
            if (out != '') {
                # "split" returns nothing if all good
                orch.dloge('can\'t split large file')
                .sh('rm -rf "%s"*', tmpf)
                ok <- F
                break
            }
            else {
                # "split" outputs a set of files with posfixes 'aa','ab', etc.
                # we replace input filename with splitted file names.
                f <- .sh('ls "%s"*', tmpf)
                splitInfo <- sapply(f, file.info)
                splitSize <- sum(unlist(splitInfo['size',]))
                if (splitSize != fi$size) {
                    orch.dloge('split size does not match')
                    .sh('rm -rf "%s"*', tmpf)
                    ok <- F
                    break
                }
            }
        }
        files <- c(files, f)
    }
    
    # Load file(s) to HDFS.
    dfs.id <- NULL
    if (length(files) > 0 && ok)
    {
        # Load several parts of the file to HDFS. HDFS files are named as 
        # "part-X" where X is a sequential number from 0 to N split parts.
        if (is.null(dfs.name)) {
            dfs.name <- .orch.uid()
        }
        i <- 0
        for (f in files) {
            dfs.id <- hdfs.fput(
                filename = f, 
                dfs.name = dfs.name, 
                dfs.file = sprintf('part-%05d', i),
                overwrite = overwrite)
            if (is.null(dfs.id)) {
                orch.dloge('error uploading to HDFS')
                hdfs.rm(dfs.name)
                dfs.name <- NULL
                break
            }
            i <- i+1
        }
        
        # Automatically attach the uploaded file
        if (!is.null(dfs.name) && attach) {
            dfs.id <- hdfs.attach(
                dfs.name,
                key.sep = key.sep,
                value.sep = value.sep)
        }
    }
    
    # Cleanup and return resulting HDFS ID.
    if (!.orch.env$keep.tmp) {
        for (f in files) {
            if (!(f %in% persist)) {
                .sh('rm -rf "%s"', f)
            }
        }
    }
    # NULL == failure, otherwise OK.
    dfs.id
}

##
#' Downloads an HDFS file to the local file system.
#
#' This is the simpiest and fastest possible way to transfer data from HDFS to 
#' the local storage. It just replicates HDFS directory part-0000x files into
#' the local file by combining all part-0000x files as one.
#'
#' @param dfs.id HDFS objecy identifier.
#' @param filename Local file name to put to HDFS.
#' @param overwrite Replace local files if already exists.
#'
#' @return local file name of the downloaded data | NULL if error.
#' @note The downloaded data is formatted as-is in HDFS.
#' 
#' @note The function will abort instead of returning NULL if HDFS object 
#'     does not exist or local file already exists and overwrite == FALSE.
#'     Both are considered invalid preconditions.
#'
#' @seealso hdfs.upload
#' @seealso hdfs.put
#' @seealso hdfs.get
##
hdfs.download <- function(
        dfs.id,
        filename = NULL,
        overwrite = FALSE)
{
    # Check input parameters.
    .orch.test.special.stop(dfs.id, "HDFS object", .is.dfs.id_or_path)
    .orch.ntest.input.stop(filename, "string")
    .orch.ntest.input.stop(overwrite, "logical")
    
    # Check target local files.
    if (is.null(filename)) {
        filename <- .orch.tmpfile()
    }
    if (!overwrite && file.exists(filename)) {
        orch.dlog.stop("local file \"%s\" already exists", filename)
    }
    
    # List all HDFS data files.
    dfsPath <- .dfs.path(dfs.id, stop=T)
    dfsFiles <- .hal.dfs.ls(dfsPath)
    if (.sh.error() != 0) {
        orch.dlog.stop("HDFS path \"%s\" does not exists", dfsPath)
    }
    parts <- c()
    for (f in dfsFiles) {
        is.part <- .dfs.path.filter(f)
        if (is.part) {
            path <- rev(strsplit(f, ' ')[[1]])[1]
            file <- rev(strsplit(path, '/')[[1]])[1]
            parts <- c(parts, file)
        }
    }
    if (!is.null(parts)) {
        parts <- sort(parts)
    }
    
    # Get data from all part-xx file.
    ok <- T
    if (is.null(parts)) {
        # HDFS path contains no data files.
        orch.dlogw("HDFS object has no data", cat=T)
        ok <- file.create(filename)
        if (!ok) {
            orch.dloge("failed to touch local file \"%s\"", 
                filename, cat=T)
        }
    }
    else if (length(parts) == 1) {
        # one-part copy can be done directly to the final file.
        res <- hdfs.fget(
            dfs.id = dfs.id, 
            dfs.file = parts,
            filename = filename, 
            overwrite = overwrite)
        if (is.null(res)) {
            orch.dloge("HDFS failed to get file \"%s\"", parts, cat=T)
            ok <- F
        }
    }
    else {
        # multi-part copy pulls data part-by-part and cat it 
        # all together into the final resulting file.
        if (overwrite) {
            .sh('rm -rf "%s"', filename)
        }
        for (f in parts) {
            tmpfn <- .orch.tmpfile()
            res <- hdfs.fget(
                dfs.id = dfs.id, 
                dfs.file = f,
                filename = tmpfn, 
                overwrite = FALSE)
            if (is.null(res)) {
                orch.dloge("HDFS failed to get file \"%s\"", f, cat=T)
                ok <- F
                break
            }
            out <- .sh('cat "%s" >> "%s"', tmpfn, filename)
            if (!.orch.env$keep.tmp) {
                .orch.unlink(tmpfn)
            }
            if (.sh.error() != 0) {
                orch.dloge("local FS failed to copy data", cat=T)
                ok <- F
                break
            }
        }
    }
    
    # Validate, cleanup and retun result.
    if (ok) {
        fi <- file.info(filename)
        if (fi$size != hdfs.size(dfs.id)) {
            orch.dloge("downloaded file size does not match", cat=T)
            ok <- F
        }
    }
    if (!ok && !is.null(filename)) {
        .sh('rm -rf "%s"', filename)
        filename <- NULL
    }
    filename
}

##
#' Copies data from R in-memory object (data.frame) to HDFS.
#'
#' Copies data from R in-memory object (data.frame) to HDFS. All data 
#' attributes like column names, data types, etc. get stored as metadata 
#' along side with the data itself. The difference with hdfs.push is that 
#' if your supply ore.frame as input to this function then the data 1st 
#' will be pulled into the local R memory and then loaded to HDFS.
#
#' @param x data.frame (or other supported data type) to export into HDFS.
#' @param key name or index of the column which represent key value.
#' @param dfs.name custom name to assign the HDFS object (optional).
#' @param overwrite allows overwriting of HDFS objects with the same name.
#' @param rownames store row names as a data column in HDFS.
#' @param categorize store "factor" columns as numbers.
#' @param key.sep key field separator character, "\t" default.
#' @param value.sep value field separator character, "," default.
#'
#' @return HDFS object identifier if all good or
#' @return NULL if transfer error occurred
#'
#' @seealso hdfs.get
#' @seealso hdfs.download
#' @seealso hdfs.upload
##
hdfs.put <- function(
        data,
        key = NULL,
        dfs.name = NULL, 
        overwrite = FALSE,
        rownames = FALSE,
        categorize = FALSE,
        key.sep = .orch.env$key.sep,
        value.sep = .orch.env$val.sep,
        digits = .orch.env$digits)
{
    # Check inputs.
    .orch.test.special.stop(data, "container", function(x) {
            is.data.frame(x) ||
            is.matrix(x) ||
            is.vector(x) ||
            is.list(x) ||
            is.ore.frame(x)
        })
    .orch.ntest.input.stop(key, c("character", "numeric", "NA"))
    .orch.ntest.input.stop(dfs.name, "string")
    .orch.test.input.stop(overwrite, "logical")
    .orch.test.input.stop(rownames, "logical")
    .orch.test.input.stop(categorize, "logical")
    .orch.test.input.stop(key.sep, "char")
    .orch.test.input.stop(value.sep, "char")
    .orch.test.input.stop(digits, "numeric")
    dataName <- deparse1(substitute(data), control=c())
    
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    orch.dbg.newtimer()
    
    # Check that we are ready to copy data to HDFS at all.
    if (!is.null(dfs.name) && hdfs.exists(dfs.name)) {
        if (overwrite) {
            hdfs.rmdir(dfs.name)
        }
        else {
            orch.dloge('"%s" already exists in HDFS', dfs.name, cat=T)
            return (NULL)
        }
    }
    
    # Support for non-data.frame types. Drop any pre-convertion code here.
    # Types supported natively are: data.frame, matrix, vector, list.
    if (is.ore.frame(data)) {
        data <- ore.pull(data)
    }
    
    # Validate the key column.
    keyi <- 0
    if (is.null(key)) {
        orch.dlog.info("keyless data output mode")
        keyi <- -1
    }
    else {
        if (is.numeric(key)) {
            keyi <- key
            if (keyi < 1 || keyi > length(data)) {
                orch.dlog.stop("key column is out of bounds")
                return (NULL)
            }
        }
        else if (is.na(key)) {
            orch.dlog.info("keyless data output mode")
            keyi <- -1
        }
        else if (is.character(key)) {
            if (key == "") {
                orch.dlog.info("empty-key data output mode")
                keyi <- 0
            }
            else {
                keyi <- which(names(data) == key)
                if (!length(keyi)) {
                    orch.dlog.stop("no such key column")
                }
            }
        }
    }
    orch.dlogv(keyi)
    orch.dlogt()
    
    # If categorization is required then convert all "factor" data columns 
    # into numeric values and keep original levels for saving then to HDFS 
    # as a sidecar file at the end.
    if (categorize)
    {
        if (!is.data.frame(data)) {
            orch.dloge("categorization of %s is not supported", 
                class(data), cat=T)
            return (NULL)
        }
        colLvl <- list()
        ctgCount <- 0L
        for (i in seq_along(data)) {
            col <- data[[i]]
            if (is.factor(col)) {
                colLvl[[i]] <- levels(col)
                data[[i]] <- as.integer(col)
                orch.dlogd("categorized column %d \"%s\"", i, names(data)[i])
                ctgCount %+=% 1L
            }
        }
        if (ctgCount == 0) {
            orch.dlog.info("nothing to categorize")
            categorize <- FALSE
        }
        else {
            orch.dlog.info("%d column%s of %d categorized", 
                ctgCount, .s(ctgCount), length(data))
        }
        orch.dlogt("categorization done")
    }
    
    # Write to a text buffer. Attention! Do not use format() or cat() as 
    # they will round float values to 7 (default) digits after dot. Functions 
    # like paste() and as.character() are OK to use.
    if (is.data.frame(data) || 
            is.matrix(data) || 
            is.vector(data))
    {        
        # Fast data dump of "simple" R data types. Improves performance over 
        # the generic "as.keyvals" (see below) code path 10+ fold but supports
        # only strucutred data types.
        orch.dlog.info("using fast CSV dump code for %s", class(data))
        if (is.vector(data)) {
            tab <- as.matrix(data)
        } else {
            .assert(is.matrix(data) || is.data.frame(data))
            tab <- data
        }
        rown <- nrow(tab)
        if (rown == 0) {
            orch.dlog.stop("no data to output")
            return (NULL)
        }
        coln <- ncol(tab)
        colNames <- c()
        if (rownames) {
            colNames <- rownames(tab)
            if (is.null(colNames)) {
                colNames <- seq_along(rown)
            }            
        }
        # NOTE: paste() and c() (if any argument is characte) both convert 
        # float|double types to character with 14 digits precision max. At the 
        # same time format(), cat() can output up to 22 digits after dot.
        trimAttr <- FALSE
        lines <- character()
        if (keyi > 0) {
            if (coln > 1 && rown > 0) {
                orch.dlogd("code path 1,1,1")
                cols <- seq_len(coln)[-keyi]
                lines <- paste0(
                    format(tab[,keyi],
                        trim = TRUE,
                        justify = "none", 
                        digits = digits),
                    key.sep, tab[,cols[1]])
                for (i in cols[-1]) {
                    lines <- paste0(
                        lines, value.sep,
                        format(tab[,i], 
                            trim = TRUE,
                            justify = "none", 
                            digits = digits))
                }
                if (!is.null(colNames)) {
                    lines <- paste0(lines, values.sep, colNames)
                }
            }
            else {
                .assert(keyi == 1 && coln == 1)
                orch.dlogd("code path 1,1,2")
                lines <- paste0(
                    format(tab[,1], 
                        trim = TRUE,
                        justify = "none", 
                        digits = digits), 
                    key.sep)
                if (!is.null(colNames)) {
                    lines <- paste0(lines, colNames)
                }
                else {
                    # the gonna be an extra "value" column produced which due to
                    # "key\t" output format. This column has to be trimmed out
                    # when we are reading data back.
                    trimAttr <- TRUE
                }
            }
        }
        else {
            .assert(coln > 0)
            key.sep <- ifelse(keyi < 0, '', key.sep)
            if (coln > 1 && rown > 0) {
                orch.dlogd("code path 1,2,1")
                cols <- seq_len(coln)
                lines <- paste0(key.sep,
                    format(tab[,cols[1]], 
                        trim = TRUE,
                        justify = "none", 
                        digits = digits))
                for (i in cols[-1]) {
                    lines <- paste0(
                        lines, value.sep,
                        format(tab[,i], 
                            trim = TRUE,
                            justify = "none", 
                            digits = digits))
                }
                if (!is.null(colNames)) {
                    lines <- paste0(lines, values.sep, colNames)
                }
            }
            else {
                .assert(coln == 1)
                orch.dlogd("code path 1,2,2")
                lines <- paste0(key.sep, 
                    format(tab[,1], 
                        trim = TRUE,
                        justify = "none", 
                        digits = digits))
                if (!is.null(colNames)) {
                    lines <- paste0(lines, values.sep, colNames)
                }
            }
        }
        
        # "Simulate" keyvals object for the rest of the code.
        data <- .get.meta(data, keyi, rownames)
        attr(data, "orch.trim") <- trimAttr
    }
    else
    {
        # Generic data dump path for "unspecialized" data. Converts input data 
        # into "keyval"-type structure first and the writes it into a buffer
        # per each list value. The idea is that any R type can be converted into
        # keyvals via extendable .any.as.keyvals() function.
        orch.dlog.info("using generic CSV dump code for %s", class(data))
        data <- .any.as.keyvals(data, i=keyi, rownames)
        orch.dlogt("coverted to keyvals")
        
        # Write keyval objects into a text buffer. Attention! Do not use format() 
        # or cat() as they will round float values to 7 (default) digits after 
        # dot. Functions like paste() and as.character() are OK to use.
        orch.dlogd("code path 2")
        key.sep <- ifelse(keyi < 0, '', key.sep)
        lines <- paste0(
            lapply(data,
                function(x) {
                    kv <- .make.keyval(x, i=1)
                    val <- sapply(kv$val, as.character)
                    paste(kv$key, 
                        paste0(val, collapse=value.sep), 
                        sep = key.sep)
                    }),
                '\n',
                collapse = '')
    }
    orch.dlogt("wrote to a buffer")
    
    # Write data to a local temp file.
    tmpf <- .orch.tmpfile()
    writeLines(
        text = lines,
        con = tmpf,
        sep = "\n",
        useBytes = F)
    orch.dlogt("wrote to file")
    
    # Load data to HDFS via local temp file.
    dfs.id <- hdfs.fput(
        filename = tmpf, 
        dfs.name = dfs.name,
        overwrite = overwrite)
    if (is.null(dfs.id)) {
        orch.dloge("error copying data to HDFS")
        return (NULL)
    }
    if (is.null(dfs.name)) {
        dfs.name <- basename(dfs.id)
    }
    orch.dlogt("called hdfs.fput")
    
    # Remove the local temp file.
    if (!.orch.env$keep.tmp) {
        .orch.unlink(tmpf)
    }
    
    # Write categorization "sidecard" data to HDFS to preserve original 
    # "factor" data. This will create one side file for each "factor" columns
    # names "__ORCH_LEVELS_#__", where # is the data column number.
    if (categorize && length(colLvl) > 0) 
    {
        t <- attr(data, "orch.types")
        for (i in seq_along(colLvl)) {
            lvl <- colLvl[[i]]
            if (is.null(lvl)) {
                next
            }
            t[i] <- "factor"
            tmpf <- .orch.tmpfile()
            write.table(lvl, 
                file = tmpf, 
                quote = F, 
                col.names = F, 
                row.names = F)
            dfs.lvl <- hdfs.fput(
                filename = tmpf,
                dfs.name = dfs.name,
                dfs.file = .dfs.levels.file(i),
                overwrite = F)
            if (is.null(dfs.lvl)) {
                orch.dlog.stop('error copying levels#%d to HDFS', i)
                return (NULL)
            }
            if (!.orch.env$keep.tmp) {
                .orch.unlink(tmpf)
            }
        }
        attr(data, "orch.types") <- t
        attr(data, "orch.categorized") <- TRUE
        orch.dlogt('wrote levels to HDFS')
    }
    else {
        # no categorization was applied
        attr(data, "orch.categorized") <- FALSE
    }
    
    # Save metadata alogside with HDFS files.
    attr(data, "orch.kvs") <- TRUE
    attr(data, "orch.key.sep") <- key.sep
    attr(data, "orch.value.sep") <- value.sep
    attr(data, "orch.origin") <- sprintf("R object \"%s\"", dataName)
    attr(data, "orch.pristine") <- FALSE
    orch.dlog.attr(data)
    dfs.id <- hdfs.mput(
        dfs.id = dfs.id,
        meta = .paste.meta(data))
    if (is.null(dfs.id)) {
        orch.dlog.stop('error copying meta-data to HDFS')
        return (NULL)
    }
    orch.dlogt('called hdfs.mput')
    
    # All good.
    orch.dlogo(t=.t)
    dfs.id
}

##
#' Generic HDFS/GET framework. The framework takes case of several shared
#' between hdfs.get and hdfs.sample operations like retreiving metadata and 
#' normalizing it, reading categorical values and converiting category IDs 
#' into R factors, etc.
#' 
#' @param dfs.id HDFS object identifier.
#' @param expr Non-generic code to execute.
#' @param ... Any extra parameters specific to implementation.
#' 
#' @return data.frame object pointing to the exported data set.
#' @return NULL is something went wrong.
#'
#' @seealso hdfs.get
#' @seealso hdfs.sample
##
.hdfs.get.fw <- function(dfs.id, body, ...)
{
    # Read metadata to get key and value separators.
    metaStr <- hdfs.mget(dfs.id)
    if (is.null(metaStr)) { 
        orch.dloge("can't read metadata of \"%s\"", dfs.id)
        return (NULL)
    }
    else {
        meta <- .parse.meta(NULL, metaStr)
        orch.dlogv(meta)
        key.sep <- meta$orch.key.sep
        if (is.null(key.sep)) {
            key.sep <- .orch.env$key.sep
            orch.dlog.info("using default key separator '%s'", key.sep)
        }
        val.sep <- meta$orch.value.sep
        if (is.null(val.sep)) {
            val.sep <- .orch.env$val.sep
            orch.dlog.info("using default value separator '%s'", val.sep)
        }
        keyi <- meta$orch.keyi
        orch.dlogt('parsed metadata')
    }
    
    # Read categorized values. Each column with categories has an extra
    # file alogside "__ORCH_LEVELS_#__" which contains the original levels
    # (e.g. category names). Load the levels from HDFS and set types of
    # categorized columns to "factor".
    categorize <- null.to(meta$orch.categorized, FALSE)
    if (categorize)
    {
        orch.dlog.info("categorization detected")
        types <- meta$orch.types
        names <- meta$orch.names
        
        ctgCount <- 0L
        colLvl <- list()
        for (i in seq_along(types)) {
            t <- types[i]
            if (t == "factor") {
                tmp <- hdfs.fget(
                    dfs.id = dfs.id, 
                    dfs.file = .dfs.levels.file(i),
                    overwrite = F)
                if (is.null(tmp)) {
                    orch.dlog.stop("can't read levels from HDFS for column #%d \"%s\"", 
                        i, null.to(names[i], ''))
                    return (NULL)
                }
                colLvl[[i]] <- read.table(tmp, as.is=T)[[1]]
                types[i] <- "integer"
                orch.dlogd("categorized column %d \"%s\"", i, names[i])
                ctgCount %+=% 1L
            }
        }
        if (length(colLvl) == 0) {
            orch.dlogw("nothing categorized")
            categorize <- FALSE
        }
        else {
            orch.dlog.info("%d column%s of %d categorized", 
                ctgCount, .s(ctgCount), length(types))
        }
        meta$orch.types <- types
        orch.dlogt('loaded levels')
    }
    
    # Here we invoke a custom code passed by a front-end function.
    # This way we are sharing this framework between hdfs.get and hdsf.sample.
    ret <- body(
		key.sep, 
		val.sep, 
		keyi, 
		meta, 
		...)

    # Now assign original levels to the categorized columns. This will restore
    # the original representation of R's "factor" data type.
    if (categorize && !is.null(ret))
    {
        for (i in seq_along(colLvl)) {
            lvl <- colLvl[[i]]
            if (is.null(lvl)) {
                next
            }
            ret[[i]] <- factor(
                x = ret[[i]], 
                levels = seq_along(lvl), 
                labels = lvl)
        }
        orch.dlogt('attached levels')
    }
    
    # All good (maybe).
    ret
}

##
#' Copies data from HDFS into R in-memory object. All metadata gets extracted 
#' and all attributes like column names, data types, etc. are restored if the
#' data was originated from R environment. Otherwise generic reverse-engineered
#' attributes (like val1, val2 for names) will be assigned.
#' 
#' @param dfs.id HDFS object identifier
#'
#' @return data.frame object pointing to the exported data set.
#' @return NULL is something went wrong.
#'
#' @note Key/value separator is not required when calling this function because
#'     it is stored together with the data itself and will be retreived auto-
#'     matically from its metadata.
#'
#' @seealso hdfs.put
#' @seealso hdfs.download
#' @seealso hdfs.upload
##
hdfs.get <- function(dfs.id)
{
    # Check input parameters.
    .orch.test.special.stop(dfs.id, "HDFS object", .is.dfs.id_or_path)
       
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    orch.dbg.newtimer()

    # Invoke generic HDFS/GET framework. The framework takes case of
    # retreiving metadata and normalizing it, reading categorical values
    # and converiting category IDs into R factors.
    ret <- .hdfs.get.fw(dfs.id, 
        body = function(...)
	{
		# Pull "..." arguments into local scope. This allows to extend
        # passed parameters without changing every callback signature.
		.orch.assigndots(...)
		
        # "download" function takes care of "part-0000x" discovering 
        # in HDFS and concatinating them into one local temp file.
        tmp <- hdfs.download(dfs.id)
        orch.dlogt('called hdfs.download')
        if (!is.null(tmp))
        {
            ret <- NULL
            if (meta$orch.class == "data.frame" &&
                meta$orch.keyi < 0)
            {
                if (file.info(tmp)$size == 0) {
                    # read.table is known to fail when input file is empty and
                    # throw an exception. At this case we need to return a data.frame
                    # with correct column types and 0 rows. 
                    orch.dlogd("codepath 1:1")
                    orch.dlogw("HDFS object has no data")
                    typeDef <- lapply(meta$orch.types, function(x) {
                        if (x == "factor") {
                            factor()
                        } else {
                            vector(x)
                        }
                    })
                    names(typeDef) <- meta$orch.names
                    ret <- do.call(data.frame, typeDef)
                }
                else {
                    # read data into memory as table via read.table which is by far
                    # the fastest way to load a data.frame into R memory from a
                    # local file system (same as scan()).
                    orch.dlogd("codepath 1:2")
                    orch.dlog.info("using fast read.table for %s, keyi=%d",
                        meta$orch.class, meta$orch.keyi)
                    input <- try(read.table(
                        file = tmp,
                        header = FALSE,
                        sep = val.sep,
                        colClasses = meta$orch.types,
                        quote = meta$orch.quote,
                        flush = !meta$orch.pristine,
                        comment.char = ''), T
                    )
                    if (class(input) == "try-error") {
                        # we will drop down "readLines" codepath from here,
                        # this happens when file has only empty lines.
                        orch.dloge("read.table failed, falling back to readLines")
                        ret <- NULL
                    }
                    else {
                        # read.table was able to read all the data just fine
                        orch.dlogt('succsefully loaded to memory')
                        
                        # restor all original R object attributes
                        ret <- .apply.meta.data.frame(input, meta)
                        orch.dlogt('converted to R object')
                        
                        # "input" object might be large, try to keep memory usage 
                        # as low as possible. Not sure this is very helpful though.
                        if (object.size(input) > .orch.env$force.gc) {
                            orch.dlog.trace("enforcing garbage collector on input=%s",
                                mem2str(object.size(input)))
                            rm(input)
                            gc()
                        }
                    }
                }
            }
            if (is.null(ret))
            {
                # For unique data structure as can always go through a slowest
                # path of read unparsed text into memory and convertion into an 
                # loosely-strucutred keyval objects.
                orch.dlogd("codepath 2:1")
                orch.dlog.info("using slow readLines for %s, keyi=%d",
                    meta$orch.class, meta$orch.keyi)
                input <- readLines(tmp)
                if (!.orch.env$keep.tmp) {
                    .orch.unlink(tmp)
                }
                orch.dlogt('succsefully loaded to memory')
                
                # parse and convert data into keyvalue pairs
                kvs <- if (keyi >= 0) {
                    kv <- strsplit.one(input, key.sep, fixed=T)
                    lapply(kv, function(kv) {
                        val <- strsplit.eol(kv[2], 
                            split = val.sep, 
                            fixed = T)[[1]]
                        .make.keyval(key=kv[1], val=val)
                    })
                }
                else {
                    lapply(input, function(kv) {
                        val <- strsplit.eol(kv[1], 
                            split = val.sep, 
                            fixed = T)[[1]]
                        .make.keyval(key=NULL, val=val)
                    })
                }
                orch.dlogt('converted to keyvals')
            
                # convert to an R object as specified in metadata
                attributes(kvs) <- meta
                ret <- .keyvals.as.any(kvs)
                orch.dlogt('converted to R object')
            }
        }
        else {
            orch.dloge("can't download \"%s\"", dfs.id)
            ret <- NULL
        }
		ret
	})
    
    # All good (maybe).
    orch.dlogo(t=.t)
    ret
}

#' @TODO (vlad) New Sukhendu's code, revise.
.orch.hdfs.sample <- function(dfs.id, percent, dfs.output)
{
  if (missing(dfs.id) || is.null(dfs.id) || !is.character(dfs.id[[1]])) {
      orch.dlog.stop("dfs identifier must be single string value")
  }
   
  if ((length(percent) != 1) || !is.numeric(percent) || percent < 0 ||
       percent > 100) {
      orch.dlog.stop("invalid percent parameter: must be numeric between 0-100")
  }
  
  if (!is.null(dfs.output) && ((length(dfs.output)!=1L) || dfs.output == ""))
     orch.dlog.stop(gettextf("invalid argument '%s'", "dfs.output"))

  if (!hdfs.exists(dfs.id))
   orch.dlog.stop("input file does not exist")

  sampleJar   <- ORCHcore:::.get.jar()

  if (is.null(dfs.output))
   dfs.output <- hdfs.mkdir(ORCHcore:::.orch.uid())
  else
   dfs.output <- hdfs.mkdir(dfs.output)

  ORCHcore:::.hadoop.sh("jar", sampleJar, "com.oracle.orch.sample.Sample",
              sprintf("%s %s %s",percent/100, dfs.id[[1]], dfs.output[[1]]))
  hdfs.cp(hdfs.id(sprintf("%s/__ORCHMETA__",dfs.id[[1]]), force = TRUE),
          dfs.output)
  dfs.output
}

#' @TODO (vlad) New Sukhendu's code, revise.
orch.sample <- function(input, percent = 1, output = NULL)
{
   if (missing(input) || is.null(input))
        orch.dlog.stop(gettextf("invalid argument '%s'", "input"))

   if(is.ore.frame(input))
    .orch.hive.sample(input, percent, output)
   else
    .orch.hdfs.sample(input, percent, output)
}

##
#' Samples data in HDFS and returns an R in-memory object. Partially copies 
#' data from HDFS into R in-memory object. All metadata gets extracted and all 
#' attributes like column names, data types, etc. are restored if the data was 
#' originated from R environment. Otherwise generic reverse-engineered attributes 
#' (like val1, val2 for names) will be assigned.
#'
#' @param dfs.id HDFS object identifier.
#' @param n Number of lines to sample, default is 1000. It is not guaranteed
#'    that the result will contain exact this number of lines.
#' @param level Number of HDFS part-files to sample, higher numbers assures
#'     better distribution but linearly slows down performance.
#'
#' @return data.frame object pointing to the samples data set.
#' @return NULL is something went wrong.
#'
#' @note Key/value separator is not required when calling this function because
#'     it is stored together with the data itself and will be retreived auto-
#'     matically from its metadata.
#'
#' @seealso hdfs.get
#' @seealso hdfs.download
#' @seealso hdfs.pull
##
hdfs.sample <- function(
        dfs.id,
        n = -1,
        level = 5)
{
    # Check input parameters.
    .orch.test.special.stop(dfs.id, "HDFS object", .is.dfs.id_or_path)
    .orch.test.input.stop(n, "numeric")
    .orch.test.input.stop(level, "positive")
    
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    orch.dbg.newtimer()
    
    # Invoke generic HDFS/GET framework. The framework takes case of
    # retreiving metadata and normalizing it, reading categorical values
    # and converiting category IDs into R factors.
    ret <- .hdfs.get.fw(dfs.id,
        lines = n, 
        body = function(...)
	{
		# Pull "..." arguments into local scope. This allows to extend
        # passed parameters without changing every callback signature.
		.orch.assigndots(...)
		
		# default sampling size
        if (lines < 0) {
            n <- 1000
            orch.dlog.info("using default sampling size of %d", n)
        }

        # Sample separate parts of the input HDFS directory in order
        # to simulate pseudo-random distribution.
        ret <- NULL
        parts <- .dfs.list(dfs.id)
        nparts <- length(parts)
        if (nparts > 0)
        {
            # Shaffle parts order to be non-deterministic and sample only 
            # [level] number ot part files. We don't want to touche every part
            # file as there can be 1000+ and Hadoop CLI latency will kill us.
            orch.dlog.info('%d part%s found', nparts, .s(nparts))
            parts <- parts[sample(nparts)]
            if (level > 0) {
                if (level < nparts) {
                    parts <- parts[seq_len(level)]
                    orch.dlog.info("samplig limited to %d part%s", 
                            level, .s(level))
                }
                else if (level > nparts) {
                    orch.dlogw("can't sample %d part%s, HDFS has only %d part%s",
                        level, .s(level), nparts, .s(nparts))
                }
                nparts <- length(parts)
                .assert(nparts <= level)
            }
            
            # Read from every part file a limited number of lines and shaffle 
            # the lines order to create a non-deterministic output.
            sampleLn <- c()
            if (n > 0)
            {
                # Read tails of each part and aggregate up the [n]
                n1 <- ceiling(n / length(parts)) + 1
                for (part in parts) {
                    tailLn <- hdfs.ftail(
                        dfs.id = dfs.id, 
                        dfs.file = part, 
                        n = n1,
                        tail = F)
                    sampleLn <- c(sampleLn, tailLn)
                    nsample <- length(sampleLn)
                    if (nsample >= n) {
                        break
                    }
                }
                .assert(nsample > 0)
                sampleLn <- sampleLn[sample(nsample)]
            }
            
            # Convert read line into the data.frame-like type (depending on HDFS
            # metadata). Some of the rows might be read incomplete?
            kvs <- .parse.keyval(sampleLn, key.sep, val.sep)
            types <- meta$orch.types
            if (!is.null(types) && length(kvs) > 0) {
                # cleanup sampled lines, to convert it to data.frame all rows 
                # must have the same # of fields and the same data types.
                coln <- length(types)
                keepRows <- sapply(kvs, function(kv) {
                    coln == length(kv$key) + length(kv$val)
                })
                kvs <- kvs[keepRows]
                badRows <- length(kvs) - sum(keepRows)
                if (badRows > 0) {
                    orch.dlogw('found %d invalid row%s', badRows, .s(badRows))
                }
            }
            if (lines > 0 && length(kvs) < n) {
                orch.dlogw("could not sample %d rows, got only %d", 
                    n, length(kvs))
            }
            else if (length(kvs) > n)  {
                kvs <- kvs[seq_len(n)]
            }
            attributes(kvs) <- meta
            ret <- .keyvals.as.any(kvs)
        }
        else {
            orch.dloge("HDFS object \"%s\" has no data", dfs.id)
        }
        ret
	})

    # All good (maybe).
    orch.dlogo(t=.t)
    ret
}

##
#' Brings an HDFS object into ORCH environment.
#'
#' Attaches "unmanaged" HDFS data to ORCH framework and return its HDFS object 
#' identifier. If the HDFS data has not metadata attached then it will try to 
#' rebuild it to make it compatible for ORCH infrastructure.
#' 
#' Delimiters are specified only as a "hint". ORCH create HDFS object's metadata 
#' with the delimiters specified, content of an HDFS object attached will not be 
#' changed. If you specify incorrect set of delimiters then attach will fail. If 
#' you do not specify the delimiters then the current defaults will be used.
#'
#' @param dfs.name HDFS object name.
#' @param key.sep Key field separator character, "\t" default.
#' @param value.sep Value field separator character, "," default.
#' @param key Key column index, NULL - autodetect.
#' @param force Overwrite HDFS object metadata.
#' @param trim Ignore tailing empty fields.
#' @param quiet Do not print messages to console.
#' 
#' @return HDFS object ID if all good.
#' @return NULL if transfer error occurred.
#'
#' @seealso hdfs.exists
#' @seealso hdfs.ls
##
hdfs.attach <- function(
    dfs.name,
    key.sep = .orch.env$key.sep,
    value.sep = .orch.env$val.sep,
    key = NULL,
    force = FALSE,
    trim = FALSE,
    quiet = FALSE)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.name, "string")
    .orch.test.input.stop(key.sep, "char")
    .orch.test.input.stop(value.sep, "char")
    .orch.ntest.input.stop(key, "numeric")
    .orch.test.input.stop(force, "logical")
    .orch.test.input.stop(trim, "logical")
    .orch.test.input.stop(quiet, "logical")
    
    # Input are fine, try to attach HDFS files. 
    if (.is.dfs.id(dfs.name) && !force) {
        # nothing to do, already attached
        dfs.id <- dfs.name
    }
    else {
        # Try to access HDFS files
        dfs.id <- .as.dfs.id(dfs.name, stop=T)
        if (!hdfs.exists(dfs.id)) {
            orch.dloge("\"%s\" not found'", dfs.id, cat=!quiet)
            dfs.id <- NULL
        }
        else {
            meta <- if (force) {
                # ignore existing metadata
                NULL
            } else {
                # read metadata for this HDFS object
                hdfs.mget(dfs.id)
            }
            if (is.null(meta)) {
                # Build "sampled" metadata it it's not ORCH-originated data.
                # Sampled metadata is missing some attributes like "dim".
                orch.dlogw("sampling data types of \"%s\"", dfs.id, cat=!quiet)
                meta <- .dfs.extract.meta(
                    dfs.id = dfs.id,
                    key.sep = key.sep,
                    value.sep = value.sep,
                    keyi = key,
                    trim = trim)
                dfs.id <- hdfs.mput(
                    dfs.id = dfs.id,
                    meta = meta,
                    overwrite = T)
                # mput can fail at this point and dfs.id will reset back to 
                # NULL indicating that we don't have access rights to the data.
            }        
        }
    }
        
    # All good
    dfs.id
}

##
#' Removes data from HDFS. This will invalidate all HDFS object identifiers 
#' pointing to this data set. Deletes both object data and metadata.
#'
#' @param dfs.id HDFS object identifier or its path
#' @param force do not confirm '*' deletion, don't check errors, silent
#' @return TRUE if data was successfully deleted or FALSE otherwise.
#'
#' @seealso hdfs.exists
#' @seealso hdfs.ls
##
hdfs.rm <- function(dfs.id, force=F)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.id, "string")
    .orch.test.input.stop(force, "logical")
    
    # Input are fine, try to remove HDFS files. 
    path <- .dfs.path(dfs.id, stop=T)
    ok <- TRUE
    if (!force) {
        # if we have /*/ in path, prompt user
        if (grepl("\\*", path)) { 
            if (!.orch.prompt('"*" detected in file path, continue?')) {
                orch.dcat("hdfs.rm operation aborted")
                ok <- FALSE
            }
        }
    }
    if (ok) {
        .hal.dfs.rmr(path)
        if (.sh.error() != 0 ) {
            if (!force) {
                orch.dloge('failed to remove "%s"', path, cat=T)
                ok <- FALSE
            }
        }
        else {
            # sync HDFS cache
            .orch.hcache.drop(dfs.id)
        }
    }
    if (!force) {
        # Return value only in non-forced mode. "force" mode does not check
        # for any errors and therefore there is no reason to retunr T|F.
        ok
    }
}

##
#' Checks if an HDFS object exists. 
#'
#' Verifies validity of the HDFS object identifier or existence of HDFS data 
#' with the specified name in HDFS. TRUE result means that the data can be 
#' attached and can be used in hadoop.run() function.
#'
# @param dfs.id HDFS object identifier or its name
#
# @return TRUE if data exists and validated
# @return FALSE in the case of a failure
#'
#' @seealso hdfs.attach
#' @seealso hdfs.ls
##
hdfs.exists <- function(dfs.id)
{
    path <- .dfs.path(dfs.id, stop=T)
    .hal.dfs.exists(path)
    if (.sh.error() != 0) {
        FALSE
    }
    else {
        TRUE
    }
}

##
#' Sets current URI path and optionally connection to an HDFS resource.
#' @attention Available only in ORCH v2.0 and above.
#'
#' The URI format is [scheme:[//autority]][/parent/]child. For HDFS the scheme 
#' is "hdfs", and for the local filesystem the scheme is "file". The scheme and 
#' authority are optional. If not specified, the default scheme specified in the 
#' configuration is used. An HDFS file or directory such as '/parent/child' can 
#' be specified simply as "child" if "/parent" is the curent working directory.
#'
#' @param dfs.path New URI path relative to the current path.
#'
#' @return Current full HDFS path if the directory was changed successfully.
#' @return NULL in the case of a failure.
#'
#' @seealso hdfs.ls
#' @seealso hdfs.pwd
##
hdfs.cd <- function(dfs.path)
{
    .orch.mtest.input.stop(dfs.path, "string")
    cwd <- .dfs.cwd(dfs.path, stop=T)
    if (substr(cwd,1,2) == '..') {
        # can't go above root level
        orch.dloge("can't go above HDFS root", cat=T)
        NULL
    }
    else if (!hdfs.exists(paste0('/', cwd))) {
        # looks like the path is invalid
        orch.dloge('HDFS path does not exist', cat=T)
        NULL
    }
    else {
        # all good
        .orch.env$hdfs.cwd <- cwd
        hdfs.pwd()
    }
}

##
#' Returns a list with names of all HDSF data objects (directories) at currently 
#' set path. Only directories containing data will be listed.
#'
#' @param dfs.path optional URI path relative to the current path. By default 
#'        list all objects at the current working path.
#' @param pattern optional regular expression for filtering of returned file 
#'        names. Example pattern="^[^_]" will filter out all "_*" files.
#' @param pattern optional regular expression for filtering of returned file 
#'     names. Example pattern="^[^_]" will filter out all "_*" files.
#'
#' @return list of HDFS data object names
#' @return NULL if path is invalid
#'
#' @seealso hdfs.cd
#' @seealso hdfs.pwd
##
hdfs.ls <- function(
        dfs.path = '.', 
        pattern = NULL)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.path, "character")
    .orch.ntest.input.stop(pattern, "character")
    
    # Input are fine, try to remove HDFS files. 
    dfs.path <- .dfs.path(dfs.path, stop=T)
    lsout <- .hal.dfs.ls(dfs.path)
    # @TODO (vlad) errors out when HDFS is not initialised yet.
    
    if (.sh.error() != 0) {
        orch.dloge("can't list directory \"%s\"", dfs.path)
        dirs <- NULL
    }
    else {
        # Parse -ls output and extract only names.
        dirs <- c()
        for (l in lsout) {
            lastCol <- rev(strsplit(l, ' +')[[1]])[1]
            fn <- rev(strsplit(lastCol, '/')[[1]])[1]
            if (!is.null(pattern) && !grepl(pattern, fn)) {
                next
            }
            dirs <- c(dirs, fn)
        }
    }
    dirs
}

##
#' Returns current working HDFS directory.
#'
#' @return current working HDFS directory
#' @return NULL if HDFS is not connected
#'
#' @seealso hdfs.cd
#' @seealso hdfs.ls
##
hdfs.pwd <- function()
{
    pwd <- sprintf("%s/%s",
        .orch.env$hdfs.root,
        .orch.env$hdfs.cwd)
    .scrub.path(pwd)
}

##
#' Return current HDFS user's root directory or NULL if HDFS is not available.
#' Essentially NULL means that you can't do anything in HDFS.
#' 
#' @param new.root If speficied then set new root directory.
#' @return Current user's root HDFS directory or NULL if HDFS is not connected.
#'
#' @seealso hdfs.setroot
#' @seealso hdfs.pwd
##
hdfs.root <- function(new.root)
{
    if (!missing(new.root)) {
        hdfs.setroot(new.root)
    }
    .orch.env$hdfs.root
}

##
#' Sets current user's HDFS root directory. All HDFS paths and operations 
#' within ORCH infrastructure are relative to the current HDFS root and user
#' can not change current working directory above its root.
#' 
#' @param dfs.path is the absolute path in HDFS file system to be set as
#'     current HDFS root. If this argument is not given then the user's
#'     HDFS home directory will be user as the root (also set by default at
#'     ORCH startup).
#' 
#' @return current HDFS root or NULL if there was an error and root was not
#'    set to the new value. This can happen if \p dfs.path does not exist
#'    in HDFS.
#' 
#' @seealso hdfs.root
#' @seealso hdfs.pwd
##
hdfs.setroot <- function(dfs.path)
{
    # Check inputs.
    .orch.mtest.input.stop(dfs.path, "string")
    if (missing(dfs.path)) {
        dfs.path <- .dfs.user.root()
    }
    
    # Test new path and switch root.
    dfs.path <- .scrub.path(dfs.path)
    if (.orch.env$hdfs.root != dfs.path) {
        # "hadoop dfs -test -e" returns 0 (ok) for bogus paths like "/..".
        # this must me handled specifically by verofying that root has not "..".
        if (grepl("/../|^../|/..$|^..$", dfs.path)) {
            orch.dloge("HDFS path \"%s\" is invalid", dfs.path, cat=T)
            dfs.path <- NULL
        }
        else {
            .hal.dfs.exists(dfs.path)
            if (.sh.error() == 0) {
                .orch.env$hdfs.root <- dfs.path
                .orch.env$hdfs.cwd <- ""
                orch.dlog.info("HDFS root set to \"%s\"", dfs.path)
            }
            else {
                orch.dloge("HDFS path \"%s\" is not found", dfs.path, cat=T)
                dfs.path <- NULL
            }
        }
    }
    else {
        orch.dlog.debug("HDFS root is not changed")
    }
    
    # Current HDFS root or NULL.
    dfs.path
}

##
#' Creates a new sub-directory in HDFS relative to the current working 
#' directory.
#' @attention Available only in ORCH v2.0 and above.
#'
#' @param dfs.name name of the new directory to create
#' @param cd automatically set as working directory, default FALSE
#'
#' @return new HDFS directory full path as string or
#' @return NULL if new directory was not created
#'
#' @seealso hdfs.rmdir
#' @seealso hdfs.cd
##
hdfs.mkdir <- function(dfs.name, cd=F)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.name, "string")
    .orch.test.input.stop(cd, "logical")
    
    # Input are fine, try to remove HDFS files. 
    dfs.name <- .dfs.path(dfs.name, stop=T)
    .hal.dfs.mkdir(dfs.name)
    if (.sh.error() != 0) {
        orch.dloge('failed to create HDFS directory', cat=T)
        dfs.name <- NULL
    }
    else {
        if (cd) {
            hdfs.cd(dfs.name)
        }
    }
    
    # HDFS path object or NULL
    dfs.name
}

##
#' Deletes an existing sub-directory in HDFS relative to the current working 
#' directory. All data objects stored in this directory will be deleted too 
#' and, therefore, all assosiated HDFS object identifier will be invalidated.
#'
#' @param dfs.name name of the directory to delete
#' @param force do not confirm '*' deletion, don't check errors, silent
#'
#' @return TRUE if directory was deleted successfully
#' @return FALSE if there was an error
#'
#' @seealso hdfs.mkdir
#' @seealso hdfs.cd
##
hdfs.rmdir <- function(dfs.name, force=F)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.name, "string")
    .orch.test.input.stop(force, "logical")
    
    # Input are fine, try to remove HDFS files. 
    path <- .dfs.path(dfs.name, stop=T)
    ok <- TRUE
    if (path == .orch.env$hdfs.root) {
        orch.dloge("can't remove root")
        ok <- FALSE
    }
    if (!force) {
        # if we have /*/ in path, prompt user
        if (grepl("\\*", path)) { 
            if (!.orch.prompt('"*" detected in directory path, continue?')) {
                orch.dcat("hdfs.rmdir operation aborted")
                ok <- FALSE
            }
        }
    }
    if (ok) {
        .hal.dfs.rmr(path)
        if (!force && .sh.error() != 0) {
            orch.dloge('failed to remove "%s"', path, cat=T)
            ok <- FALSE
        }
    }
    if (!force) {
        # Return value only in non-forced mode. "force" mode does not check
        # for any errors and therefore there is no reason to retunr T|F.
        ok
    }
}

##
#' Moves an existing file/dir in HDFS relative to the current working 
#' directory to the specified destination directory.
#'
#' @param dfs.src name of the src file to move
#' @param dfs.dst name of the dest file/directory
#' @param force do not confirm '*' move, don't check errors, silent
#'
#' @return TRUE if file was moved successfully
#' @return FALSE if there was an error
#'
#' @seealso hdfs.cp
##
hdfs.mv <- function(dfs.src, dfs.dst, force=F)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.src, "string")
    .orch.test.input.stop(dfs.dst, "string")
    .orch.test.input.stop(force, "logical")
    
    # Input are fine, try to remove HDFS files. 
    dfs.src <- .dfs.path(dfs.src, stop=T)
    ok <- TRUE
    if (!force) {
        # if we have /*/ in path, prompt user
        if (grepl("\\*", dfs.src)) { 
            if (!.orch.prompt('"*" detected in source path, continue?')) {
                orch.dcat("hdfs.mv operation aborted")
                ok <- FALSE
            }
        }
    }
    if (ok) {
        dfs.dst <- .dfs.path(dfs.dst, stop=T)
        .hal.dfs.mv(dfs.src, dfs.dst)
        if (.sh.error() != 0) {
            if (!force) {
                orch.dloge('failed to move HDFS file', cat=T)
                ok <- FALSE
            }
        }
        else {
            # sync HDFS cache
            .orch.hcache.move(dfs.src, dfs.dst)
        }
    }
    if (!force) {
        # Return value only in non-forced mode. "force" mode does not check
        # for any errors and therefore there is no reason to retunr T|F.
        ok
    }
}

##
#' Copies an existing file/dir in HDFS relative to the current working 
#' directory to the destination directory
#'
#' @param dfs.src name of the src file to move
#' @param dfs.dst name of the dest file/directory
#' @param force do not confirm '*' copy, don't check errors, silent
#'
#' @return TRUE if file was moved successfully
#' @return FALSE if there was an error
#'
#' @seealso hdfs.mv
##
hdfs.cp <- function(dfs.src, dfs.dst, force=F)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.src, "string")
    .orch.test.input.stop(dfs.dst, "string")
    .orch.test.input.stop(force, "logical")
    
    # Input are fine, try to remove HDFS files. 
    dfs.src <- .dfs.path(dfs.src, stop=T)
    ok <- TRUE
    if (!force) {
        # if we have /*/ in path, prompt user
        if (grepl("\\*", dfs.src)) { 
            if (!.orch.prompt('"*" detected in source path, continue?')) {
                orch.dcat("hdfs.cp operation aborted")
                ok <- FALSE
            }
        }
    }
    if (ok) {
        dfs.dst <- .dfs.path(dfs.dst, stop=T)
        .hal.dfs.cp(dfs.src, dfs.dst)
        if (.sh.error() != 0) {
            if (!force) {
                orch.dloge('failed to copy HDFS file')
                ok <- FALSE
            }
        }
        else {
            # sync HDFS cache
            .orch.hcache.copy(dfs.src, dfs.dst)
        }
    }
    if (!force) {
        # Return value only in non-forced mode. "force" mode does not check
        # for any errors and therefore there is no reason to retunr T|F.
        ok
    }
}

##
#' Returns total size of the HDFS object in bytes.
#' Non-existing objects will report size 0.
#'
#' @param dfs.id HDFS object identifier
#' @param units converts to KB, MB, GB, TB or PB
#' @return total size of the HDFS object in bytes or 
#'     0 if object does not exist in HDFS
#'
#' @seealso hdfs.parts
#' @seealso hdfs.ls
#' @seealso hdfs.fsize
##
hdfs.size <- function(dfs.id, units=NULL)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.id, "string")
    .orch.ntest.input.stop(units, "string")
    
    # List all data files.
    dfsPath <- .dfs.path(dfs.id, stop=T)
    dfsFiles <- .hal.dfs.ls(dfsPath)
    parts <- c()
    if (.sh.error() == 0) {
        for (f in dfsFiles) {
            isPart <- .dfs.path.filter(f)
            if (isPart) {
                size <- rev(strsplit(f, ' ')[[1]])[4]
                parts <- c(parts, size)
            }
        }
        size <- ifelse(length(parts) > 0,
            sum(as.numeric(parts)),
            0) # no data files were found
    }
    else {
        size <- 0
    }
    
    # Convert to size units if required
    if (!is.null(units)) {
        u <- toupper(units)
        if ('KB' == u) {
            size <- size / KB            
        }
        else if ('MB' == u) {
            size <- size / MB            
        }
        else if ('GB' == u) {
            size <- size / GB            
        }
        else if ('TB' == u) {
            size <- size / TB            
        }
        else if ('PB' == u) {
            size <- size / PB            
        }
        else {
            orch.dloge("unknown units %s, returning in bytes", 
                u, cat=T)
        }
    }
    
    # Round is useful when we are returning < bytes as we'll have long 
    # tailing .-part which will denimish the result readability.
    .assert(length(size) == 1)
    round(size, 2)
}

##
#' Returns number of parts the HDFS object is divided into.
#' Non-existing objects will report 0 parts.
#'
#' @param dfs.id HDFS object identifier
#' @return number of parts the HDFS object is divided into or 
#'     0 if object does not exist in HDFS.
#'
#' @seealso hdfs.parts
#' @seealso hdfs.ls
##
hdfs.parts <- function(dfs.id)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.id, "string")
    
    # Count all data files (not prefixed with "_").
    dfsPath <- .dfs.path(dfs.id, stop=T)
    dfsFiles <- .hal.dfs.ls(dfsPath)
    partCnt <- 0
    if (.sh.error() == 0) {
        for (f in dfsFiles) {
            if (.dfs.path.filter(f)) {
                partCnt <- partCnt + 1
            }
        }
    }
    partCnt
}

##
#' Converts HDFS path to R "dfs.id" objects. Accepts ONLY absolute path(e.g. 
#' dfs.path() result). If \p dfs.x is of a wrong type or malformed then returns 
#' NULL.
#'
#' @param dfs.x HDFS absolute path 
#' @param force donot perform existence check when TRUE
#'
#' @return R HDFS object which points to an HDFS resource.
#' @return NULL wrong type or malformed \p dfs.x
#' @attention Internal format of the object is a subject to change, use API!
##
hdfs.id <- function(dfs.x, force=F)
{
    .orch.test.input.stop(dfs.x, "character")
    .orch.test.input.stop(force, "logical")
    
    # Check input preconditions.
    if (missing(dfs.x)) {
        # no ID = unique ID
        dfs.x <- .orch.uid()
    }
    # Make the HDFS object pointer.
    if(!.is.dfs.str(dfs.x)) {
        orch.dloge('input must be a string', stop=T)
    }
    
    # Mark path as "id" type.
    dfs.id <- dfs.x
    attr(dfs.id, 'dfs.id') <- T
    
    # Make sure the directory exists when asked to do so.
    if (!force && !hdfs.exists(dfs.id)) {
        orch.dloge('"%s" is not found', dfs.id[[1]])
        dfs.id <- NULL
    }
    dfs.id
}

##
#' Returns TRUE if \p x is actually an ORCH "dfs.id" object.
#' 
#' @param x any R object
#' @return TRUE if x is "dfs.id" type object.
#' 
#' @seealso hdfs.id
#' @seealso hdfs.attach
##
is.hdfs.id <- function(x)
{
    .is.dfs.id(x)
}

##
#' Returns a data.frame with extencive description of an HDFS object attributes.
#' If the object does not exist or has no metadata then NULL is returned.
#'
#' @param dfs.id HDFS object to describe.
#' @return data.frame with description.
##
hdfs.describe <- function(dfs.id)
{
    # Check inputs. 
    .orch.test.special.stop(dfs.id, "HDFS object", .is.dfs.id_or_path)

    # Read metadata for the specified HDFS object.
    metaStr <- hdfs.mget(dfs.id)
    if (!is.null(metaStr))
    {
        # retreive and normalize attributes
        meta <- .parse.meta(NULL, metaStr)
        keyi        <- null.to(meta$orch.keyi, -1)
        class       <- null.to(meta$orch.class, "data.frame")
        types       <- null.to(meta$orch.types, "character")
        names       <- null.to(meta$orch.names, "val")
        dim         <- null.to(meta$orch.dim, c(-1,-1))
        origin      <- null.to(meta$orch.origin, "unknown")
        categorized <- null.to(meta$orch.categorized, F)
        rownamei    <- null.to(meta$orch.rownamei, 0)
        key.sep     <- null.to(meta$orch.key.sep, NA)
        value.sep   <- null.to(meta$orch.value.sep, NA)
        quote       <- null.to(meta$orch.quote, NA)
        pristine    <- null.to(meta$orch.pristine, FALSE)
        trim        <- null.to(meta$orch.trim, FALSE)
        
        # format description as a data.frame
        desc <- data.frame(
            NAME = c(
                "path",
                "origin",
                "class", 
                "types",
                "dim",
                "names",
                "caterized",
                "has.key",
                "key.column",
                "empty.key",
                "has.rownames",
                "key.sep",
                "value.sep",
                "quoted",
                "pristine",
                "trimmed"),
            VALUE = c(
                toString(dfs.id),
                paste0(origin, collapse=''),
                class,
                toString(types),
                sprintf("c(%.0f, %0.f)", dim[1], dim[2]),
                toString(names),
                categorized,
                (keyi > 0),
                paste0(keyi, ':', 
                    if (keyi > 0) 
                        names[keyi]
                    else if (keyi == 0)
                        "_"
                    else "NULL"),
                (keyi == 0),
                (rownamei > 0),
                key.sep,
                value.sep,
                .empty.to(quote, FALSE),
                pristine,
                trim),
            stringsAsFactors = F
        )
    }
    else {
        orch.dloge("metadata was not found in HDFS", cat=T)
        desc <- data.frame(
            NAME = c(
                "path",
                "origin"),
            VALUE = c(
                toString(dfs.id),
                "HDFS"),
            stringsAsFactors = F
        )
    }

    # Add metadata-independent attributes.
    desc <- rbind(desc, c("size", hdfs.size(dfs.id)))
    desc <- rbind(desc, c("parts", hdfs.parts(dfs.id)))
    desc
}

##
#' Returns number of rows and columns of an HDFS object. Normally dimensions
#' are stored in ORCH metadata alongside with an HDFS object and the function
#' can simply return known values. If dimensions are not known then this
#' function will try to figure it out by downloading the data set or running
#' a mapReduce jobs. After it's done ORCH metadata will be updated on HDFS
#' to cache discovered values and do not repeat the same counting job again
#' next time the function is called.
#' 
#' @param dfs.id HDFS object identifier to investigate.
#' @param force Do not ask confirmation for running a mapReduce job. This
#'     parameter must be set to TRUE if a script is intended to be run in
#'     a batch mode, e.g. unattended execution. \p force implicitely enables
#'     silent execution.
#' @return Vector c(rows, columns). If any of the values is unknown for any
#'    reason the it will have value -1.
#' 
#' @seealso hdfs.nrow
#' @seealso hdfs.ncol
##
hdfs.dim <- function(
    dfs.id, 
    force = FALSE)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.id, "string")
    
    # Read metadata for the specified HDFS object.
    metaObj <- NULL
    while (TRUE) {
        meta <- hdfs.mget(dfs.id)
        if (!is.null(meta)) {
            metaObj <- .parse.meta(list(), meta)
            dim <- attr(metaObj, "orch.dim", exact=T)
            if (is.null(dim)) {
                dim <- c(-1,-1)
            }
            break
        }
        else {
            orch.dloge("metadata was not found in HDFS", cat=T)
            dfs.id <- hdfs.attach(dfs.id, force=T)
            if (is.null(dfs.id)) {
                orch.dloge("attach failed")
                break
            }
        }
    }
    
    # Now try to recover unknow bits of data
    update <- F
    if (is.null(metaObj)) {
        # we will end up here if we absolutely failed to understand the
        # input data structure and value types. at this case there is
        # nothing we can do to but fail.
        orch.dloge("HDFS data structure is unknown", cat=T)
    }
    else {
        if (dim[1] < 1) {
            orch.dlogw("number of rows is unknown", cat=!force)
            fsize <- hdfs.size(dfs.id)
            if (fsize < 1*MB && 
                    (force || .orch.prompt("download HDFS data"))) {
                # for relatively small data we can simply download the data
                # and then parse it locally to count number of "\n" chars.
                # This is faster than running MR count job because we avoid
                # constant Hadoop job spinup latency.
                orch.dlog.info("size < 1MB, downloading HDFS files")
                tmpf <- hdfs.download(dfs.id)
                out <- .sh.cmd("wc", tmpf)
                if (.sh.error() != 0) {
                    orch.dloge("error counting number of lines with \"wc\"")
                }
                else { 
                    out <- strsplit(out, ' ', fixed=T)[[1]]
                    out <- out[out != '']
                    nrow <- as.numeric(out[1])
                    if (is.null(nrow) || is.na(nrow)) {
                        orch.dloge("error parsing \"wc\" output")
                    }
                    else {
                        dim[1] <- nrow
                        update <- T
                    }
                }
            }
            else if (force || .orch.prompt("run mapReduce job")) {
                # the last resort on a large data set is to spinup a mapReduce
                # job just to count number of rows. This way we don't need
                # to bring data into local file system, e.g. we support any
                # size data set.
                orch.dlog.info("running mapReduce job")
                x <- hadoop.run(dfs.id,
                    mapper = function(k, v) {
                        orch.keyval(NULL, nrow(v))
                    },
                    reducer = function(k, v) {
                        orch.keyval(NULL, sum(v$nrow))
                    },
                    config = new("mapred.config",
                        job.name = sprintf("hdfs.dim(%s)", dfs.id),
                        map.input = "data.frame",
                        map.output = data.frame(key=NA, nrow=0L),
                        map.split = 100000, # ? find the best value
                        reduce.input = "data.frame",
                        reduce.output = data.frame(key=NA, nrow=0L))
                        # @TODO (vlad): turn of parser in ORCH driver
                )
                nrow <- hdfs.get(x)
                if (is.null(nrow)) {
                    orch.dloge("mapReduce job failed, see logs", cat=T)
                }
                if (any(dim(nrow) != c(1,1))) {
                    orch.dloge("got unexpected multiple result", cat=T)
                }
                else {
                    dim[1] <- nrow[[1]]
                    update <- TRUE
                }
            }
        }
        if (dim[2] < 1) {
            # if we don't know number of columns we can extract this info
            # from other meta attributes like types definitions.
            types <- attr(metaObj, "orch.types", exact=T)
            coln <- length(types)
            if (coln < 1) {
                orch.dloge("can't identify number of columns", cat=T)
            }
            else {
                dim[2] <- coln
                update <- T
            }
        }
    }

    # Overwrite ORCH meta data in HDFS. This will update the "dim" attribute
    # and next time hdfs.dim is called we'll just return its value.
    if (update && !is.null(metaObj)) {
        orch.dlog.info("metadata for \"%s\" has changed, updating", dfs.id)
        attr(metaObj, "orch.dim") <- dim
        meta <- .paste.meta(metaObj)
        hdfs.mput(dfs.id, meta, overwrite=T)
    }
    
    # All done.
    names(dim) <- c("rows", "columns")
    as.integer(dim)
}

##
#' Returns number of rows of an HDFS object. See hdfs.dim for detailed 
#' description of its functionality and parameters.
#' 
#' @param dfs.id HDFS object to describe.
#' @param force Don't ask mapReduce job confirmation.
#' @return number of rows
#' 
#' @seealso hdfs.dim
#' @seealso hdfs.ncol
##
hdfs.nrow <- function(
    dfs.id, 
    force = FALSE)
{
    hdfs.dim(
        dfs.id = dfs.id, 
        force = force)[1]
}

##
#' Returns number of columns of an HDFS object. See hdfs.dim for detailed 
#' description of its functionality.
#' 
#' @param dfs.id HDFS object to describe.
#' @param force Don't ask mapReduce job confirmation.
#' @return number of rows
#' 
#' @seealso hdfs.dim
#' @seealso hdfs.nrow
##
hdfs.ncol <- function(
    dfs.id, 
    force = FALSE)
{
    hdfs.dim(
        dfs.id = dfs.id, 
        force = force)[2]
}

##
#' Returns the last \p n lines of the specified HDFS file withput any parsing.
#' Due to HDFS design restrictions tail is concatinated from tails of each part
#' file of HDFS file, not the real \p n last lines.
#' 
#' @param dfs.id HDFS object
#' @param n number of tail lines to return
#' 
#' @return vector of strings
#' @return NULL if file does not exist
#' 
#' @seealso hdfs.head
#' @seealso hdfs.sample
#' @seealso hdfs.download
##
hdfs.tail <- function(dfs.id, n=10)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.id, "string")
    .orch.test.input.stop(n, "numeric")
    .orch.test.special.stop(n, "positive", function(x) x>=0)
    
    if (n <= 0) {
        return (NULL)
    }
    ret <- c()
    parts <- rev(.dfs.list(dfs.id))
    if (!is.null(parts)) {
        nret <- 0
        for (part in parts) {
            tail <- hdfs.ftail(dfs.id, part, tail=F)
            ntail <- length(tail)
            nret <- nret + ntail
            if (nret > n) {
                ret <- c(tail[(nret-n+1):ntail], ret)
                nret <- n
                break
            }
            else {
                ret <- c(tail, ret)
                next
            }
        }
        if (nret < n) {
            orch.dlogw("retrieved only %d tail lines < %d", 
                nret, n, cat=T)
        }
    }
    ret
}

##
#' Returns the first \p n lines of the specified HDFS file withput any parsing.
#' Due to HDFS design restrictions tail is concatinated from tails of each part
#' file of HDFS file, not the real \p n last lines.
#' 
#' @param dfs.id HDFS onject
#' @param n number of head lines to return
#' 
#' @return vector of strings
#' @return NULL if file does not exist
#' 
#' @seealso hdfs.tail
#' @seealso hdfs.sample
#' @seealso hdfs.download
##
hdfs.head <- function(dfs.id, n=10)
{
    # Check inputs. 
    .orch.test.input.stop(dfs.id, "string")
    .orch.test.input.stop(n, "numeric")
    .orch.test.special.stop(n, "positive", function(x) x>=0)
    
    if (n <= 0) {
        return (NULL)
    }
    fsize <- hdfs.size(dfs.id)
    if (fsize == 0) {
        orch.dlogw("zero file size, nothing to do")
        ret <- c()
    }
    else if (fsize <= 10*KB) {
        orch.dlog.info("small file size, streaming")
        ret <- c()
        parts <- .dfs.list(dfs.id)
        if (!is.null(parts)) {
            nret <- 0
            for (part in parts) {
                lines <- .hal.dfs.cat(.dfs.mkpath(dfs.id, part))
                nlines <- length(lines)
                nret <- nret + nlines
                if (nret > n) {
                    ret <- c(ret, lines[1:(nlines-nret+n)])
                    nret <- n
                    break
                }
                else {
                    ret <- c(ret, lines)
                    next
                }
            }
            if (nret < n) {
                orch.dlogw("retrieved only %d lines < %d", 
                    nret, n, cat=T)
            }
        }
    }
    else {
        orch.dlog.info("large file size, downloading")
        fname <- hdfs.download(dfs.id)
        ret <- readLines(fname, n)
    }
    (ret)
}

## ------------------------------------------------------------------------- ##
##                      EXPERIMENTAL PUBLIC FUNCTIONS                        ##
## ------------------------------------------------------------------------- ##

##
#' Loads a local file into HDFS.
#
#' This is the simpiest possible way to transfer data to HDFS from a local
#' storage.  It just replicates the local file into HDFS directory. By default
#' the HDFS directory get a unique ID and the HDFS file is named "part-00000".
#'
#' @param filename local file name to put to HDFS
#' @param dfs.name how to name the HDFS directory
#' @param dfs.file name of the file with the data
#' @param overwrite replace HDFS directory if already exists
#' @param silent expect errors, don't report them
#'
#' @return HDFS object ID of the loaded data | NULL if error
#' @note The loaded data has no metadata at this point.
##
hdfs.fput <- function(
        filename, 
        dfs.name = NULL, 
        dfs.file = NULL,
        overwrite = FALSE,
        silent = FALSE)
{
    # Check input parameters.
    .assert(.orch.test.input(filename, "character"))
    .assert(.orch.ntest.input(dfs.name, "character"))
    .assert(.orch.ntest.input(dfs.file, "character"))
    .assert(.orch.test.input(overwrite, "logical"))
    .assert(.orch.test.input(silent, "logical"))
    
    # Prepare copy parameters.
    if (is.null(dfs.name)) {
        dfs.name <- .orch.uid()
    }
    if (is.null(dfs.file)) {
        dfs.file <- "part-00000"
        orch.dlog.info("using default HDFS file name \"%s\"", dfs.file)
    }
    dfs.fname <- .dfs.mkpath(dfs.name, dfs.file)
    dfs.fpath <- .dfs.path(dfs.fname, stop=T)
    
    # Check HDFS file system readiness.
    if (hdfs.exists(dfs.fname)) {
        if (overwrite) {
            hdfs.rm(dfs.fname, force=T) # ignore errors
        }
        else {
            orch.dloge("\"%s\" already exists", dfs.name)
            return(NULL)
        }
    }
    
    # Try to copy data from the local file system to HDFS.
    out <- .hal.dfs.put(.sh.path(filename), dfs.fpath)
    if (.sh.error() != 0) {
        if (!silent) {
            orch.dloge("failed to write HDFS file \"%s\"", dfs.fname)
        }
        orch.dlog.debug("+Hadoop+ \"%s\"", out)
        hdfs.rm(dfs.fpath, force=T)
        NULL
    }
    else if (hdfs.exists(dfs.fname)) {
        # success!
        .as.dfs.id(dfs.name)
    }
    else {
        # unxpected error
        orch.dloge('HDFS file "%s" is missing', dfs.fpath)
        NULL
    }
}

##
#' Stores metadata for an HDFS object. Normally metadata will be stored 
#' alogside with the HDFS object but other storage layers can be used too
#' like Hive metastore or a SQL database.
#' 
#' @param dfs.id target HDFS object identifier.
#' @param meta metadata as a string or as an object with attributes.
#' @param overwrite update metadata overwriting the old one.
#' @param validate verify that stored metadata is valid.
#' 
#' @return HDFS object ID of the written data.
#' @return NULL if error is detected.
#' 
#' @seealso hdfs.mget
##
hdfs.mput <- function(
        dfs.id,
        meta, 
        overwrite = FALSE,
        validate = TRUE)
{
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    
    # Check input parameters.
    .assert(.orch.test.special(dfs.id, "HDFS object", .is.dfs.id_or_path))
    .assert(.orch.test.input(meta, "character"))
    .assert(.orch.test.input(overwrite, "logical"))
    .assert(.orch.test.input(validate, "logical"))
    
    if (validate) {
        .parse.meta(list(), meta, 
            stop=T, 
            validate=T)
    }
    tmp <- .orch.tmpfile()
    cat(meta, file=tmp)
    orch.dlog.debug("writing metadata to \"%s\"", dfs.id)
    dfs.id <- hdfs.fput(
        filename = tmp, 
        dfs.name = .dfs.path(dfs.id),
        dfs.file = '__ORCHMETA__',
        overwrite = overwrite)
    if (!is.null(dfs.id)) {
        .orch.hcache.mput(dfs.id, meta)
    }
    if (!.orch.env$keep.tmp) {
        .orch.unlink(tmp)
    }
    
    # All done.
    orch.dlogo(t=.t)
    dfs.id
}

##
#' Retreives an HDFS file into a local file.
#' @attention Retreives only _one_ HDFS file at a time.
#' 
#' This function is designed to copy only one HDFS file at a time to the local
#' file system. You can select a specific file from the HDFS object directory
#' by specifying \p dfs.file. If this parameter is not specified then the first 
#' non-system (e.g. without "_" prefix) file from lexicographically sorted list 
#' of files from the HDFS object directory will be retreived.
#' 
#' Local copy by defalut is stored in a temporary file that will be deleted at 
#' the end of R's session. This can be overwritten with \p filename parameter
#' but then caller is responsible for removing this file when not needed any
#' more
#' 
#' @param dfs.id HDFS object to retreive
#' @param dfs.file name of the specific file to retrive. 
#' @param filename local file name and path.
#' @param overwrite allow replacement of the target local file.
#' @param silent do not report any error messages.
#' 
#' @return local file name containing the retreived data
#' @return NULL if an error has occured.
##
hdfs.fget <- function(
        dfs.id, 
        dfs.file,
        filename = NULL,
        max.size = 0, 
        overwrite = FALSE,
        silent = FALSE)
{
    # Check input parameters.
    .assert(.orch.test.special(dfs.id, "HDFS object", .is.dfs.id_or_path))
    .assert(.orch.test.input(dfs.file, "character"))
    .assert(.orch.ntest.input(filename, "character"))
    .assert(.orch.test.input(max.size, "positive"))
    .assert(.orch.test.input(overwrite, "logical"))
    .assert(.orch.test.input(silent, "logical"))
    
    # Check source and target file names.
    if (is.null(filename)) {
        filename <- .orch.tmpfile()
        orch.dlog.info('using temp file name "%s"', filename)
    }
    if (missing(dfs.file)) {
        dfs.file <- .dfs.find.data.file(dfs.id, cat=!silent)
        if (is.null(dfs.file)) {
            return (NULL)
        }
        orch.dlog.info("using default HDFS file name \"%s\"", 
            dfs.file)
    }
    
    # Check local file system readiness.
    if (file.exists(filename)) {
        if (overwrite) {
            .orch.unlink(filename) # ignore errors
        }
        else {
            if (!silent) {
                orch.dloge('collision, "%s" already exists', filename)
            }
            return(NULL)
        }
    }
    .assert(!is.null(dfs.file))
    .assert(!is.null(filename))
    
    # Try to copy data from HDFS to the local file system.
    dfs.fname <- paste(.dfs.path(dfs.id), '/', dfs.file, sep='')
    if (max.size > 0) {
        # Maximum file size to read is specified then we have to switch to
        # a so-called async execution mode when we start "hadoop dfs -get"
        # command as a background process and wait until retreived data size
        # will exceed the requested amount. 
        pid <- .hal.dfs.aget(dfs.fname, .sh.path(filename))
        if (.sh.error() != 0) {
            if (!silent) {
                orch.dloge('failed to start async read of HDFS file "%s"', dfs.fname)
            }
            .orch.unlink(filename)
            return(NULL)
        }
        else {
            while (.sh.running(pid)) {
                size <- null.to(file.info(filename)$size, 0)
                print(size)
                if (size >= max.size) {
                    .sh.kill(pid)
                    break
                }
            }
        }
    }
    else {
        # If maximum size is not specified then we need to read all the data
        # from HDFS which is a default mode of operation. At this case we
        # simply running sync "hadoop dfs -get" and wait till it's done.
        out <- .hal.dfs.get(dfs.fname, .sh.path(filename))
        if (.sh.error() != 0) {
            if (!silent) {
                orch.dloge('failed to sync read HDFS file "%s"', dfs.fname)
            }
            orch.dlog.debug('+Hadoop+ "%s"', out)
            .orch.unlink(filename)
            return(NULL)
        }
    }
    if (file.exists(filename)) {
        # success
        filename
    }
    else {
        orch.dloge('local file "%s" is missing', filename)
        NULL
    }
}

##
#' Retreives metadata for an HDFS object. Normally metadata will be stored 
#' alogside with the HDFS object but other storage layers can be used too
#' like Hive metastore or a SQL database.
#' 
#' @param dfs.id target HDFS object identifier.
#' @param validate verify that retreived metadata is valid.
#' 
#' @return Vector of strings containing the retreived data. 
#' @return NULL if error or metadata does not exists.
#' 
#' @note This function will not try to attach an HDFS object if instead of
#'     HDFS object you will pass a string HDFS path like many other hdfs.*
#'     function do. Attaching would trigger parsing and automatic metadata
#'     creation that we try to avoid in this case.
#' 
#' @seealso hdfs.mput
##
hdfs.mget <- function(
        dfs.id, 
        validate = T)
{
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    
    # Check input parameters.
    .assert(.orch.test.special(dfs.id, "HDFS object", .is.dfs.id_or_path))
    .assert(.orch.test.input(validate, "logical"))
    
    # First check if the hcache has it.
    meta <- .orch.hcache.mget(dfs.id)
    if (is.null(meta)) {
        # and then check HDFS
        tmp <- .orch.tmpfile()
        orch.dlog.debug("reading metadata from \"%s\"", dfs.id)
        tmp <- hdfs.fget(
            dfs.id = dfs.id,
            dfs.file = '__ORCHMETA__',
            filename = tmp,
            overwrite = T,
            silent = T)
        meta <- NULL
        if (!is.null(tmp)) {
            meta <- readLines(tmp)
            if (!.orch.env$keep.tmp) {
                .orch.unlink(tmp)
            }
        }
        if (!is.null(meta)) {
            .orch.hcache.mput(dfs.id, meta)
        }
    }
    if (!is.null(meta) && validate) {
        .parse.meta(list(), meta, 
            stop=T, 
            validate=T)
    }
    
    # All done.
    orch.dlogo(t=.t)
    meta
}

##
#' Returns one specifiec file size of the HDFS object in bytes.
#' Non-existing objects will report size 0.
#'
#' @param dfs.id HDFS object identifier
#' @param dfs.file HDFS file name
#' 
#' @return the HDFS file size in bytes
#' @return 0 if object/file does not exist in HDFS
#'
#' @seealso hdfs.size
#' @seealso hdfs.parts
#' @seealso hdfs.ls
##
hdfs.fsize <- function(
        dfs.id, 
        dfs.file)
{
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    
    # Check input parameters.
    .assert(.orch.test.special(dfs.id, "HDFS object", .is.dfs.id_or_path))
    .assert(.orch.test.input(dfs.file, "character"))
    
    dfsPath <- .dfs.mkpath(.dfs.path(dfs.id, stop=T), dfs.file)
    dfsFiles <- .hal.dfs.ls(dfsPath)
    if (.sh.error() == 0) {
        fsize <- NULL
        for (f in dfsFiles) {
            isTheFile <- regexpr(dfsPath, f, fixed=T)[1]
            if (isTheFile > 0) {
                # extract "size" column from "ls" output
                sizeStr <- rev(strsplit(f, ' ')[[1]])[4]
                fsize <- suppressWarnings(as.numeric(sizeStr))
                if (is.na(fsize)) {
                    # "ls" output format has changed, internal failure
                    orch.dlog.stop("can't parse Hadoop output", cat=T)
                }
                break
            }
        }
        if (is.null(fsize)) {
            # "ls" command output is missing the file we are looking for,
            # this is unexpected but likely to indicate that the file is not 
            # present. we may continue execution.
            orch.dloge("unexpected Hadoop output")
            fsize <- 0
        }
    }
    else {
        # shell errorlevel != 0
        orch.dlogw("file \"%s\" not found", dfsPath)
        fsize <- 0
    }
    
    orch.dlogo(t=.t)
    fsize
}

##
#' Return content of the specified HDFS file. Chooses streaming or downloading
#' of the file content based of the file size to improve performance.
#' 
#' @param dfs.id HDFS object ID.
#' @param dfs.file HDFS filename to cat (by default chooses random).
#' @param timeout Maximum number of second to stream.
#' 
#' @return A vector of strings.
#' @return NULL if file does not exist or empty.
##
hdfs.fcat <- function(
        dfs.id, 
        dfs.file,
        timeout = 0)
{
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    
    # Check input parameters.
    .assert(.orch.test.special(dfs.id, "HDFS object", .is.dfs.id_or_path))
    .assert(.orch.mtest.input(dfs.file, "character"))
    .assert(.orch.test.input(timeout, "positive"))
    
    if (missing(dfs.file)) {
        dfs.file <- .dfs.find.data.file(dfs.id, cat=T)
        if (is.null(dfs.file)) {
            return(NULL)
        }
        orch.dlog.info("using 1st HDFS file name \"%s\"", 
            dfs.file)
    }
    fsize <- hdfs.fsize(dfs.id, dfs.file)
    if (fsize == 0) {
        orch.dlogw("zero file size, nothing to do")
        lines <- c()
    }
    else if (fsize <= .orch.env$fcat.threshold || 
        timeout > 0)
    {
        dfs.fname <- .dfs.mkpath(.dfs.path(dfs.id), dfs.file)
        if (!hdfs.exists(dfs.fname)) {
            orch.dloge("file \"%s\" does not exist", 
                dfs.fname, cat=T)
            lines <- NULL
        }
        else {
            if (fsize <= .orch.env$fcat.threshold) {
                orch.dlog.info("small file size, streaming")
                lines <- .hal.dfs.cat(dfs.fname)
            }
            else {
                .assert(timeout > 0)
                orch.dlog.info("large file size, async streaming")
                lines <- .hal.dfs.acat(dfs.fname, timeout)
            }
            if (.sh.error() != 0 && !.sh.killed()) {
                orch.dloge("error accessing \"%s\" file", 
                    dfs.fname, cat=T)
                lines <- character()
            }
        }
    }
    else {
        .assert(timeout <= 0)
        orch.dlog.info("large file size, downloading")
        tmpf <- .orch.tmpfile()
        hdfs.fget(dfs.id, dfs.file, tmpf)
        if (.sh.error() != 0) {
            .orch.unlink(tmpf)
            orch.dloge("error accessing \"%s\" file", 
                dfs.fname, cat=T)
            lines <- character()
        }
        else {
            lines <- readLines(tmpf)
            if (!.orch.env$keep.tmp) {
                .orch.unlink(tmpf)
            }
        }
    }
    
    # All done, stop timer.
    orch.dlogo(t=.t)
    lines
}

##
#' Retreives an HDFS file last \p n lines of data. This functions ensures that
#' the requested number of _complete_ lines is retreived from an HDFS file.
#' Due to limitation of Hadoop's "tail" command it can fall back to "cat" or
#' "get" command if "tail" can't return \p n lines of the file's tail (can be
#' disabled via tail=T argumnet).
#' 
#' @param dfs.id HDFS object ID.
#' @param dfs.file Filename to get its tail (by default last part)
#' @param n Number of lines to return, 0 = return all read.
#' @param tail Restrict result to tailing lines one, may cause failure.
#' 
#' @return vector of retreived lines
#' @return NULL if file does not exist or empty.
##
hdfs.ftail <- function(
        dfs.id, 
        dfs.file,
        n = 0,
        tail = FALSE)
{
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dlogp2()
    orch.dbg.newtimer()
    
    # Check input parameters.
    .assert(.orch.test.special(dfs.id, "HDFS object", .is.dfs.id_or_path))
    .assert(.orch.mtest.input(dfs.file, "character"))
    .assert(.orch.test.input(n, "numeric"))
    .assert(.orch.test.input(tail, "logical"))
    
    # Read tail of the file from HDFS.
    if (missing(dfs.file)) {
        dfs.file <- .dfs.find.data.file(dfs.id, last=T)
        if (is.null(dfs.file)) {
            return(NULL)
        }
        orch.dlog.info('using default HDFS file name "%s"', 
            dfs.file)
    }
    dfsPath <- .dfs.mkpath(.dfs.path(dfs.id), dfs.file)
    lines <- .hal.dfs.tail(dfsPath)
    nlines <- length(lines)
    nbytes <- sum(nchar(lines)) + length(lines)
    orch.dlogv2(
        nlines,
        nbytes,
        n)
    
    # HDFS file size if expencive to get and it's used in two logical 
    # conditions, get the size upfront if one of the conditions will be hit.
    if (nbytes >= 1*KB) {
        fsize <- hdfs.fsize(dfs.id, dfs.file)
        orch.dlogv(fsize)
    }
    
    # Now the specified # of tail lines. If not possible due to line size
    # then fall back to reading the whole file.
    out <- NULL
    if (nbytes < 1*KB || nbytes >= fsize)
    {
        # File is so small that it fit completely into -tail command output.
        # This guarantees that lines were read complete, not need to drop 1st.
        out <- if (nlines > n) {
            if (n <= 0) {
                lines
            } else {
                lines[(nlines-n+1):nlines]
            }
        } else {
            orch.dlogw("can't get %g record%s, file is too small", n, .s(n))
            lines
        }
    }
    else if (nlines > 1 && nlines > n)
    {
        # 1st line must be removed in any case as there is a high chance
        # that his line was truncated by the Haddop's -tail command.
        out <- if (n <= 0) {
            lines[-1]
        } else {
            lines[(nlines-n+1):nlines]
        }
    }
    else if (fsize <= .orch.env$ftail.max.download) 
    {
        # Worst case is when we can't read complete # of lines as requiested
        # using -tail command and have to fall back to reading whole file.
        orch.dlogw("can't get %g full record%s via tail command", n, .s(n))
        orch.dlog.info("falling back to reading whole file from HDFS")
        lines <- hdfs.fcat(dfs.id, dfs.file)
        out <- if (n <= 0) {
            # return all what we've got
            lines
        }
        else {
            nlines <- length(lines)
            if (nlines > n) {
                # restrict output lines to required
                lines[(nlines-n+1):nlines]
            }
            else {
                # this is all file has, can't get more
                if (nlines < n) {
                    orch.dlogw("file \"%s\" has %d lines < %d",
                        dfsPath, nlines, n)
                }
                lines
            }
        }
    }
    else if (!tail)
    {
        # File is too large for reading it from HDFS, try to use async streaming
        # from HDFS with timeout. This will break the tail concept because we'll
        # get lines from some position in a middle of the HDFS file.
        timeout <- .orch.env$ftail.timeout
        retry <- 1
        while (retry >= 0) {
            orch.dlog.info("trying async HDFS cat with timeout %d", timeout)
            lines <- hdfs.fcat(dfs.id, dfs.file, timeout=timeout)
            out <- if (n <= 0) {
                # return all what we've got
                retry <- -1
                lines
            }
            else {
                nlines <- length(lines)
                if (nlines > n) {
                    # restrict output lines to required
                    retry <- -1 # end
                    lines[(nlines-n+1):nlines]
                }
                else {
                    # retry
                    timeout <- ceiling(timeout*(nlines/n))
                    retry %-=% 1
                    if (retry < 0) {
                        lines
                    }
                }
            }
        }
        nlines <- length(out)
        if (nlines < n) {
            orch.dlogw("can't get %d lines from \"%s\", got %d",
                n, dfsPath, nlines)
        }
    }
    else {
        # File is too large for reading it from HDFS, return at least lines
        # that we were able to read with "-tail" command. 1st line must be 
        # removed as it's most likely was truncated by the Haddop's "-tail" 
        # command.
        out <- if (n < 2) {
            orch.dloge("failed to read tail lines")
            NULL
        }
        else {
            orch.dloge("can't get %g record%s, file is too large", n, .s(n))
            lines[-1]
        }
    }

    # All done, stop timer.
    orch.dlogo(t=.t)
    out
}

##
#' Returns currently configured or sets a new value system-wide default key 
#' separator. Key separator is used in HDFS text based files to separate key 
#' from values. E.g.:
#'     key<key_separator>value1,value2...
#' 
#' Note that key separator can be altered at the time of writing data to
#' HDFS for a specific object. The key separator then gets stored in HDFS 
#' object's metadata and default system-wide value is not used at the time
#' of reading this object back from HDFS. This default value is used only 
#' when writing new data to HDFS or if anexisting object does not have
#' key seprator stored in its metadata.
#' 
#' @param key.sep New key separator to set (optional).
#' @return Currently configured system-wide key separator.
#' 
#' @seealso hdfs.valuesep
#' @seealso hdfs.delim
##
hdfs.keysep <- function(key.sep)
{
    .orch.mtest.input.stop(key.sep, "character")
    if (!missing(key.sep))
    {
        oldKeySep <- .orch.env$key.sep
        if (oldKeySep != key.sep) {
            .orch.env$key.sep <- key.sep
            orch.dlog.info("changed key separator from '%s' to '%s'", 
                oldKeySep, key.sep)
        }
        else {
            orch.dlog.info("key separator is '%s'", key.sep)
        }
    }
    .orch.env$key.sep
}

##
#' Returns currently configured or set a new value of system-wide value 
#' separator. Value separator is used in HDFS text based files to separate 
#' values. E.g.:
#'     key\tvalue1<values_separator>value2<value_separator>...
#' 
#' Note that velue separator can be altered at the time of writing data to
#' HDFS for a specific object. The value separator then gets stored in HDFS 
#' object's metadata and default system-wide value is not used at the time
#' of reading this object back from HDFS. This default value is used only 
#' when writing new data to HDFS or if an existing object does not have
#' value seprator stored in its metadata.
#' 
#' @param value.sep New value separator to set (optional).
#' @return Currently configured system-wide value separator.
#' 
#' @seealso hdfs.keysep
#' @seealso hdfs.delim
##
hdfs.valuesep <- function(val.sep)
{
    .orch.mtest.input.stop(val.sep, "character")
    if (!missing(val.sep))
    {
        oldValSep <- .orch.env$val.sep
        if (oldValSep != val.sep) {
            .orch.env$val.sep <- val.sep
            orch.dlog.info("changed value separator from '%s' to '%s'", 
                oldValSep, val.sep)
        }
        else {
            orch.dlog.info("value separator is '%s'", val.sep)
        }
    }
    .orch.env$val.sep
}

##
#' Returns currently configured or set a new value of system-wide key and value 
#' separators. Key and value separator is used in HDFS text based files to 
#' split key from values and values from each other. E.g.:
#'     key<key_separator>value1<values_separator>value2<value_separator>...
#' 
#' Note that key and velue separators can be altered at the time of writing 
#' data to HDFS for a specific object. Both key and value separators then get 
#' stored in HDFS object's metadata and default system-wide value is not used 
#' at the time of reading this object back from HDFS. This default value is 
#' used only when writing new data to HDFS or if an existing object does not 
#' have key or value seprator stored in its metadata.
#' 
#' @param key New key separator to set (optional).
#' @param value New value separator to set (optional).
#' @return Currently configured system-wide value c(key,value) separators.
#' 
#' @seealso hdfs.keysep
#' @seealso hdfs.valuesep
##
hdfs.delim <- function(key, value)
{
    c(hdfs.keysep(key), hdfs.valuesep(value))
}

##
#' Retreives and updates ORCH metadata for an HDFS object. If no attributes
#' to update are given in \p ... then returns a list of present meta attributes. 
#' If any attributes are specified as "name=value" in \p ... parameter then
#' updates given attributes in HDFS object metadata.
#' 
#' @example
#'     hdfs.meta("cars") -> return list of attributes
#'     hdfs.meta("cars", pristine=T) -> sets "orch.pristine" to TRUE in HDFS.
#'     hdfs.meta("cars", bad_attr=T) -> error, unknown attribute.
#'     hdfs.meta("cars", custorm_attr=T, relax=T) -> ok, attribute allowed.
#' 
#' @param dfs.id HDFS object ID.
#' @param ... List of attributes and values to updated.
#' @param force Don't check for invalid or unknown attributes.
#' @return List of attributes if user attributes to set are not specified in 
#'     [...]. Otherwise return TRUE if all attributes were set, or FALSE if any
#'     attribute was not set for some reason.
#' 
#' @seealso hdfs.describe
#' @seealso hdfs.attach
##
hdfs.meta <- function(dfs.id, ..., force = FALSE)
{
    # Check input parameters.
    .orch.test.special.stop(dfs.id, "HDFS object", .is.dfs.id_or_path)
    .orch.test.input.stop(force, "logical")
    
    # List of read/write meta attributes.
    writableAttr <- c(
        "orch.kvs",
        "orch.types",
        "orch.names",
        "orch.class",
        "orch.keyi",
        "orch.rownamei",
        "orch.key.sep",
        "orch.value.sep",
        "orch.origin",
        "orch.dim",
        "orch.pristine",
        "orch.quote",
        "orch.categorized",
        "orch.trim"
    )

    # List of read-only system meta attributes.
    readonlyAttr <- c(
        "orch.desc.name",
        "orch.desc.Sclass",
        "orch.desc.type",
        "orch.desc.len",
        "orch.desc.precision",
        "orch.desc.scale",
        "orch.desc.isVarLength",
        "orch.desc.nullOK"
    )
    
    # List of all "officially" supported meta attributes.
    supportedAttr <- c(
        writableAttr,
        readonlyAttr
    )
    
    userAttr <- list(...)
    meta <- hdfs.mget(dfs.id)
    if (is.null(meta)) {
        # no HDFS object or never attached
        orch.dloge("can't read metadata from \"%s\"", dfs.id, cat=T)
        if (length(userAttr) == 0) {
            # RETURN: no ORCHMETA -> empty attributes
            list()
        }
        else {
            # RETURN: can't set attributes
            FALSE
        }
    }
    else {
        metaObj <- .parse.meta(list(), meta)
        if (length(userAttr) == 0)
        {
            # drop "orch." prefix from attributes
            hdfsAttr <- attributes(metaObj) 
            for (attrName in names(hdfsAttr))
            {
                attr <- substring(attrName,6)
                if (!force && !begins(attrName, "orch.")) {
                    orch.dloge("invalid meta attribute \"%s\"", attr)
                }
                else if (!force && !(attrName %in% supportedAttr)) {
                    orch.dlogw("unknown meta attribute \"%s\"", attr)
                }
                else {
                    userAttr[[attr]] <- hdfsAttr[[attrName]]
                }
            }
            # RETURN: cleaned up set of all attributes
            userAttr
        }
        else if (is.null(names(userAttr)))
        {
            hdfsAttr <- attributes(metaObj) 
            ret <- list()
            for (attr in userAttr) {
                attrName <- paste0("orch.", attr)
                if (attrName %in% supportedAttr) {
                    ret[[attr]] <- hdfsAttr[[attrName]]
                }
                else {
                    orch.dlogw("unknown meta attribute \"%s\"", attr)
                }
            }
            # RETURN: subselection of attributes
            if (length(ret) == 1) {
                ret[[1]]
            }
            else if (length(ret) == 0) {
                NULL
            }
            else {
                ret
            }
        }
        else
        {
            # update attributes as write back to HDFS
            ok <- T
            updated <- F
            for (i in seq_along(userAttr))
            {
                attr <- names(userAttr)[i]
                if (attr == "") {
                    orch.dlogw("unnamed meta attribute \"%s\"", userAttr[i])
                    next
                }
                attrName <- paste0("orch.", attr)
                if (!force && !(attrName %in% supportedAttr)) {
                    orch.dloge("unknown meta attribute \"%s\"", attr, cat=T)
                    ok <- F
                }
                else if (!force && (attr %in% readonlyAttr)) {
                    orch.dlogw("readonly meta attribute \"%s\"", attr, cat=T)
                    ok <- F
                }
                else {
                    dfsVal <- attr(metaObj, attrName, exact=T)
                    newVal <- userAttr[[attr]]
                    if (is.null(dfsVal) != is.null(newVal) ||
                        is.na(dfsVal) != is.na(newVal) || 
                        any(dfsVal != newVal))
                    {
                        attr(metaObj, attrName) <- newVal
                        updated <- TRUE
                        orch.dlog.debug("meta attribute \"%s\" set = %s", 
                            attrName, toString(newVal))
                    }
                }
            }
            if (updated) {
                newMeta <- .paste.meta(metaObj)
                dfs.ok <- hdfs.mput(dfs.id, newMeta, overwrite=T)
                if (is.null(dfs.ok)) {
                    orch.dloge("error updating metadata in \"%s\"", dfs.id, cat=T)
                    ok <- F
                }
            }
            # RETURN: TRUE if all attributes were set
            ok
        }
    }
}

##
#' Synchronizes HDFS cache with HDFS file system. Must be used when an external
#' change of the HDFS object by another user or 3rd party process is expected
#' to change its content.
#' 
#' @param dfs.id HDFS object to sync up, or everything if not specified.
#' @return None.
##
hdfs.sync <- function(dfs.id)
{
    if (missing(dfs.id)) {
        .orch.hcache.reset()
    }
    else {
        .orch.test.special.stop(dfs.id, "HDFS object", .is.dfs.id)
        .orch.hcache.drop(dfs.id)
    }
}

##
#' Cleans a hdfs file by either removing the rows with missing values or 
#' putting default values in the missing cells
#' 
#' @param input is a valid dfs identifier/hdfs file with metdata attached.
#' @param 
#' @return None.
#'
#' @TODO (vlad) New Sukhendu's code, revise.
##
hdfs.cleanInput <- function(input, config = NULL, tmpdir = "/tmp", 
                            replace = TRUE, replace_val = NULL)
{

 # only valid for hdfs ids
 .orch.test.special.stop(input, "HDFS object", .is.dfs.id_or_path)

 statdir <- hdfs.mkdir(paste(tmpdir,"/", .orch.uid(), sep=""))
 # change permission to make the file writable
 .hal.dfs.sh(chmod='a+w', statdir[[1]])

 # initialize config object if not done so by the caller
 if (is.null(config)) {
   config = new("mapred.config",
        job.name = "pristinize",
        map.split = 0,
        map.input = "data.frame",
        hdfs.access = TRUE,
        map.output = .orch.outputmeta(input))

 }
 else {
   # HDFS access needs to be TRUE
   config@hdfs.access = TRUE
   if (length(config@map.output) == 0) 
    config@map.output = .orch.outputmeta(input)
 }

 replace_default <- data.frame("numeric"=0, "integer"=0, "logical" =FALSE, 
                               "character" = "", "factor" = as.factor(""), 
                               stringsAsFactors=FALSE)

 # replace with non-default user entered values
 if (!is.null(replace_val)) {
   if (!is(replace_val, "data.frame") ||
       !all(names(replace_val) %in% names(replace_default)))
     orch.dlog.stop("either replace_val is not a data.frame or the column names are not a subset of default column names")

   replace_default[names(replace_val)] <- replace_val
    
 }

 # Run the Map-only job
 dfsRes <- try( 
     hadoop.run(input,
     mapper = function(k,v) {
        if (replace) {
         res <- sapply(seq_len(length(v)), 
           function(i) {
             replaced_count <- 0
             col <- v[[i]]
             na  <- is.na(col)
             if (any(na)) {
                 replaced_count <- length(col[na])
                  v[[i]][na] <<- switch (class(col),
                                       "numeric"  = replace_default$numeric,
                                       "integer"  = replace_default$integer,
                                       "logical"  = replace_default$logical,
                                       "character"= replace_default$character,
                                       "factor"   = replace_default$factor,
                                       orch.dlog.stop("unsupported type")
                                      )
             }
             replaced_count
         })
        
         replaced_count <- sum(res)
        }
        else {
          naRows <- apply(v, 1, function(x) any(is.na(x)))
        }

        if (!is.null(k)) {
             if (replace) {
              na <- is.na(k)
              if (any(na)) {
                 replaced_count <- replaced_count + length(v[[i]][na])
                 k[na] <- switch(class(k), 
                                "numeric" = replace_default$numeric,
                                "integer" = replace_default$integer, 
                                "logical" = replace_default$logical,
                                "character" = replace_default$character, 
                                "factor" = replace_default$factor,
                                orch.dlog.stop("unsupported type"))
               }
           }
           else {
                naKeys <- sapply(k, function(x) is.na(x))
                naRows <- naRows | naKeys
          }
        }

        affected_count <- ifelse(replace, replaced_count, length(naRows[naRows]))
       
        tmpf <- tempfile(pattern = "orch", tmpdir = "/tmp")
        write.table(data.frame(affected_count, nrow(v), (nrow(v)*ncol(v))), 
                               tmpf, sep =',', col.names = FALSE, 
                               row.names = FALSE)

        hdfs.fput(tmpf, statdir[[1]], .orch.uid())
        
        if (replace)
            orch.keyvals(k, v)
        else
            orch.keyvals(k[!naRows],v[!naRows,])
    },
    reducer = NULL,
    export = orch.export(statdir, replace, replace_default),
    config = config
    ), silent = TRUE)

  if (inherits(dfsRes,"try-error")) {
    # cleanups
    hdfs.rm(statdir)
    orch.dlog.stop("Error returned by the Map Reduce job")
  }

  tmpf <- .orch.tmpfile() 
  .hal.dfs.sh(getmerge=statdir[[1L]], tmpf)
  out <- readLines(tmpf)
  out   <-  rowSums(sapply(out, function(y)
                              as.numeric(strsplit(y,',')[[1L]])))
  
  # display the statistics
  
  # output statistics:
  percent_affected <- ifelse (replace, ((out[[1L]]*100)/out[[3L]]), 
                             ((out[[1L]]*100)/out[[2L]]))
   
  cat(" Number of ", ifelse(replace, "values replaced: ", " rows removed: "),
      out[[1L]],"\n")
  cat(" Percentage of ", ifelse(replace, "values replaced: ", " rows removed: "),
      percent_affected,"\n")
  cat(" Total number of rows in the original input data: ", out[[2L]],"\n")

  # Set pristine to TRUE in the output metadata
  hdfs.meta(dfsRes, pristine = TRUE)

  # cleanups
  hdfs.rm(statdir)

  dfsRes
}
