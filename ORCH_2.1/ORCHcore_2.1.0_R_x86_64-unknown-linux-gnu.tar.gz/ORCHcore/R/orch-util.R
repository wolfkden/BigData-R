# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' Oracle R Connector for Hadoop utility functions library.
#' @name ORCH package
#' @docType package
##

###############################
# DO NOT INCLUDE ANY SOURCES! #
###############################

## ------------------------------------------------------------------------- ##
##                             GLOBAL VARIABLES                              ##
## ------------------------------------------------------------------------- ##

# Binary data size units.
KB <- 1024    # Kilobyte
MB <- 1024*KB # Meagbyte
GB <- 1024*MB # Gigabyte
TB <- 1024*GB # Terabyte
PB <- 1024*TB # Petabyte
EB <- 1024*PB # Exabyte
ZB <- 1024*EB # Zettabyte
YB <- 1024*ZB # Yottabye

# Decimal data size units.
K. <- 1000    # Thousand
M. <- 1000*K. # Million
G. <- 1000*M. # Billion
T. <- 1000*G. # Trillion
P. <- 1000*T. # Quadrillion
E. <- 1000*P. # Quintillion
Z. <- 1000*E. # Sextillion
Y. <- 1000*Z. # Septillion

## ------------------------------------------------------------------------- ##
##                             PRIVATE FUNCTIONS                             ##
## ------------------------------------------------------------------------- ##

##
#' Converts an integer to logical bits.
#' Example: .int2bits(2) -> c(F,T,F,...)
##
.int2bits <- function(x)
{
    as.logical(intToBits(x))
}

##
#' Converts logical bits into an integer.
#' Example: .bits2int(c(F,T,F,...)) -> 2
##
.bits2int <- function(b)
{
    as.integer(sum((2^(0:31))[b]))
}

##
#' Adjusts length of two vectors to be the same by repeating.
#' Example: .rep_length(c(1,2,3,4), c(1,2)) -> list(c(1,2,3,4), c(1,2,1,2))
##
.rep_length <- function(x, y)
{
    xl <- length(x)
    yl <- length(y)
    if (xl < yl) {
        if (yl %% xl) {
            orch.dlog.stop("[y] length is not a multiple of [x] length")
            return (NULL)
        }
        x <- rep(x, yl/xl)
    }
    else if (yl < xl) {
        if (xl %% yl) {
            orch.dlog.stop("[x] length is not a multiple of [y] length")
            return (NULL)
        }
        y <- rep(y, xl/yl)
    }
    .assert(length(x) == length(y))
    list(x=x, y=y)
}

##
#' Core of in-place operators like %+=%, %-=%, %*=%, %+/=%, etc. Assigns
#' value [val] to a parent variable or environment variable (if it's name
#' uses notation "env$name").
#' 
#' @seealso %+=%
#' @seealso %-=%
#' @seealso %*=%
#' @seealso %/=%
#' @seealso %c=%
##
.inplace.op <- function(a, val)
{
    a <- deparse(substitute(a, env=parent.frame()))
    xenv <- strsplit(a, "$", fixed=T)[[1]]
    if (length(xenv) == 1) {
        assign(a, val, envir=parent.frame(2))
    }
    else if (length(xenv) == 2) {
        assign(xenv[2], val, envir=get(xenv[1], envir=parent.frame(2)))
    }
    else {
        orch.dlog.stop("can't assign %s", a)
    }
    val
}

## ------------------------------------------------------------------------- ##
##                             PUBLIC FUNCTIONS                              ##
## ------------------------------------------------------------------------- ##

# Support for pre 2.15.x version of R.
if (!exists("paste0"))
{
    # This function was introduced in R-2.15.0.
    paste0 <- function(..., collapse=NULL)
    {
        paste(...,
            sep = '', 
            collapse = collapse)
    }
}
if (!exists("cat0"))
{
    # This function does not exist in R yet.
    cat0 <- function(..., file="", fill=FALSE, 
            labels=NULL, append=FALSE)
    {
        cat(..., 
            sep = '',
            file = file, 
            fill = fill, 
            labels = labels,
            append = append)
    }
}

##
#' Formats memory size in bytes to a human-readable form.
#' @example: 
#'     mem2str(1024) -> "1KB"
#'     mem2str(obj=1) -> "48B"
#' 
#' @param bytes Number of bytes to format as string.
#' @param round number of digits after ".", see ?round.
#' @param obj If \p bytes is not speficied, use object.size(obj) instead.
#' @return String with "human-readable" memory size.
##
mem2str <- function(
        bytes, 
        round = 2, 
        obj = NULL)
{
    if (missing(bytes)) {
        bytes <- object.size(obj)
    }
    if (bytes < KB) {
        units <- "B"
    }
    else if (bytes < MB) {
        bytes <- bytes / KB            
        units <- "KB"
    }
    else if (bytes < GB) {
        bytes <- bytes / MB            
        units <- "MB"
    }
    else if (bytes < TB) {
        bytes <- bytes / GB            
        units <- "GB"
    }
    else if (bytes < PB) {
        bytes <- bytes / TB            
        units <- "TB"
    }
    else {
        bytes <- bytes / PB            
        units <- "PB"
    }
    sprintf("%g%s", round(bytes, round), units)
}

##
#' Formats memory size to a human-readable form.
#' @example: 
#'     size2str(1000) -> "1K"
#'     size2str(obj=1) -> "48"
#' 
#' @param count Numeric count to format as string.
#' @param round Number of digits after ".", see ?round.
#' @param obj If \p count is not speficied, use object.size(obj) instead.
#' @return String with "human-readable" count.
##
size2str <- function(
        count, 
        round = 2,
        obj = NULL)
{
    if (missing(count)) {
        count <- object.size(obj)
    }
    if (count < K.) {
        units <- ""
    }
    else if (count < M.) {
        count <- count / K.
        units <- "K"
    }
    else if (count < G.) {
        count <- count / M.
        units <- "M"
    }
    else if (count < T.) {
        count <- count / G.
        units <- "G"
    }
    else if (count < P.) {
        count <- count / T.
        units <- "T"
    }
    else {
        count <- count / P.
        units <- "P"
    }
    sprintf("%g%s", round(count, round), units)
}

##
#' Replaces the x value with y if x is missing, 0-length, null, or NA.
#' Example: .null.to(NULL, "") -> ""
##
null.to <- function(x, y)
{
    if (missing(x) || 
        is.null(x) || 
        is.na(x) ||
        length(x) == 0)
    {
        x <- y
    }
    x
}

##
#' Replaces the x value with y if x is missing, 0-length, or an empty string.
#' Example: .empty.to("", "stdout") -> "stdout"
##
.empty.to <- function(x, y)
{
    if (missing(x)  ||
        length(x) == 0 || 
        (is.character(x) && x == ""))
    {
        x <- y
    }
    x
}

##
#' Flattens out a CSV+c() list.
#' Example: c('a,b','c') -> c('a','b','c').
##
str2csv <- function(x.csv, trim=F)
{
    ret <- c()
    x.str <-  as.character(x.csv)
    x.str <- gsub('\n', ' ', x.str)
    for (s in x.str) {
        toks <- strsplit(s, ',')[[1]]
        if (trim) {
            toks <- ore.str.trim(toks)
        }
        ret <- c(ret, toks)
    }
    ret
}

##
#' Converts a list to a CSV-string.
#' Example: c('1','2') -> '1,2'.
##
csv2str <- function(x, trim=FALSE, sep=',')
{
    ret = ''
    for (s in as.character(x)) {
        if (trim) {
            s = gsub("( *, *)", ',', s)
            s = gsub("( +$)|(^ +)", '', s)
        }
        ret = paste(ret,sep,s, sep='')
    }
    substring(ret, nchar(sep)+1)
}

##
#' Recursive gsub version. 
#' Repeats gsub() until no more replacements can be done.
##
rgsub <- function(
        pattern, 
        replacement, 
        x, 
        ignore.case = FALSE, 
        perl = FALSE,
        fixed = FALSE, 
        useBytes = FALSE)
{
    repeat {
        y <- gsub(
            pattern = pattern, 
            replacement = replacement, 
            x = x,
            ignore.case = ignore.case,
            perl = perl,
            fixed = fixed,
            useBytes = useBytes)
        if (y == x) {
            break
        }
        else {
            x <- y
        }
    }
    (x)
}

##
#' Concatinates two parts of a path into one and normalizes it. NULLs and NAs
#' are treated as "",  if one side is "" then no "/" is inserted between. Both
#' [left] and [right] arguments can be vectors.
#' 
#' @example 
#'     path("/a/", "/b/") -> "/a/b/"
#'     path(c("a","b"), "c") -> c("a/c", "b/c")
#'     path(c("a","b"), c("c","d")) -> c("a/c", "a/d", "b/c", "b/d")
#'     path("a", "b", "c") -> "a/b/c"
#'     path(c("a","b"), "c", "d") -> c("a/c/d", "b/c/d")
#' 
#' @param left Left-hand side of a path.
#' @param right Right-hand side of a path.
#' @param ... More right-hand sides to add.
#' @return "left/right/..." path(s).
##
path <- function(left, right, ...)
{
    left <- null.to(left, "")
    right <- null.to(right, "")
    .assert(is.character(left))
    .assert(is.character(right))
    
    ret <- c()
    for (l in left) {
        for (r in right) {
            sep <- ifelse(l!="" && r!="", "/", "")
            ret <- c(ret, rgsub("//", "/",
                sprintf("%s%s%s", l, sep, r),
                fixed=T))
        }
    }
    rr <- list(...)
    if (length(rr) > 0) {
        ret <- do.call(path, c(list(ret), rr))
    }
    
    .assert(is.character(ret))
    .scrub.path(ret)
}

##
#' Trims spaces from a string.
#' Example: strim(' a ') -> 'a'
##
strim <- function(s)
{
    s <- gsub("^ *", '', s)
    gsub(" *$", '', s)
}

##
#' Capitalizes only the 1st letter of a string or a collection of strings.
#' Examples: 
#'     cap('aa bB') -> 'Aa bB'
#'     cap('Aa bB', strict=T) -> 'Aa bb'
#'     cap(c('aa', 'bb')) -> c('Aa', 'Bb')
#' 
#' @param s a string(s) to capitalize
#' @param strict lower-case all other symbols
##
cap <- function(s, strict=F)
{
    sapply(s, 
        USE.NAMES = !is.null(names(s)),
        function(s) {
            A <- toupper(substring(s,1,1))
            b <- substring(s,2)
            paste(A, 
                if (strict) tolower(b) else b,
                sep = '', 
                collapse = ' ')
        })
}

##
#' Capitalizes 1st letters of every word in a string or a collection of strings.
#' Examples: 
#'     cap.all('aa bB') -> 'Aa BB'
#'     cap.all('aa bB', strict=T) -> 'Aa Bb'
#'     cap.all(c('aa bb', 'cc dd')) -> c('Aa Bb', 'Cc Dd')
#' 
#' @param s string(s) to capitalize
#' @param strict lower-case all other symbols
#' @param sep word separator character
##
cap.all <- function(s, strict=F, sep=' ')
{
    sapply(s, 
        USE.NAMES = !is.null(names(s)),
        function(s) { 
            paste(
                sapply(strsplit(s, sep),
                    cap, strict=strict,
                    USE.NAMES=F),
                collapse=sep)
        })
}

##
#' Reverses a string(s).
##
strrev <- function(x)
{
    sapply(
        lapply(
            strsplit(x, NULL), 
            rev), 
        paste, 
        collapse="")
}

##
#' This function implements the same interface as strsplit but correctly handles 
#' empty strings and strings with empty last token. Examples:
#'     strsplit("a,", ",")[[1]] will return "a" only, but 
#'     strsplit.eol("a,", ",")[[1]] will return c("a", "")
#' 
#' @note It is generally a good idea to split strings in bulk. E.g. read all
#' lines in memory (with readLines() for instance) and then apply strsplit.eol
#' on whole vector of strings. Example:
#'     lines <- readLines(file)
#'     tokens <- strsplit.eol(lines, ",", fixed=T)
#'     data <- unlist(tokens)
#'     nrow <- length(tokens)
#'     ncol <- length(tokens[[1]])
#'     dim(data) <- c(ncol, nrow) # invert
#'     data[,1] # 1st line parsed
##
strsplit.eol <- function(
        x, split, 
        fixed = FALSE, 
        perl = FALSE, 
        useBytes = FALSE)
{
    if (length(x) > 1) {
        # faster than sprintf on bulk data
        x <- paste0(x, split)
    }
    else if (!fixed || x == "" || ends(x, split)) {
        # faster than paste0 of one string
        x <- sprintf("%s%s", x, split)
    }
    strsplit(x, split, fixed, perl, useBytes)
}

##
#' Splits string \p s only one at the first match of \p split and rest of the
#' sting remains intact and is returned as the second part of the split.
#' Example: strsplit.one("a,b,c", ",") -> c("a", "b,c")
##
strsplit.one <- function(
    x, split,
    fixed = FALSE, 
    perl = FALSE, 
    useBytes = FALSE)
{
    pos <- regexpr(pattern = split, 
        text = x, 
        fixed = fixed, 
        perl = perl, 
        useBytes = useBytes)
    i <- 0
    lapply(x,
        function(y) {
            i <<- i + 1
            if (pos[i] > 0) {
                c(substr(y, 1, pos[i]-1),
                  substr(y, pos[i]+1, nchar(y)))
            }
            else {
                (y)
            }
        }
    )
}

##
#' Same as built-in as.numeric() but converts factors to strings 1st.
#' Example: as.numeric.str(factor(c("2","5"))) -> c(2,5), not (1,2)
##
as.numeric.str <- function(x)
{
    if (is.factor(x)) {
        sapply(x, function(x) {
            as.numeric(as.character(x))
        })
    }
    else {
        as.numeric(x)
    }
}

##
#' Same as built-in as.integer() but converts factors to strings 1st.
#' Example: as.integer.str(factor(c("2","5"))) -> c(2,5), not (1,2)
##
as.integer.str <- function(x)
{
    if (is.factor(x)) {
        sapply(x, function(x) {
            as.integer(as.character(x))
        })
    }
    else {
        as.integer(x)
    }
}

##
#' Verifies if string begins with one of the specified sub-strings. If more
#' than one string is given then return a vector of result of the same length
#' as the input vector of strings.
#' 
#' @example
#'     begins('12345', '123') -> TRUE
#'     begins(c('12','34'), '12') -> c(TRUE, FALSE)
#'     begins(c('12','34'), c('12','34')) -> c(TRUE, TRUE)
#' 
#' @param str String(s) to compare
#' @param sub Substrings to compare with
#' @return TRUE if a string [str] begins with a any of substrings [sub].
##
begins <- function(str, sub)
{
    sapply(str, function(x) {
        any(sapply(sub, function(y) {
            substr(x, 1, nchar(y)) == y
        }))
    })
}

##
#' Verifies if string ends with one of the specified sub-strings. If more
#' than one string is given then return a vector of result of the same length
#' as the input vector of strings.
#' 
#' @example
#'     ends('12345', '345') -> TRUE
#'     ends(c('12','34'), '2') -> c(TRUE, FALSE)
#'     ends(c('12','34'), c('2','4')) -> c(TRUE, TRUE)
#' 
#' @param str String(s) to compare
#' @param sub Substrings to compare with
#' @return TRUE if a string [str] ends with a any of substrings [sub].
##
ends <- function(str, sub)
{
    sapply(str, function(x) {
        any(sapply(sub, function(y) {
            l <- nchar(x)
            substr(x, l-nchar(y)+1, l) == y
        }))
    })
}

##
#' Returns TRUE only if the string is double-quoted.
#' Example: dquoted('"aaa"') -> TRUE
## 
dquoted <- function(s)
{
    regexpr('^ *".*" *$', s)[1] > 0
}

##
#' Returns TRUE only if the string is single-quoted.
#' Example: squoted("'aaa'") -> TRUE
## 
squoted <- function(s)
{
    regexpr("^ *'.*' *$", s)[1] > 0
}

##
#' TBD
##
sqt <- function(s)
{
    s <- escstr(s)
    if (grepl("[ \"]", s)) {
        sprintf("'%s'", s)
    }
    else {
        s
    }
}

##
#' TBD
##
dqt <- function(s)
{
    s <- escstr(s)
    if (grepl("[ ']", s)) {
        sprintf('"%s"', s)
    }
    else {
        s
    }
}

##
#'
##
left <- function(s, n)
{
    substr(s, 1, n)
}

##
#' Converts a schema, user or table name into Oracle expected format. E.g.
#' double-quoted names stay as they are otherwise uppercased.
##
oraname <- function(s)
{
    if (!dquoted(s)) {
        s <- toupper(s)
    }
    s
}

##
#' Replaces special characters like TAB with "escape" notation, like \t.
#' Example: cat(escstr("\t\n")) -> "\t\n"
##
escstr <- function(s)
{
    gsub('\t', '\\t', fixed=T, x=
    gsub('\n', '\\n', fixed=T, x=
    gsub('\"', '\\"', fixed=T, x=
        s)))
}

##
#' Displays a text and puts a newline character at the end. 
#' Same as cat(..., '\n'). Example: catn('hi') -> 'hi\n'.
##
catn <- function(...)
{
    cat(...)
    cat('\n')
}

##
#' Formats a string using sprintf rules and then prints it out.
#' Same as print(sprintf(...)). Example: printf('hi%d', 5) -> '[1] hi5'.
##
printf <- function(msg, ...)
{
    msg <- do.call(sprintf, append(list(msg), list(...)))
    print(msg)
}

##
#' Formats a string using sprintf rules and then cats it.
#' Same as cat(sprintf(...)). Example: catf('hi%d', 5) -> 'hi5'.
##
catf <- function(msg, ...)
{
    msg <- do.call(sprintf, append(list(msg), list(...)))
    cat(msg)
}

##
#' Formats a string using sprintf rules and then cats it + newline at the end.
#' Same as cat(sprintf(...), '\n'). Example: catfn('hi%d', 5) -> 'hi5\n'.
##
catfn <- function(...)
{
    catf(...)
    cat('\n')
}

##
#' Patrick's version of faster rbind method.
#' @example list to data.frame: do.call(rbind, lapply(vals, as.data.frame)).
#' 
#' @param ... One or more identically structured data.frame objects whose
#'     columns are either atomic vectors or factor objects.
#' @return data.frame
##
fast.rbind <- function(...)
{
    args <- lapply(list(...), as.list)
    if (length(args) == 0) {
        return (data.frame())
    }
    first <- args[[1L]]
    df <- lapply(seq_len(length(first)), 
        function(i) {
            cols <- lapply(args, `[[`, i)
            isfac <- is.factor(cols[[1L]])
            if (isfac) {
                levs <- unique(unlist(lapply(cols, levels), use.names=FALSE))
                cols <- lapply(cols, as.character)
            }
            bin <- do.call(c, unname(cols))
            if (isfac) {
                bin <- factor(bin, levs)
            }
            bin
        })
    attributes(df) <- list(names = names(first),
        row.names = .set_row_names(length(df[[1L]])),
        class = "data.frame")
    df
}

##
#' Does exactly the same as vanilla R's deparse but makes sure that only
#' one string is returned as a result, not a milti-line vector. Also removes
#' all intentations from the source.
##
deparse1 <- function(expr,
        backtick = mode(expr) %in% c("call", "expression", "(", "function"),
        control = c("keepInteger", "showAttributes", "keepNA"))
{
    x <- deparse(expr, 
        width.cutoff = 500, 
        nlines = -1,
        backtick = backtick,
        control = control)
    paste0(gsub("^ *", '', x), collapse='')
}

##
#' Returns a character at the specified position of a string.
#' 
#' @param x String.
#' @param pos Position.
#' @return String with one character only.
##
char <- function(x, pos)
{
    substr(x, pos, pos)
}

##
#' Bitwise AND.
##
"%and%" <- function(x, y) 
{
    if (length(y) == 1) {
        sapply(x, 
            function(x) {
                .bits2int(.int2bits(x) & .int2bits(y))
            })
    }
    else {
        z <- .rep_length(x, y)
        x <- z[[1]]
        y <- z[[2]]
        sapply(seq_along(x), 
            function(i) {
                .bits2int(.int2bits(x[i]) & .int2bits(y[i]))
            })
    }
}

##
#' Bitwise OR.
##
"%or%" <- function(x, y) 
{
    if (length(y) == 1) {
        sapply(x, 
            function(x) {
                .bits2int(.int2bits(x) | .int2bits(y))
            })
    }
    else {
        z <- .rep_length(x, y)
        x <- z[[1]]
        y <- z[[2]]
        sapply(seq_along(x), 
            function(i) {
                .bits2int(.int2bits(x[i]) | .int2bits(y[i]))
            })
    }
}

##
#' Bitwise XOR.
##
"%xor%" <- function(x, y) 
{
    if (length(y) == 1) {
        sapply(x, 
            function(x) {
                .bits2int(xor(.int2bits(x), .int2bits(y)))
            })
    }
    else {
        z <- .rep_length(x, y)
        x <- z[[1]]
        y <- z[[2]]
        sapply(seq_along(x), 
            function(i) {
                .bits2int(xor(.int2bits(x[i]), .int2bits(y[i])))
            })
    }
}

##
#' Bitwise shift left.
##
"%<<%" <- function(x, y)
{
    .assert(length(y) == 1)
    as.integer(x * (2^y))
}

##
#' Bitwise shift right.
##
"%>>%" <- function(x, y)
{
    .assert(length(y) == 1)
    as.integer(x / (2^y))
}

##
#' In-place increment. Equivalent to C++ "+=" operator or R's "a <- a + b"
#' expression. Adds [b] to [a] and assigns the result back to [a]. 
#' @example
#'     x <- 3
#'     x %+=% 2 
#'     x == 5
#' 
#' @param a Left-hand operator.
#' @param a Right-hand operator.
#' @return a + b
#' 
#' @seealso %-=%
#' @seealso %*=%
#' @seealso %/=%
##
"%+=%" <- function(a, b)
{
    .inplace.op(a, a+b)
}

##
#' In-place decrement. Equivalent to C++ "-=" operator or R's "a <- a - b"
#' expression. Subtracts [b] from [a] and assigns the result back to [a]. 
#' @example
#'     x <- 3
#'     x %-=% 2
#'     x == 1
#' 
#' @param a Left-hand operator.
#' @param a Right-hand operator.
#' @return a - b
#' 
#' @seealso %+=%
#' @seealso %*=%
#' @seealso %/=%
##
"%-=%" <- function(a,b)
{
    .inplace.op(a, a-b)
}

##
#' In-place multiplication. Equivalent to C++ "*=" operator or R's "a <- a * b"
#' expression. Multiplies [a] on [b] and assigns the result back to [a]. 
#' @example
#'     x <- 3
#'     x %*=% 2
#'     x == 6
#' 
#' @param a Left-hand operator.
#' @param a Right-hand operator.
#' @return a * b
#' 
#' @seealso %+=%
#' @seealso %-=%
#' @seealso %/=%
##
"%*=%" <- function(a,b)
{
    .inplace.op(a, a*b)
}

##
#' In-place division. Equivalent to C++ "/=" operator or R's "a <- a / b"
#' expression. Divides [a] on [b] and assigns the result back to [a]. 
#' @example
#'     x <- 3
#'     x %/=% 2
#'     x == 1.5
#' 
#' @param a Left-hand operator.
#' @param a Right-hand operator.
#' @return a / b
#' 
#' @seealso %+=%
#' @seealso %-=%
#' @seealso %*=%
##
"%/=%" <- function(a,b)
{
    .inplace.op(a, a/b)
}

##
#' In-place combine. Equivalent to R's "a <- c(a, b)" expression. Combines 
#' [a] with [b] and assigns the result back to [a]. 
#' @example
#'     x <- 3
#'     x %c=% 2
#'     x == c(3,2)
#' 
#' @param a Left-hand operator.
#' @param a Right-hand operator.
#' @return c(a, b)
##
"%c=%" <- function(a,b)
{
    .inplace.op(a, c(a,b))
}
