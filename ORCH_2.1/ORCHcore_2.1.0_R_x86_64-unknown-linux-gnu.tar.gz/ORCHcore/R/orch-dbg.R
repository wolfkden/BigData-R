# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' @name Oracle R Connector for Hadoop
#' @docType package
#' 
#' ORCH debug library. This is a collection of debug and logging functions.
#' ORCH functions must use only these function to print any messages and do not 
#' use print() or cat() R's native function.
##

###############################
# DO NOT INCLUDE ANY SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

## ------------------------------------------------------------------------- ##
##                             GLOBAL VARIABLES                              ##
## ------------------------------------------------------------------------- ##

# Severity levels, const:
if (!exists('.orch.dbgInit') || 
    .orch.dbgInit == F)
{
    orch.dbgFatal    <- 0 # special!
    orch.dbgCritical <- 1 # [
    orch.dbgError    <- 2
    orch.dbgWarning  <- 3
    orch.dbgSuper    <- 4
    orch.dbgDebug    <- 5
    orch.dbgInfo     <- 6
    orch.dbgTrace    <- 7
    orch.dbgQuery    <- 8
    orch.dbgShell    <- 9
    orch.dbgSystem   <- 10 # ]
    orch.dbgAll      <- 11 # special!
    .orch.dbgLast    <- orch.dbgSystem
    .orch.dbgInit    <- T
}

if (!exists('.orch.dbg.env') || 
    is.null(.orch.dbg.env$init))
{
    # Global debug switches (release mode):
    .orch.dbg.env <- new.env()
    .orch.dbg.env$init <- TRUE
    .orch.dbg.env$enable <- TRUE
    .orch.dbg.env$assert <- TRUE
    .orch.dbg.env$severity <- 2
    .orch.dbg.env$lasterr <- ''
    
    # Defines how to format log messages:
    .orch.dbg.env$show.time <- 2
    .orch.dbg.env$show.level <- 2
    .orch.dbg.env$show.cmdpath <- FALSE
    .orch.dbg.env$show.stopmsg <- TRUE
    .orch.dbg.env$shift <- 0
    .orch.dbg.env$mute <- c()
    .orch.dbg.env$max.msg.length <- 1000
    .orch.dbg.env$max.msg.repeat <- 80
    
    # Set of forced enabled/disabled severity levels:
    .orch.dbg.env$forced <- rep(NA, .orch.dbgLast)
    
    # Last time stamp, used in orch.dlogt():
    .orch.dbg.env$ts <- Sys.time()
    
    # Enables stop() call in stop=T within error log:
    .orch.dbg.env$stop.enabled <- T

    # Debug output stream:
    .orch.dbg.env$output <- stdout()
    .orch.dbg.env$stdout <- TRUE
}

## ------------------------------------------------------------------------- ##
##                             PRIVATE FUNCTIONS                             ##
## ------------------------------------------------------------------------- ##

##
#' Essentially imitates C/C++ assert() macro. As of R's version it's the same 
#' as stopifnot but can be turned off for better performance. Enabled in debug
#' mode only, otherwise replaced with an empty body. Throws a fatal error if
#' \p expr is false, logs it and stops execution.
#' 
#' @param expr Expression to be evaluated.
#' @return None.
#' 
#' @seealso .checkpoint
#' @seealso orch.dbg.on
#' @seealso orch.dbg.off
##
.assert <- function(expr)
{}

##
#' Checkpoint is an assert that always verified regardless of debug mode.
#' Essentially it's implementation of assert body. Throws a fatal error if
#' \p expr is false, logs it and stops execution.
#' 
#' @param expr Expression to be evaluated.
#' @return None.
#' 
#' @seealso .assert
##
.checkpoint <- function(expr)
{
    if (!expr) {
        orch.dlog.fatal("assert failed, %s", 
            deparse(substitute(expr)), 
            stop = T, 
            cat = T)
    }
}

##
#' Logging usability function, returns "s" if number or length of an object is
#' not 1, e.g. it's multiple count.
#' @example 
#'     orch.dloge("%g job%s failed", n, .s(n))
#'     orch.dloge("cars has %g col%s", ncol(cars), .s(obj=cars)) 
#'     orch.dloge("cars has %g row%s", nrow(cars), .s(df=cars))
#' 
#' @param n A numeric count.
#' @param obj Object to use as n=length(obj), optional.
#' @prama df Data.frame to use as n=nrow(obj), optional.
#' @return "s" or "".
##
.s <- function(n, obj, df)
{
    if (missing(n))
    {
        if (missing(obj)) {
            n <- if (is.null(df)) 0 else nrow(df)
        } else {
            n <- length(obj)
        }
    }
    ifelse(n != 1, "s", "")
}

##
#' Logging usability function, returns "ON" if value is TRUE, otherwise "OFF".
#' For numeric values 0 is "OFF", 1 is "ON" and the rest is "ON(value)".
#' @example orch.dloge("x is %s", .onoff(x))
#' 
#' @param x Is a logical value or numeric value.
#' @return "ON", "OFF" or "NA".
##
.onoff <- function(x)
{
    if (is.na(x)) {
        "NA"
    }
    else if (is.logical(x)) { 
        if (x) {
            "ON"
        }
        else {
            "OFF"
        }
    }
    else if (is.numeric(x)) {
        if (x == 0) {
            "OFF"
        }
        else if (x == 1) {
            "ON"
        }
        else {
            paste0("ON(",x,")")
        }
    }
    else {
        toString(x)
    }
}

##
#' Same as list(...) but converts NULL to "NULL".
#' Example: .orch.dbg.nlist(NULL) -> "NULL"
##
.orch.dbg.nlist <- function(...)
{
    lapply(list(...),
        function(x) {
            if (is.null(x)) "NULL" else x
        }
    )
}

##
#' Returns severity level as string name.
##
.orch.dbg.sv2str <- function(e)
{
    if (is.character(e)) {
        ret= e
    }
    else {
        ret <- ''
        if (e == orch.dbgFatal)
            ret <- "FATAL"
        else if (e == orch.dbgCritical)
            ret <- "CRITICAL"
        else if (e == orch.dbgError)
            ret <- "ERROR"
        else if (e == orch.dbgWarning)
            ret <- "WARNING"
        else if (e == orch.dbgSuper)
            ret <- "SUPER"
        else if (e == orch.dbgDebug)
            ret <- "DEBUG"
        else if (e == orch.dbgInfo)
            ret <- "INFO"
        else if (e == orch.dbgTrace)
            ret <- "TRACE"
        else if (e == orch.dbgQuery)
            ret <- "QUERY"
        else if (e == orch.dbgShell)
            ret <- "SHELL"
        else if (e == orch.dbgSystem)
            ret <- "SYSTEM"
        else if (e == orch.dbgAll)
            ret <- "ALL"
        else
            orch.dlog.stop('unknown severity %d', e)
    }
    ret
}

##
#' Returns severity level as numeric value.
##
.orch.dbg.str2sv <- function(e)
{
    if (is.numeric(e)) {
        ret <- e
    }
    else {
        ret <- -1
        e <- toupper(strim(e))
        if (e == "FATAL")
            ret <- orch.dbgFatal
        else if (e == "CRITICAL")
            ret <- orch.dbgCritical
        else if (e == "ERROR")
            ret <- orch.dbgError
        else if (e == "WARNING")
            ret <- orch.dbgWarning
        else if (e == "SUPER")
            ret <- orch.dbgSuper
        else if (e == "DEBUG")
            ret <- orch.dbgDebug
        else if (e == "INFO")
            ret <- orch.dbgInfo
        else if (e == "TRACE")
            ret <- orch.dbgTrace
        else if (e == "QUERY")
            ret <- orch.dbgQuery
        else if (e == "SHELL")
            ret <- orch.dbgShell
        else if (e == "SYSTEM")
            ret <- orch.dbgSystem
        else if (e == "ALL")
            ret <- orch.dbgAll
        else
            orch.dlog.stop('unknown severity "%s"', e)
    }
    ret
}

##
#' Returns name of the severity format in the log depending on the input
#' \p show.level level. If \p show.level is not specified then the currently
#' configured is used by default.
##
.orch.dbg.show.level <- function(show.level)
{
    if (missing(show.level)) {
        show.level <- .orch.dbg.env$show.level
    }
    if (show.level == 1) {
        "FULL"
    }
    else if (show.level == 2) {
        "2CHAR"
    }
    else {
        ""
    }
}

##
#' Returns format string for timestamps in the log depending on the input
#' \p show.time level. If \p show.time is not specified then the currently
#' configured is used by default.
##
.orch.dbg.show.time <- function(show.time)
{
    if (missing(show.time)) {
        show.time <- .orch.dbg.env$show.time
    }
    if (show.time == 1) {
        "%Y-%m-%d %H:%M:%S"
    }
    else if (show.time == 2) {
        "%H:%M:%S"
    }
    else {
        ""
    }
}

##
#' Return a formatted message prefix.
##
.orch.dbg.pfx <- function()
{
    severity <- get('severity', parent.frame())
    indent <- get('indent', parent.frame())

    # Format log message time stamp.
    t <- Sys.time()
    if (.orch.dbg.env$show.time == 1) {
        ts <- format(t, " %Y-%m-%d %H:%M:%S")
    }
    else if (.orch.dbg.env$show.time == 2) {
        ts <- format(t, " %H:%M:%S")
    }
    else {
        ts <- ''
    }

    # Format severity level prefix.
    lvl <- .orch.dbg.sv2str(severity)
    if (.orch.dbg.env$show.level == 1) {
        lvl <- paste(" [", lvl, "]", sep='')
    }
    else if (.orch.dbg.env$show.level == 2) {
        lvl <- paste(" [", substr(lvl, 1,2), "]", sep='')
    }
    else {
        lvl <- ''
    }

    # Put together the final log message.
    pfx <- ''
    if (.orch.dbg.env$stdout) {
        pfx <- 'DBG:'
    }
    pfx <- paste(pfx, ts, lvl, sep='')
    pfx <- gsub("^ +", '', pfx)
    indent <- indent + .orch.dbg.env$shift
    while (indent > 0) {
        pfx <- paste(pfx, "  ", sep='')
        indent <- indent - 1
    }
    pfx
}

##
#' Returns true if the given message is muted.
#' \p sev can be ommited if severity is defined in caller's frame.
##
.orch.dbg.muted <- function(msg, sev)
{
    if (missing(sev)) {
        sev <- get('severity', parent.frame())
    }
    ret <- sapply(msg, function(msg1) {
        if (msg1 == "") {
            # remove empty lines
            return (TRUE)
        }
        ret1 <- FALSE
        for (re in .orch.dbg.env$mute) {
            msgRE <- re[[1]]
            sevRE <- re[[2]]
            if (is.numeric(sevRE)) {
                if (sevRE != sev) {
                    next
                }
            }
            else if (is.character(sevRE)){
                muted <- length(grep(sevRE, .orch.dbg.sv2str(sev)))
                if (muted != 1) {
                    next
                }
            }
            muted <- length(grep(msgRE, msg1))
            if (muted == 1) {
                ret1 <- TRUE
                break
            }
        }
        ret1
    })

    .assert(is.logical(ret))
    ret
}

##
#' Return TRUE if a message must be printed out.
#' \p sev can be ommited if severity is defined in caller's frame.
##
.orch.dbg.show <- function(sev)
{
    if (missing(sev)) {
        sev <- get('severity', parent.frame())
    }
    if (!.orch.dbg.env$enable) {
        ret <- FALSE
    }
    else {
        if (sev == 0) {
            # FATALs are displayed always.
            ret <- TRUE
        }
        else if (sev <= .orch.dbg.env$severity) {
            # check force-disable settings
            forced <- .orch.dbg.env$forced[sev]
            ret <- is.na(forced) || forced
        }
        else {
            # check force-enable settings
            forced <- .orch.dbg.env$forced[sev]
            ret <- !is.na(forced) && forced
        }
    }
    ret
}

##
#' Returns TRUE if a message must be ignored.
#' \p sev can be ommited if severity is defined in caller's frame.
##
.orch.dbg.hide <- function(sev)
{
    if (missing(sev)) {
        sev <- get('severity', parent.frame())
    }
    !.orch.dbg.show(sev)
}

##
#' Format a variable for nice printing to log. For vectors encapsulates all 
#' its values in "c()" notation.
##
.orch.dbg.format <- function(v)
{
    # Format right part (after assign operator)
    x <- if (is.factor(v)) {
        sprintf("f(%s)", paste0(as.integer(v), collapse=','))
    }
    else if (is.vector(v) && length(v) > 1) {
        sprintf("c(%s)", paste0(v, collapse=','))
    }
    else if (is.numeric(v) && v < 1*T. && floor(v) == ceiling(v)) {
        sprintf("%.0f", v)
    }
    else {
        toString(v)
    }
    
    # Format middle part (right after variable name)
    if (length(v) > 1) {
        sprintf("{%d} = %s", length(v), x)
    }
    else {
        sprintf(" = %s", x)
    }    
}

##
#' This function allows to export hidden functions implemented in ORHC package. 
#' It simply defines a set of new funtions pointing to the original hidden 
#' declaration. Note that the exported function signature must exactly mimic 
#' the internal real function.
#'
#' @param name name of the funtion to export
#' @param ... function parameters and default values
#' @param .prefix replaces function name prefix, default 'orch.'
#' @param .name replaces exported function name, ignores prefix
#'
#' Examples:
#' ORHC:::.orch.import('dbg.mute', 'regex', severity=NULL)
#' ORHC:::.orch.import('dlogq', 'qry', indent=0, .name='dq')
#' orch.dbg.mute('.*'); dq(x)
##
.orch.import <- function(name, ..., 
        .prefix = 'orch.', 
        .name = NULL)
{
    v <- list(...)
    cmd.in <- '' # function(in) {
    cmd.out <- '' # call(out) }
    if (length(v) > 0)
    {
        n <- names(v)
        for (i in 1:length(v))
        {
            if (length(n) < i || n[i] == '') {
                # has no default value:
                p <- v[[i]]
                cmd.in <- paste(cmd.in, ',',p, sep='')
                cmd.out <- paste(cmd.out, ',',p,'=',p, sep='')
            }
            else {
                # has a default value:
                p <- n[i]
				x <- v[[p]]
				if (is.character(x)) {
					x <- paste('"',x,'"', sep='')
                }
				else if (is.null(x)) {
					x <- 'NULL'
                }
				else if (is.na(x)) {
					x <- 'NA'
                }
				else if (is.nan(x)) {
					x <- 'NaN'
                }
                cmd.in <- paste(cmd.in, ',',p,'=',x, sep='')
                cmd.out <- paste(cmd.out, ',',p,'=',p, sep='')
            }
        }
        # remove the last ',' chars
        cmd.in <- substring(cmd.in, 2)
        cmd.out <- substring(cmd.out, 2)
    }
    if (is.null(.prefix)) {
        .prefix <- ''
    }
    if (is.null(.name)) {
        .name <- paste(.perfix,name, sep='')
    }
    eval.parent(parse(text=
        paste(
            .name,
                '<- function(',cmd.in,')',
                '{',
                    'ORHC:::',.prefix,name,'(',cmd.out,')',
                '}',
            sep='')
    ))
}

##
#' This function allows to export hidden constant variables declared in OREbase 
#' package. It simply defines a set of new variables and assigns them to the 
#' original hidden values.
#'
#' @param ... list of variable names to export
#' @param .prefix replaces variable(s) name prefix, default 'orch.'
#' @param .name replaces exported variable name(s), ignores prefix
#'
#' Examples:
#' ORHC:::.orch.import.vars(
#'     'dbgFatal',
#'     'dbgCritical',
#'     .name = 'xyz')
#' print(xyz, orch.dbgCritical)
##
.orch.import.vars <- function(...,
        .prefix = 'orch.', 
        .name = NULL)
{
    v <- list(...)
	for (i in 1:length(v)) {
		x <- v[[i]]
        if (is.null(.prefix)) {
            .prefix <- ''
        }
        if (is.null(.name) || is.na(.name[i])) {
            v <- paste(.perfix,v, sep='')
        }
        else {
            v <- .name[i] 
        }
		eval.parent(parse(text=
			paste(.name,'<- ORHC:::',.prefix,x, sep='')
		))
	}
}

##
#' Returns TRUE is \p severity is set to "ALL".
##
.orch.dbg.isAll <- function(severity)
{
    length(severity) == 1 && 
        .orch.dbg.str2sv(severity) == orch.dbgAll 
}

## ------------------------------------------------------------------------- ##
##                            EXPORTED FUNCTIONS                             ##
## ------------------------------------------------------------------------- ##

##
#' Enables or disables asserts through the code. Asserts can dro peformance
#' signicatly you want to disable them in relase code.
#' 
#' @param onOff Enable or disable asserts.
#' @return Current assert setting if \p onOff is not specified.
#' 
#' @seealso orch.dbg.on
#' @seealso orch.dbg.off
##
orch.dbg.assert <- function(onOff)
{
    if (missing(onOff)) {
        .orch.dbg.env$assert
    }
    else if (onOff != .orch.dbg.env$assert) {
        if (.orch.dbg.env$assert) {
            .orch.dbg.env$assert <- FALSE
            .assert <<- function(expr) {}
            orch.dlog.system("asserts are OFF")
        }
        else {
            .orch.dbg.env$assert <- TRUE
            .assert <<- .checkpoint
            orch.dlog.system("asserts are ON")
        }
    }
}

##
#' Globally enables debugging. \p severity allows to set new debug severity 
#' level or turn on individual message severity logging. Also enables 
#' assertions in ORCH code.
#' 
#' @examples 
#'     orch.dbg.on()              # resume debugging.
#'     orch.dbg.on("all")         # log all debug output.
#'     orch.dbg.on("warning")     # log warnings, errors, and up.
#'     orch.dbg.on("error,trace") # log errors and up, plus TRACE only.
#'     orch.dbg.on(",trace")      # enable TRACE in addition.
#'     orch.dbg.on("~,info")      # log INFO messages only.
#' 
#' @param severity Vector of severity numeric ID or string name (optinal). It 
#'     can be in a format of comma-separated string as well.
#'     Accepted configuration values:
#'     * NULL. This means to just enable debugging without changing the
#'       the current debug settings. Severity will stay the same as prior
#'       turning off orch.dbg.off(). Example: orch.dbg.on().
#'     * "all" will enable everything and reset individually enables/disabeld 
#'       debug severities. Example: orch.dbg.on('all')
#'     * A list which will indicate a global severity level plus individual 
#'       severities to enable only. Example: orch.dbg.on("error,trace")
#'     * If the first value is empty "" then the current severity will not 
#'       be changed and only additional list severities will be enabled 
#'       individually. Example: orch.dbg.on(",trace")
#'     * If the first value is "only" or "~" then only listed severities will 
#'       be enabled and global severity level will be set to FATAL.
#'       Example: orch.dbg.on("~,info")
#' @param assert Enable of disable asserts throught the code:
#'     * TRUE - enable (default).
#'     * FALSE - disable.
#'     * NULL - do not change.
#' @return None.
#' 
#' @seealso orch.dbg.off
#' @seealso orch.dbg.enable
#' @seealso orch.dbg.assert
##
orch.dbg.on <- function(
        severity = NULL, 
        assert = TRUE)
{
    # Check inputs.
    .orch.ntest.input.stop(severity, c("numeric","word"), 1:.orch.dbgLast)
    only <- FALSE
    also <- FALSE
    
    # Convert c("a,b","c") to c("a","b","c") and extract control words.
    if (is.character(severity)) {
        severity <- strim(unlist(strsplit(severity, ',')))
        if (severity[1] %in% c("only","~")) {
            # "only" and "~" are control keywords
            severity <- severity[-1]
            only <- TRUE
        }
        else if (severity[1] %in% c("also","+")) {
            # "also" and "+" are control keywords
            severity <- severity[-1]
            also <- TRUE
        }
    }
    
    # Severity "all" resets everything.
    if (.orch.dbg.isAll(severity)) {
        orch.dlog.system("debug reset and turn on")
        .orch.dbg.env$forced <- rep(NA, .orch.dbgLast)
        orch.dbg.unmute()
    }
    
    # Configure asserts.
    if (!is.na(assert) && !is.null(assert)) {
        orch.dbg.assert(assert)
    }
    
    # Configure debug severity levels.
    #   "only" mode = enable ONLY specified severity levels.
    #   "also" mode = enable specified severity levels additionally.
    #   normal mode = 1st values is the global severity, the rest are "also". 
	if (!is.null(severity)) {
        if (only) {
            orch.dbg.severity(0)
            for (sv in severity) {
                orch.dbg.enable(sv)
            }
        }
        else if (also) {
            for (sv in severity) {
                orch.dbg.enable(sv)
            }
        }
        else {
            orch.dbg.severity(severity[1])
            for (sv in severity[-1]) {
                orch.dbg.enable(sv)
            }
        }
	}
    
    # Enable debugging globally in ORCH.
    if (!.orch.dbg.env$enable) {
    	.orch.dbg.env$enable <- TRUE
        orch.dlog.system("debug logging is ON")
    }
    if (exists(".orch.env")) {
        .orch.env$debug <- TRUE
    }
    
    # No return.
    invisible()
}

##
#' Globally disables debugging. \p severity allows to turn off individual 
#' message severity logging. Also disables assertions in ORCH code.
#' 
#' @example
#'     orch.dbg.off()               # suspend debugging
#'     orch.dbg.off('all')          # turn off and reset debugging
#'     orch.dbg.off('warning')      # disable only warning messages
#'     orch.dbg.off('warning,info') # disable warning and info messages
#' 
#' @param severity Vector of severity numeric IDs or string name (optinal). It 
#'     can be in a format of comma-separated string as well.
#'     Accepted configuration values:
#' 	   * NULL. Suspends debugging and all log message until it's resumed with
#'       orch.dbg.on() function call. Turns off asserts too. Example: 
#'       orch.dbg.off()
#'     * List of severities to disable individually. Only those severities
#'       will not be logged any more. Asserts will be still enabled.
#'     * "all" will completely turn off debugging and reset all enabled and
#'       disabled severities. Turns off asserts too. Example: 
#'       orch.dbg.off("all")
#' @param assert Enable of disable asserts throught the code:
#'     * TRUE - enable.
#'     * FALSE - disable (default).
#'     * NULL - do not change.
#' @retunr None.
#' 
#' @seealso orch.dbg.on
#' @seealso orch.dbg.disable
#' @seealso orch.dbg.assert
##
orch.dbg.off <- function(
        severity = NULL, 
        assert = FALSE)
{
    # Check inputs.
    .orch.ntest.input.stop(severity, c("numeric","word"), 1:.orch.dbgLast)
    
    # Convert c("a,b","c") to c("a","b","c").
    if (is.character(severity)) {
        severity <- strim(unlist(strsplit(severity, ',')))
    }
    
    # If severity is not specified the just completely shutdown ORCH debugging.
    if (is.null(severity)) {
        if (.orch.dbg.env$enable) {
            .orch.dbg.env$enable <- FALSE
            orch.dlog.system("debug logging is OFF")
        }
        if (exists(".orch.env")) {
            .orch.env$debug <- FALSE
        }
    }
    
    # Configure asserts.
    if (!is.na(assert) && !is.null(assert)) {
        orch.dbg.assert(assert)
    }

    # Severity "all" resets everything.
    if (.orch.dbg.isAll(severity)) {
        orch.dlog.system("debug reset and turn off")
        .orch.dbg.env$forced <- rep(NA, .orch.dbgLast)
        orch.dbg.unmute()
        orch.dbg.severity(0)
        severity <- NULL
    }
    if (!is.null(severity)) {
        for (sv in severity) {
            orch.dbg.disable(sv)
        }
    }
    
    # No return.
    invisible()
}

##
#' Sets a new debug output stream (or a file name).
#' If new output is not specified then sets to stdout by default.
#' 
#' @param con R connection object to be used as debug log output. Can be a
#'     string file name, or strdout(), or stderr(). "" will be considered as
#'     strout().
#' @return None.
##
orch.dbg.output <- function(con='')
{
    conStr <- strim(con)
    if (conStr %in% c("stderr", "-", "2")) {
        con <- stderr()
    }
    else if (conStr %in% c("stdout", "", "1")) {
        con <- stdout()
    }
    stdout <- FALSE
    if (con == stdout()) {
        conStr <- "stdout"
        stdout <- TRUE
    }
    else if (con == stderr()) {
        conStr <- "stderr"
        stdout <- TRUE
    }
    if (con != .orch.dbg.env$output) {
        orch.dlog.system("debug output set to \"%s\"", conStr)
        .orch.dbg.env$output <- con
        .orch.dbg.env$stdout <- stdout
    }
    invisible()
}

## ------------------------------------------------------------------------- ##
##                             PUBLIC FUNCTIONS                              ##
## ------------------------------------------------------------------------- ##

##
#' Creates a copy of current debug environment with all settings.
#' This allows to restore any changes done to the debug environment.
#' @return *Copy* of current debug environment.
#' 
#' @seealso orch.dbg.setenv
#' @seealso orch.dbg.status
##
orch.dbg.getenv <- function()
{
    orch.dlog.system('debug environment saved')
    as.list(.orch.dbg.env)
}

##
#' Restores the debug environment to the previously saved one. This will 
#' completely overwrite all current debug settings.
#' 
#' @param env Previously saved environmnet.
#' @return None.
#' 
#' @seealso orch.dbg.getenv
#' @seealso orch.dbg.status
##
orch.dbg.setenv <- function(env)
{
    .assert(all(names(.orch.dbg.env) == names(env)))
    for (var in names(env)) {
        .orch.dbg.env[[var]] <- env[[var]]
    }
    orch.dlog.system('debug environment restored')
}

##
#' Prints out (current) debug environment settings.
#' @param env Optionally saven debug environment, by default uses current.
#' @return A data frame with human-readable status.
##
orch.dbg.status <- function(env)
{
    if (missing(env)) {
        env <- .orch.dbg.env
    }
    data.frame(
        NAME=c(
            "enable",
            "severity",
            "output",
            "asserts",
            "show.level", 
            "show.time", 
            "stop.enabled",
            "show.stopmsg",
            "show.cmdpath",
            "FORCED:",
            tolower(.orch.dbg.sv2str(1)),
            tolower(.orch.dbg.sv2str(2)),
            tolower(.orch.dbg.sv2str(3)),
            tolower(.orch.dbg.sv2str(4)),
            tolower(.orch.dbg.sv2str(5)),
            tolower(.orch.dbg.sv2str(6)),
            tolower(.orch.dbg.sv2str(7)),
            tolower(.orch.dbg.sv2str(8)),
            tolower(.orch.dbg.sv2str(9)),
            tolower(.orch.dbg.sv2str(10))),
        VALUE=c(
            env$enable,
            .orch.dbg.sv2str(env$severity), 
            .empty.to(env$output, "stdout"),
            .orch.dbg.env$assert,
            .orch.dbg.show.level(env$show.level),
            .orch.dbg.show.time(env$show.time),
            env$stop.enabled,
            env$show.stopmsg,
            env$show.cmdpath,
            "",
            null.to(env$forced[1], "-"),
            null.to(env$forced[2], "-"),
            null.to(env$forced[3], "-"),
            null.to(env$forced[4], "-"),
            null.to(env$forced[5], "-"),
            null.to(env$forced[6], "-"),
            null.to(env$forced[7], "-"),
            null.to(env$forced[8], "-"),
            null.to(env$forced[9], "-"),
            null.to(env$forced[10], "-"))
    )
}

##
#' Sets or examines debug log severity level.
#'
#' If severity is specified then set the new global level. severity can be 
#' given as a numeric value or as a string name. Alwsays returns the current 
#' severity level as pair c(name, value).
#'
#' @param severity Severity numeric ID or string name (optinal)
#' @return Current c(<severity name>, <severity ID>).
##
orch.dbg.severity <- function(severity)
{
    if (!missing(severity) && severity != '') {
        sv <- .orch.dbg.str2sv(severity)
        if (sv != .orch.dbg.env$severity) {
            orch.dlog.system('debug severity is set to %s, was %s', 
                .orch.dbg.sv2str(sv), 
                .orch.dbg.sv2str(.orch.dbg.env$severity))
            .orch.dbg.env$severity <- sv
        }
    }
    ret <- .orch.dbg.env$severity
    attr(ret, "name") <- .orch.dbg.sv2str(.orch.dbg.env$severity)
    ret
}

##
#' Returns a named list of all available severity levels.
##
orch.dbg.severity.list <- function()
{
    ret <- c()
    for (sv in 0:.orch.dbgLast) {
        sv.str <- .orch.dbg.sv2str(sv)
        ret[sv.str] <- sv
    }
    ret
}

##
#' Sets new global indentation value, use orch.dbg.shift() to reset.
#' Example: orch.dbg.tab(1); orch.dlog('1') --> "  1".
##
orch.dbg.tab <- function(n=0)
{
    .orch.dbg.env$shift <- n
}

##
#' Enables a specific message severity level to be displayed regarless of the 
#' currently set global debug deverity level. Use orch.dbg.reset() to 
#' disable. This overrides previously disabled with orch.dbg.disable() severity 
#' level.
#'
#' Note that you can specify several severities at once to enable by 
#' supplying a vector of severities (names or IDs) or comma-separated 
#' string of severity names.
#'
#' @examples 
#'     orch.dbg.enable()        # enable ORCH debugging.
#'     orch.dbg.enable("trace") # enable only TARCE messages.
#'     orch.dbg.enable("all")   # enable all messages regardless.
#' 
#' @param severity Severity is a numeric ID or a string name or a vector of 
#'     severities. Can be in a form of comma-separated string list. Special 
#'     values are:
#'     * NULL to just enable debugging without changing severity settings.
#'       Example: orch.dbg.enable()
#'     * "all" to enable every single one severity.
#'       Example: orch.dbg.enable("all")
#' @return None.
#' 
#' @seealso orch.dbg.disable
#' @seealso orch.dbg.reset
#' @seealso orch.dbg.is.enabled
##
orch.dbg.enable <- function(severity = NULL)
{
    if (is.character(severity)) {
        severity <- str2csv(severity)
    }
    if (.orch.dbg.isAll(severity)) {
        # force enable all severities
        .orch.dbg.env$forced <- rep(TRUE, .orch.dbgLast)
        orch.dlog.system('force enabled all severity levels')
    }
    else if (is.null(severity)) {
        if (!.orch.dbg.env$enable) {
            # enable debugging globally in ORCH.
            .orch.dbg.env$enable <- TRUE
            orch.dlog.system("debug logging is ON")
        }
    }
    else {
        for (sv1 in severity) {
            # force enable specific severity
            sv1 <- .orch.dbg.str2sv(sv1)
            if (sv1 == 0) {
                orch.dlog.error("can't enable FATAL")
            }
            else {
                .orch.dbg.env$forced[sv1] <- TRUE
                orch.dlog.system('force enabled %s severity', 
                    .orch.dbg.sv2str(sv1))
            }
        }
    }
}

# Set of force enable shortcuts for each severity.
orch.dbg.enable.fatal <- function() orch.dbg.enable(orch.dbgFatal)
orch.dbg.enable.critical <- function() orch.dbg.enable(orch.dbgCritical)
orch.dbg.enable.error <- function() orch.dbg.enable(orch.dbgError)
orch.dbg.enable.warning <- function() orch.dbg.enable(orch.dbgWarning)
orch.dbg.enable.super <- function() orch.dbg.enable(orch.dbgSuper)
orch.dbg.enable.debug <- function() orch.dbg.enable(orch.dbgDebug)
orch.dbg.enable.info <- function() orch.dbg.enable(orch.dbgInfo)
orch.dbg.enable.trace <- function() orch.dbg.enable(orch.dbgTrace)
orch.dbg.enable.query <- function() orch.dbg.enable(orch.dbgQuery)
orch.dbg.enable.shell <- function() orch.dbg.enable(orch.dbgShell)
orch.dbg.enable.system <- function() orch.dbg.enable(orch.dbgSystem)

##
#' Returns enable status of the specified message severity level. The severity
#' must be equal or lower than the globally configured severity or set force
#' enabled.
#'
#' @param severity severity is a numeric ID or a string name; -1 == *all*
#' @return TRUE or FALSE
#' 
#' @seealso orch.dbg.enable
#' @seealso orch.dbg.severity
#' @seealso orch.dbg.on
##
orch.dbg.is.enabled <- function(severity=-1)
{
    if (is.character(severity)) {
        severity <- .orch.dbg.str2sv(severity)
    }
    ret <- F
    if (severity < 0) {
        ret <- all(.orch.dbg.env$forced)
        if (is.na(ret)) {
            ret <- .orch.dbg.env$severity >= orch.dbgAll
        }
    }
    else {
        ret <- .orch.dbg.env$forced[severity]
        if (is.na(ret)) {
            ret <- severity <= .orch.dbg.env$severity
        }
    }
    ret
}

##
#' Disables a specific message severity level to NOT be displayed regarless of 
#' the currently set global debug severity level. Use orch.dbg.reset() to 
#' re-enable. This overrides previously enabled with orch.dbg.enable() severity 
#' level.
#'
#' Note that you can specify several severities at once to disable by 
#' supplying a vector of severities (names or IDs) or comma-separated 
#' string of severity names.
#' 
#' @examples 
#'     orch.dbg.disable()        # disable ORCH debugging.
#'     orch.dbg.disable("trace") # disable only TARCE messages.
#'     orch.dbg.disable("all")   # disable all messages regardless.
#' 
#' @param severity Severity is a numeric ID or a string name or a vector of 
#'     severities. Can be in a form of comma-separated string list. Special 
#'     values are:
#'     * NULL to just disable debugging without changing other severity 
#'       settings. Example: orch.dbg.disable()
#'     * "all" to disable every single one severity.
#'       Example: orch.dbg.disable("all")
#' @return None.
#' 
#' @seealso orch.dbg.enable
#' @seealso orch.dbg.reset
#' @seealso orch.dbg.is.disbaled
##
orch.dbg.disable <- function(severity = NULL)
{
    if (is.character(severity)) {
        severity <- str2csv(severity)
    }
    if (.orch.dbg.isAll(severity)) {
        # force disable all severities
        .orch.dbg.env$forced <- rep(FALSE, .orch.dbgLast)
        orch.dlog.system('force disabled all severity levels')
    }
    else if (is.null(severity)) {
        if (.orch.dbg.env$enable) {
            # disable debugging globally in ORCH.
            .orch.dbg.env$enable <- FALSE
            orch.dlog.system("debug logging is OFF")
        }
    }
    else {
        for (sv1 in severity) {
            # force disable specific severity
            sv1 <- .orch.dbg.str2sv(sv1)
            if (sv1 == 0) {
                orch.dlog.error("can't disable FATAL")
            }
            else {
                .orch.dbg.env$forced[sv1] <- FALSE
                orch.dlog.system('force disabled %s severity', 
                    .orch.dbg.sv2str(sv1))
            }
        }
    }
}

# Set of force disable shortcuts for each severity.
orch.dbg.disable.fatal <- function() orch.dbg.disable(orch.dbgFatal)
orch.dbg.disable.critical <- function() orch.dbg.disable(orch.dbgCritical)
orch.dbg.disable.error <- function() orch.dbg.disable(orch.dbgError)
orch.dbg.disable.warning <- function() orch.dbg.disable(orch.dbgWarning)
orch.dbg.disable.super <- function() orch.dbg.disable(orch.dbgSuper)
orch.dbg.disable.debug <- function() orch.dbg.disable(orch.dbgDebug)
orch.dbg.disable.info <- function() orch.dbg.disable(orch.dbgInfo)
orch.dbg.disable.trace <- function() orch.dbg.disable(orch.dbgTrace)
orch.dbg.disable.query <- function() orch.dbg.disable(orch.dbgQuery)
orch.dbg.disable.shell <- function() orch.dbg.disable(orch.dbgShell)
orch.dbg.disable.system <- function() orch.dbg.disable(orch.dbgSystem)

##
#' Returns disable status of the specified message level. The severity
#' must be higher than the globally configured severity or set force
#' disabled.
#'
#' @param severity severity is a numeric ID or a string name; -1 == *all*
#' @return TRUE or FALSE
#' 
#' @seealso orch.dbg.disable
#' @seealso orch.dbg.severity
#' @seealso orch.dbg.off
##
orch.dbg.is.disabled <- function(severity=-1)
{
    if (is.character(severity)) {
        severity <- .orch.dbg.str2sv(severity)
    }
    ret <- F
    if (severity < 0) {
        ret <- all(!.orch.dbg.env$forced)
        if (is.na(ret)) {
            ret <- .orch.dbg.env$severity < orch.dbgAll
        }
    }
    else {
        ret <- !.orch.dbg.env$forced[severity]
        if (is.na(ret)) {
            ret <- severity > .orch.dbg.env$severity
        }
    }
    ret
}

##
#' Resets a specific message severity level force enable (via orch.dbg.enable)
#' or force disable (via orch.dbg.disable) settings.
#'
#' Note that you can specify several severities at once to reset by 
#' supplying a vector of severities (names or IDs) or comma-separated 
#' string of severity names.
#' 
#' @examples 
#'     orch.dbg.reset()        # same as "all".
#'     orch.dbg.reset("trace") # reset only TARCE messages.
#'     orch.dbg.reset("all")   # reset all severities regardless.
#' 
#' @param severity Severity is a numeric ID or a string name or a vector of 
#'     severities. Can be in a form of comma-separated string list. Special 
#'     values are:
#'     * NULL to just disable debugging without changing other severity 
#'       settings. Example: orch.dbg.disable()
#'     * "all" to reset every single one severity.
#'       Example: orch.dbg.reset("all")
#' @return None.
#' 
#' @seealso orch.dbg.enable
#' @seealso orch.dbg.disable
##
orch.dbg.reset <- function(severity = NULL)
{
    if (is.character(severity)) {
        severity <- str2csv(severity)
    }
    if (is.null(severity) || .orch.dbg.isAll(severity)) {
        # force disable all severities
        .orch.dbg.env$forced <- rep(NA, .orch.dbgLast)
        orch.dlog.system('reset all forced severity levels')
    }
    else {
        for (sv1 in severity) {
            # force disable specific severity
            sv1 <- .orch.dbg.str2sv(sv1)
            if (sv1 == 0) {
                orch.dlog.error("can't reset FATAL")
            }
            else {
                .orch.dbg.env$forced[sv1] <- NA
                orch.dlog.system('reset %s forced severity', 
                    .orch.dbg.sv2str(sv1))
            }
        }
    }
}

# Set of force reset shortcuts for each severity.
orch.dbg.reset.critical <- function() orch.dbg.reset(orch.dbgCritical)
orch.dbg.reset.error <- function() orch.dbg.reset(orch.dbgError)
orch.dbg.reset.warning <- function() orch.dbg.reset(orch.dbgWarning)
orch.dbg.reset.super <- function() orch.dbg.reset(orch.dbgSuper)
orch.dbg.reset.debug <- function() orch.dbg.reset(orch.dbgDebug)
orch.dbg.reset.info <- function() orch.dbg.reset(orch.dbgInfo)
orch.dbg.reset.trace <- function() orch.dbg.reset(orch.dbgTrace)
orch.dbg.reset.query <- function() orch.dbg.reset(orch.dbgQuery)
orch.dbg.reset.shell <- function() orch.dbg.reset(orch.dbgShell)
orch.dbg.reset.system <- function() orch.dbg.reset(orch.dbgSystem)

##
#' Adds another regex string to the muted list.
#' Example: orch.dbg.mute("hello .*"); --> "hello world" is muted.
##
orch.dbg.mute <- function(regex, severity=NULL)
{
    .orch.dbg.env$mute <- unique(c(
        .orch.dbg.env$mute, 
        list(list(regex, severity))
    ))
    orch.dlog.system('muted %s:"%s" (%d)', 
        severity, 
        regex, 
        length(.orch.dbg.env$mute))
}

##
#' Un-mutes one or all previously muted messages.
#' @param i muted message index to unmute (optinal)
##
orch.dbg.unmute <- function(i)
{
    cnt <- length(.orch.dbg.env$mute)
    if (missing(i)) {
        if (cnt > 0) {
            .orch.dbg.env$mute <- c()
            orch.dlog.system('unmuted %d messages', cnt)
        }
    }
    else if (i > 0 && i <= cnt) {
        msgRE <- .orch.dbg.env$mute[i][[1]]
        sevRE <- .orch.dbg.env$mute[i][[2]]
        .orch.dbg.env$mute <- .orch.dbg.env$mute[-i]
        orch.dlog.system('unmuted message #%d: %s:"%s"', i, sevRE, msgRE)
    }
    else {
        orch.dloge('bad used message index %d', i)
    }
}

##
#' Prints out a list of muted messages in the format:
#' [#]. [severity filter]:[message filter]
##
orch.dbg.muted <- function()
{
    i <- 1
    for (re in .orch.dbg.env$mute) {
        msgRE <- re[[1]]
        sevRE <- re[[2]]
        cat(i, '. ', sevRE, ':"', msgRE, '"\n', sep='')
        i <- i+1
    }
}

##
#' Simply print content of a file to debug's log. Note that if debug output
#' is directed to the stdout then each line will be prepended with "DBG:".
##
orch.dbg.cat <- function(con)
{
    lines <- readLines(con)
    if (length(lines) > 0) {
        if (.orch.dbg.env$stdout) {
            lines <- paste("DBG:", lines)
        }
        cat(lines, sep='\n',
            file = .orch.dbg.env$output,
            append = T)
    }
}

##
#' Logs one local variable. Example: orch.dlogv(x) will log out "x = [value]".
#' Vectors are logged in array-like style, e.g. will produce a log like per
#' each vector element and the variable name will be postfixed with "[n]".
#' Example: x<-c(1,2); orch.dlogv(x) -> "x[1] = 1" "x[2] = 2". 
##
orch.dlogv <- function(x, v, 
        severity = orch.dbgTrace, 
        indent = 0,
        format = NULL,
        quote = TRUE,
        .parent = 0)
{
    if (!.orch.dbg.show()) {
        return()
    }
    
    # If custom name of the valiable is not specified, extract variable name
    # from the function argument names directly.
    if (missing(v)) {
        v <- x
        penv <- sys.frame(sys.parent(.parent))
        x <- deparse(substitute(x, env=penv))
    }
    
    # Special data types handling
    if (is.null(v)) {
        v <- "NULL"
    }
    else if (is.character(v) || is.factor(v)) {
        v <- gsub("\t", "\\t", fixed=T, x=
             gsub("\n", "\\n", fixed=T, x=v
        ))
        if (quote) {
            v <- sprintf('"%s"', v)
        }
    }
    else if (class(v) == "formula") {
        v <- paste(v, collapse='')
    }
    
    # If variable is a vector or list, log each value as array-style
    # e.g. "a[1] = 1", "a[2] = 2", etc. otherwise just "a = 1".
    # if vector has names then use names instead of indexes.
    # data.frames are logged as "a[1] = c(1,2)"
    n <- length(v)
    if (n > 1L) {
        lines <- seq_len(n)
        nskip <- n - .orch.dbg.env$max.msg.repeat
        if (nskip > 0L) {
            # limit number of log lines
            tail <- floor(.orch.dbg.env$max.msg.repeat / 2L)
            lines <- c(lines[1:tail], -1, lines[(n-tail+1):n])
            skipMsg <- sprintf("{skipped %d value%s}", nskip, .s(nskip))
        }
        msg <- c()
        vn <- names(v)
        if (is.null(vn)) {
            # does not have any names, use "a[i] = x" format
            for (i in lines) {
                msg <- c(msg, if (i <= 0) {
                    skipMsg
                } else {
                    sprintf("%s[%d]%s", x, i, 
                        .orch.dbg.format(v[[i]]))
                })
            }
        }
        else {
            # has names, use "a[name_i|i] = x" format
            for (i in lines) {
                msg <- c(msg, if (i <= 0) {
                    skipMsg
                } else {
                    sprintf("%s[%s]%s", x,
                        if (vn[i]=='') i else vn[i], 
                        .orch.dbg.format(v[[i]]))
                })
            }
        }
    }
    else {
        msg <- sprintf("%s%s", x, 
            .orch.dbg.format(unlist(v)))
    }
    
    # Truncate too long messages as specified in options, inserts in the
    # middle "... {-X} ..." to indicate that its partially missing.
    msg <- sapply(msg, function(x) {
        len <- nchar(x)
        if (len > .orch.dbg.env$max.msg.length) {
            tpos <- as.integer(.orch.dbg.env$max.msg.length/2 - 10)
            x <- sprintf("%s... {-%.0f} ...%s",
                substr(x, 1, tpos),
                len - tpos*2,
                substring(x, len - tpos))
            .assert(nchar(x) <= .orch.dbg.env$max.msg.length)
        }
        x
    })
    # and apply extra formatting if requested by the user.
    if (!is.null(format)) {
        msg <- sapply(msg, function(x) {
            sprintf(format, x)
        })
    }
    
    # All done, message is ready to be logged.
    orch.dlog(severity, msg, indent)
}

##
#' Logs one or several local variables.
#' Example: orch.dlogv2(x, y) will print out "x = [value]", "y = [value]".
##
orch.dlogv2 <- function(..., 
        severity = orch.dbgTrace, 
        indent = 0, 
        format = NULL,
        quote = TRUE,
        .parent = 0)
{
    # the trick is to wrap local variables into a function call which
    # allows dlogp to parse it out and extract their names.
    orch.dlogp(...,
        severity = severity,
        indent = indent,
        format = format,
        quote = quote,
        .parent = .parent+1)
}

##
#' Logs one or several local function parameter(s).
#' Example: orch.dlogp(x, y) will print out "x = [value]", "y = [value]".
##
orch.dlogp <- function(..., 
        severity = orch.dbgTrace, 
        indent = 0, 
        format = NULL,
        quote = TRUE,
       .parent = 0)
{
    if (.orch.dbg.hide()) {
        return()
    }
    v <- list(...)
    if (length(v) > 0) {
        pcall <- sys.call(sys.parent(.parent))
        x <- sapply(match.call(call=pcall)[-1], 
            function(x) {
                # IMPORTANT. deparse() will brake source text into lines at cutoff
                # length with extra 4 spaces at the beginning of 2nd and following
                # lines. We need to concatinate all together because there is no
                # way to prevent this braking.
                src <- deparse(x, width.cutoff=500)
                paste0(gsub("^ *", '', src),
                    collapse='')
            })
        for (i in seq_along(x)) {
            p <- x[i]
            n <- names(x)[i]
            if (is.null(n) || n == '') {
                # print only non-named input parameters, e.g. everything that
                # was specified in "..." list and skip control parameters.
                orch.dlogv(p, v[[i]], 
                    severity = severity, 
                    indent = indent,
                    format = format,
                    quote = quote)
            }
        }
    }
}

##
#' Logs all actual parameters of the function this orch.dlogp2 was invoked.
#' Example: f<-function(a,b,c){orch.dlogp2()} will log values of a, b, c.
##
orch.dlogp2 <- function(
        severity = orch.dbgTrace, 
        indent = 0, 
        format = NULL,
        quote = TRUE,
        .parent = 1)
{
    # Match parent function definition with actuall call to extract names
    # of assigned parameters.
    funDef <- sys.function(sys.parent(.parent))
    funCall <- sys.call(sys.parent(.parent))
    args <- names(match.call(funDef, funCall)[-1])
    
    # Get current namespace. In dev mode package will be ".GlobalEnv" and
    # all function are available globally. In packaged mode it suppose to
    # be "ORCH" and invokation must be done with "ORCH:::" notation.
    pkg <- getPackageName()
    ns <- ifelse(pkg != ".GlobalEnv",
        sprintf("%s:::", pkg),
        "") # global namespace
    
    # Invoke orch.dlogp function in the parent function context for each
    # matched argument. We can't use do.call here because we match only
    # only argument names, not argument values.
    for (n in args) {
        eval.parent(parse(text=paste0(ns,
            "orch.dlogp(",n,",",
                "severity=",severity,",",
                "indent=",indent,",",
                "format=",format,",",
                "quote=",quote,",",
                ".parent=",.parent-1,")"
            )))
    }
}

##
#' Log an SQL query string and return the query back.
#' Usage: dbSendQuery(orch.dlogq("select * from table")).
##
orch.dlogq <- function(qry, indent=0)
{
    orch.dlog(orch.dbgQuery, qry, indent)
    qry
}

##
#' Formats a command for logging.
#' @example: 
#'     .shfmt('/bin/bash') #-> "bash"
#'     .shfmt('(/bin/bash)') #-> "( bash )"
##
.shfmt <- function(cmd)
{
    sapply(cmd, 
        function(cmd) {
            cmd <- 
                gsub("(", " ( ", fixed=T, x=
                gsub(")", " ) ", fixed=T, x=
                    cmd))
            cl <- strsplit(cmd, ' ', f=T, u=T)[[1]]
            cl <- cl[cl != ""] # drop extra spaces
            i <- ifelse(cl[1] == "(", 2, 1)
            cl[i] <- basename(cl[i])
            paste(cl, collapse=' ')
        }, 
        USE.NAMES = F)
}

##
#' Log a shell command string and return the command back.
#' Usage: system(orch.dlogsh("ls *")).
##
orch.dlogsh <- function(cmd, indent=0, result=F)
{
    n <- length(cmd)
    lines <- seq_len(n)
    nskip <- n - .orch.dbg.env$max.msg.repeat
    if (nskip > 0L) {
        # limit number of log lines
        tail <- floor(.orch.dbg.env$max.msg.repeat / 2L)
        lines <- c(lines[1:tail], -1, lines[(n-tail+1):n])
        skipMsg <- sprintf("{skipped %d lines%s}", nskip, .s(nskip))
    }
    for (i in lines) {
        if (i < 0) {
            cmd1 <- skipMsg
        }
        else {
            cmd1 <- cmd[i]
            if (!.orch.dbg.env$show.cmdpath && !result) {
                cmd1 <- .shfmt(cmd1)
            }
        }
        cmd1 <- paste(ifelse(result,'<','>'), cmd1)
        orch.dlog(orch.dbgShell, cmd1, indent)
    }
    cmd
}

##
#' Logs a warning message. Example: orch.dlogw("everything is going to hell", 
#' 666) prints out "(W#666) everything is going to hell" :-).
##
orch.dlogw <- function(msg, ..., warn=-1, indent=0, stop=F, cat=F)
{
    severity <- orch.dbgWarning
    if (!.orch.dbg.show() && !stop && !cat) {
        return()
    }
    msg <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    if (!is.null(warn) && warn >= 0) {
        msg <- sprintf("(W#%d) %s", warn, msg)
    }
    for (msg in msg) {
        orch.dlog(severity, msg, indent, stop=stop, cat=cat)
    }
}

##
#' Logs an error message. Example: orch.dloge("everything went to hell", 666) 
#' prints out "(E#666) everything went to hell" :-).
##
orch.dloge <- function(msg, ..., err=-1, indent=0, stop=F, cat=F)
{
    severity <- orch.dbgError
    if (!.orch.dbg.show() && !stop && !cat) {
        return()
    }
    msg <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    if (!is.null(err) && err >= 0) {
        msg <- sprintf("(E#%d) %s", err, msg)
    }
    for (msg in msg) {
        orch.dlog(severity, msg, indent, stop=stop, cat=cat)
    }
}

##
#' Log the current timestamp. Example: orch.dlogt() prints out the current time 
#' and delta from the last call to orch.dlogt(). Used for performance tests.
#'
#' @param msg prefix message, e.g. "hello" -> "hello, timestamp ..."
#' @param resume don't reset the timer, default is FALSE
##
orch.dlogt <- function(msg='', ..., resume=F, indent=0)
{
    msg <- null.to(msg, '')
    if (msg != '') {
        msg <- paste(msg, 'at')
        p <- .orch.dbg.nlist(...)
        if (length(p) > 0) {
            msg <- do.call(sprintf, append(list(msg), p))
        }
    }
    else {
        msg <- 'timestamp'
    }
    t <- Sys.time()
    tstr <- sprintf('%s %s, diff%s', msg, 
        format(t, '%H:%M:%S'), 
        ifelse(resume, '+', ''))
    orch.dlog.timer(tstr, t-.orch.dbg.env$ts)
    if (!resume) {
        .orch.dbg.env$ts <- t
    }
}

##
#' Resets the timer and starts the new global countdown. Every subsequent call
#' to orch.dlogt() will measure the time from this point of time.
##
orch.dbg.newtimer <- function(msg='', indent=0)
{
    if (is.null(msg)) {
        msg <- ''
    }
    if (msg != '') {
        msg <- paste(msg, ', ', sep='')
    }
    t <- Sys.time()
    .orch.dbg.env$ts <- t
    tstr <- sprintf('%stimer started @ %s', msg, format(t, '%H:%M:%S'))
    orch.dlog(orch.dbgInfo, tstr, indent=indent)
}

##
#' Traces function call in.
#' If function name is not supplied it's taken from the call stack.
##
orch.dlogi <- function(fn.name, timer=F, indent=0, .parent=1)
{
    if (missing(fn.name)) {
        pcall <- sys.call(sys.parent(.parent))
        fn.name <- sub('\\(.*$', '', pcall[1])
    }
    orch.dlog.trace('::> called %s', fn.name, i=indent)
    if (timer) {
        Sys.time()
    }
}

##
#' Traces function call out.
#' If function name is not supplied it's taken from the call stack.
##
orch.dlogo <- function(fn.name, timer=NULL, indent=0, .parent=1)
{
    if (missing(fn.name)) {
        pcall <- sys.call(sys.parent(.parent))
        fn.name <- sub('\\(.*$', '', pcall[1])
    }
    if (!is.null(timer)) {
        tmsg <- paste(fn.name, 'clocked at')
        orch.dlog.timer(tmsg, Sys.time()-timer)
    }
    orch.dlog.trace('<:: ended %s', fn.name, i=indent)
}

##
#' Logs an debug message. Example: orch.dlogd("everything is going to hell") 
#' prints out "[DEBUG] everything is going to hell" :-). Shortcut for
#' orch.dlog.debug().
##
orch.dlogd <- function(msg, ..., err=-1, indent=0)
{
    severity <- orch.dbgDebug
    if (!.orch.dbg.show()) {
        return()
    }
    msg <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    for (msg in msg) {
        orch.dlog(severity, msg, indent)
    }
}

##
#' Logs a generic debug message.
#' Usage: orch.dlog(orch.dbgFatal, "HELP!").
##
orch.dlog <- function(err, msg, 
        indent = 0, 
        stop = FALSE, 
        cat = FALSE)
{
    msg <- strim(msg)
    msg <- msg[msg != ""]
    
    severity <- err
    if (err <= orch.dbgError) {
        .orch.dbg.env$lasterr <- msg
    }
    show <- .orch.dbg.show() && length(msg) > 0
    disp <- .orch.dbg.env$stdout && show
    if (show) {
        muted <- .orch.dbg.muted(msg)
        if (all(muted)) {
            show <- FALSE
        }
    }
    if (show) {
        # truncate too long messages as specified in options, appends 
        # "... {X truncated}" to indicate that its partially missing
        logMsg <- sapply(msg[!muted], function(x) {
            truncLen <- nchar(x) - .orch.dbg.env$max.msg.length
            if (truncLen > 0) {
                x <- sprintf("%s... {%.0f truncated}",
                    substr(x, 1, .orch.dbg.env$max.msg.length),
                    truncLen)
            }
            x
        })
        logMsg <- paste(.orch.dbg.pfx(), logMsg)
        write(logMsg, .orch.dbg.env$output, app=T)
        if (disp) {
            cat <- FALSE
        }
    }
    stop <- stop && .orch.dbg.env$stop.enabled
    if (stop) {
        if (.orch.dbg.env$show.stopmsg && !disp) {
            stopMsg <- paste0(msg, collapse='\n')
            cat <- FALSE
        }
        else {
            stopMsg <- "execution aborted"
        }
    }
    if (cat) {
		sevStr <- cap(.orch.dbg.sv2str(severity), strict=T)
        for (msg1 in msg) {
            cat(sevStr, ": ", msg1, '\n', sep='')
        }
    }
    if (stop) {
        stop(stopMsg, call.=FALSE)
    }
}

##
#' Prints out a message to stdout and debug log both tf debug log output 
#' is not set to stdout already.
#' 
#' @param msg Message(s) to display in printf format.
#' @param ... Message optional variables.
#' @param sep Message line separator, "\n" by default.
#' @param err Output to stderr instead of stdout.
##
orch.dcat <- function(msg, ..., sep="\n", err=FALSE)
{
    if (length(msg) > 0) {
        str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
        if (!.orch.dbg.env$stdout) {
            orch.dlog(orch.dbgSuper, str)
        }
        cat(str, sep=sep,
            file = if (err) stderr() 
                else stdout())
    }
}

##
#' Returns the very last error message reported.
##
orch.dbg.lasterr <- function()
{
    .orch.dbg.env$lasterr
}

##
# Set of logging shortcuts for each severity.
# --->
orch.dlog.fatal <- function(msg, ..., i=0, stop=F, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgFatal, str, indent=i, stop=stop, cat=cat)
}

orch.dlog.critical <- function(msg, ..., i=0, stop=F, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgCritical, str, indent=i, stop=stop, cat=cat)
}

orch.dlog.error <- function(msg, ..., i=0, stop=F, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgError, str, indent=i, stop=stop, cat=cat)
}

orch.dlog.stop <- function(msg, ..., i=0, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog.error(str, indent=i, stop=T, cat=cat)
}

orch.dlog.warning <- function(msg, ..., i=0, stop=F, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgWarning, str, indent=i, stop=stop, cat=cat)
}

orch.dlog.debug <- function(msg, ..., i=0)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgDebug, str, indent=i)
}

orch.dlog.info <- function(msg, ..., i=0, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgInfo, str, indent=i, cat=cat)
}
# <---
# End of logging shortcuts for each severity.
##

##
#' Logs all attributes of the given R object. Very useful for logging ORCH
#' attributes set for keyValue objects or configuration settings.
##
orch.dlog.attr <- function(..., i=0)
{
    v <- list(...)
    x <- sapply(match.call(call=sys.call())[-1], deparse)
    for (i in seq_len(length(x))) {
        p <- x[i]
        pn <- names(x)[i]
        # print only non-named input arguments
        if (!is.null(pn) && pn != '') {
            next
        }
        va <- attributes(v[[i]])
        vn <- names(va)
        # print "var[attr] = val" trace
        for (j in seq_len(length(va))) {
            attr <- sprintf("%s[%s]", x[i], vn[j])
            orch.dlogv(attr, list(va[[j]]))
        }
    }
}

##
#' Logs timing measurements. Message can be specified to describe the object. 
#' If message is not specified then "var timing XXX sec" is used. If message 
#' has no "%s" tags then the object size is appended to the end. If \p t is
#' missing then \p msg is assumed to contain the timing value.
#' 
#' @example orch.dlog.timer("ended at", Sys.time()) -> "ended at hh:mm:ss"
#' @example orch.dlog.timer(Sys.time()) -> "Sys.time() timing hh:mm:ss"
#' 
#' @param msg custom log message or an object if \p t is missing
#' @param t difftime object, obtained via Sys.time() substraction
#' @param i indentation of the log message
##
orch.dlog.timer <- function(msg, t, i=0)
{
    if (missing(t)) {
        # assume call: orch.dlog.timer(my_timer)
        t <- msg
        tName <- deparse(substitute(msg))
        msg <- sprintf("%s timing %%s", tName)
    }
    else {
        # assume call: orch.dlog.timer("my_timer", my_timer)
        msg <- null.to(msg, '')
        if (!grepl("%s", msg, fixed=T)) {
            msg <- sprintf("%s %%s", strim(msg))
        }
    }
    str <- sprintf(msg, format(t))
    orch.dlog(orch.dbgTrace, str, indent=i)
}

##
#' Logs memory usage by an R object \p x. Message can be specified to describe
#' the object. If message is not specified then "object "var" uses XXX" is used.
#' If message has no "%s" tags then the object size is appended to the end.
#' 
#' @param msg custom log message or an object if \p x is missing
#' @param x object to log the memory usage
#' @param i indentation of the log message
##
orch.dlog.memory <- function(msg, x, i=0)
{
    if (missing(x)) {
        x <- msg
        xName <- deparse(substitute(msg))
        msg <- sprintf("object \"%s\" uses %%s", xName)
    }
    if (!grepl("%s", msg, fixed=T)) {
        msg <- sprintf("%s %%s", strim(msg))
    }
    str <- sprintf(msg, mem2str(object.size(x)))
    orch.dlog(orch.dbgInfo, str, indent=i)
}

orch.dlog.trace <- function(msg, ..., i=0)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgTrace, str, indent=i)
}

orch.dlog.query <- function(msg, ..., i=0)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgQuery, str, indent=i)
}

orch.dlog.shell <- function(msg, ..., i=0)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgShell, str, indent=i)
}

orch.dlog.system <- function(msg, ..., i=0, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgSystem, str, indent=i, cat=cat)
}

orch.dlog.super <- function(msg, ..., i=0, cat=F)
{
    str <- do.call(sprintf, append(list(msg), .orch.dbg.nlist(...)))
    orch.dlog(orch.dbgSuper, str, indent=i, cat=cat)
}

# <---
##

##
#' Makes a generic debug block.
#' Usage: if (orch.dblock()) { ... debug code ... }.
##
orch.dblock <- function(severity)
{
    !.orch.dbg.hide()
}

# Set of debug block shortcuts for each severity.
orch.dblock.fatal <- function() orch.dblock(orch.dbgFatal)
orch.dblock.critical <- function() orch.dblock(orch.dbgCritical)
orch.dblock.error <- function() orch.dblock(orch.dbgError)
orch.dblock.warning <- function() orch.dblock(orch.dbgWarning)
orch.dblock.debug <- function() orch.dblock(orch.dbgDebug)
orch.dblock.info <- function() orch.dblock(orch.dbgInfo)
orch.dblock.trace <- function() orch.dblock(orch.dbgTrace)
orch.dblock.query <- function() orch.dblock(orch.dbgQuery)
orch.dblock.shell <- function() orch.dblock(orch.dbgShell)
orch.dblock.system <- function() orch.dblock(orch.dbgSystem)
orch.dblock.super <- function() orch.dblock(orch.dbgSuper)

##
#' Experimental.
##
orch.dbg.top <- function() 
{
    top <- .sh('top -l 1 -pid 0', quiet=T)[-11:-13]
    stat <- list()
    for (l in top) {
        l <- strim(strsplit(l, ':')[[1]])
        if (length(l) == 2) {
            name <- gsub(' ', '', 
                cap.all(l[1], sep=' '), 
                fixed=T)
            stat[name] <- l[2]
        }
    }
    stat
}

##
#' Experimental.
##
orch.dbg.procinfo <- function() 
{
    proc <- .sh('top -l 1 -pid %s', Sys.getpid(), quiet=T)[12:13]
    names <- strim(strsplit(proc[1], ' +')[[1]])
    values <- strim(strsplit(proc[2], ' +')[[1]])
    stat <- list()
    for (i in 1:length(names)) {
        stat[names[i]] <- values[i]
    }
    stat
}

##
#' Experimental.
##
orch.dlog.procinfo <- function()
{
    stat <- orch.dbg.procinfo()
    orch.dlog.info("execution time = %s", stat$TIME)
    orch.dlog.info("number of threads = %s", stat$'#TH')
    orch.dlog.info("resident private address space = %s", stat$RPRVT)
    orch.dlog.info("resident shared address space = %s", stat$RSHRD)
    orch.dlog.info("resident memory = %s", stat$RSIZE)
    orch.dlog.info("private address space = %s", stat$VPRVT)
    orch.dlog.info("total memory = %s", stat$VSIZE)
}

## ------------------------------------------------------------------------- ##
##                            DBG INITIALIZATION                             ##
## ------------------------------------------------------------------------- ##

# Turn on asserts if debug is enabled.
if (.orch.dbg.env$assert) {
    .assert <- .checkpoint
    orch.dlog.system("asserts are ON")
}
