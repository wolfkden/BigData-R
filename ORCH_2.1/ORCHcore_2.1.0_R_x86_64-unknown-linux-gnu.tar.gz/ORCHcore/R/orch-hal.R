# Copyright (c) 2012, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' Oracle R Connector for Hadoop.
#' @name ORCH package
#' @docType package
#' 
#' Hadoop command abstraction layer. Turns out that Hadoop has a tendency to
#' change its CLI signature from distribution to distribution (e.g. CHD3->CHD4)
#' which brakes ORCH. To avoid this in future all Hadoop CLI interaction 
#' functions must be abstracted into one layer rather than invoking them 
#' directly in ORCH code via .sh() interface.
#' 
#' Also abstraction of the commands will give us a possibility to switch to
#' another Hadoop command transport layer later on without touching the ORCH
#' code itself. Planned command transport layers are ssh, REST, WebFS.
#' 
#' ORCH -> HAL -...-> shell
#'               |.-> ssh
#'               |.-> REST
#'               |.-> WebFS
##

###############################
# DO NOT INCLUDE AND SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

## ------------------------------------------------------------------------- ##
##                           HAL PUBLIC FUNCTIONS                            ##
## ------------------------------------------------------------------------- ##

##
#' List of all HAL API functions.
#' Each function must have an implementation in the following format:
#'     <function_name>.<transport_layer>.mr<mapred_version>
#' @examples
#'     .hal.dfs.rmr.sh.mr1 <- function() ...
#'     .hal.dfs.rmr.sh.mr2 <- function() ...
#' 
#' Supported transport layers:
#'     "sh"
#' Supported MR version:
#'     "1" - all updates of CDH3
#'     "1_1" - CDH4 with MR1
#'     "2" - CDH4 with MR2
#' 
#' @seealso .hal.select
##
.hal.functions <- c(
    ".hal.dfs.sh", 
    ".hal.dfs.rmr",
    ".hal.dfs.df",
    ".hal.dfs.mkdir",
    ".hal.dfs.exists",
    ".hal.dfs.stat",
    ".hal.dfs.mv",
    ".hal.dfs.cp",
    ".hal.dfs.ls",
    ".hal.dfs.cat",
    ".hal.dfs.acat",
    ".hal.dfs.put",
    ".hal.dfs.get",
    ".hal.dfs.aget",
    ".hal.dfs.tail",
    ".hal.dfs.head",
    ".hal.hadoop.jobs",
    ".hal.hadoop.streaming.path")

##
#' Switches between different Hadoop abstraction layers.
#' @param mr MapReduce version.
#' @param transport Communication transport layer to use
#' 
#' Supported transport layers:
#'     "sh"
#' Supported MR version:
#'     "1" - all updates of CDH3
#'     "1_1" - CDH4 with MR1
#'     "2" - CDH4 with MR2
#' 
#' @example .hal.choose(mr=2) # switches to mapReduce v2, CLI.
#' @example .hal.choose(mr=1, tranport="ssh") # switches to mapReduce v1 via SSH.
##
.hal.select <- function(mr, transport='sh')
{
    .assert(mr %in% c(1, 1.1, 2))
    .assert(transport %in% c("sh"))
    
    halId <- paste0(transport, ".mr", gsub("\\.", "_", mr))
    orch.dlog.info("initializing HAL to %s", halId)
    for (fn in .hal.functions) {
        mapFn <- paste0(fn, ".", halId)
        if (exists(mapFn)) {
            eval(parse(text=paste0(fn, "<<-", mapFn)))
            orch.dlog.debug("%s -> %s", fn, mapFn)
        }
        else {
            mapFn <- paste0(fn, ".", transport)
            eval(parse(text=paste0(fn, "<<-", mapFn)))
            orch.dlog.debug("%s -> %s (default)", fn, mapFn)
        }
    }
}

## ------------------------------------------------------------------------- ##
##                          HAL PRIVATE FUNCTIONS                            ##
## ------------------------------------------------------------------------- ##

##
#' Validates response of a CLI function to be as expected. Must be used after 
#' each *.sh call to ensure that Hadoop behaves as expected.
#' 
#' @param out Shell command output, vector of strings.
#' @param ... Regexpr strings to match with.
#' 
#' @return \p out
##
.check.response <- function(out, ...)
{
    for (ln in out) {
        if (!.sh.match(ln, ...)) {
            orch.dlogw("unexpected response: %s", ln)
        }
    }
    out
}

## ------------------------------------------------------------------------- ##
## HAL: .dfs.sh                                                              ##
## ------------------------------------------------------------------------- ##

##
#' Invokes "hadoop" CLI for HDFS specifically. Depending on the detected
#' version of Hadoop will use MR1 or MR2 CLI commands.
#' 
#' @example MR1: .hal.dfs.sh(a=1, 'z') ==> "hadoop fs -a 1 'z'".
#' @example MR2: .hal.dfs.sh(a=1, 'z') ==> "hdfs dfs -a 1 'z'".
#' 
#' @param ... Set of command line options.
#' @param print T if you want to just print out the command line.
#' @param noerr Ignore stderr output.
#' @param async Run the command in asynchronous mode; if it's numeric value
#'     then it specifies timeout of the command execution.
#' 
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop. Non 0 value
#'     of .sh.error() indicates failure.
##
.hal.dfs.sh <- function(..., async = FALSE)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.sh.sh <- function(..., async = FALSE)
{
    cmd <- paste0(.hadoop.path(), '/bin/hadoop fs ')
    .sh.cmd(cmd, ..., async = async)
}

.hal.dfs.sh.sh.mr2 <- function(..., async = FALSE)
{
    cmd <- paste0(.hadoop.path(), '/bin/hdfs dfs ')
    .sh.cmd(cmd, ..., async = async)
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.rmr                                                              ##
## ------------------------------------------------------------------------- ##

##
#' Removes an HDFS object recursively. Internally can use MR1 or MR2 CLI
#' interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path of a file or a directory to remove.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.rmr <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.rmr.sh.mr1 <- function(path)
{
    out <- .hal.dfs.sh(rmr=path)
    .check.response(out,
        "^$", 
        "^Deleted .+$", 
        "^Moved .+$", 
        "^rmr: cannot remove .*: No such file or directory.$")
}

.hal.dfs.rmr.sh <- function(path)
{
    out <- .hal.dfs.sh(rm=NULL, r=NULL, path)
    .check.response(out,
        "^$", 
        "^Deleted .+$", 
        "^Moved .+$", 
        "^rm: .*: No such file or directory$")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.df                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Returns HDFS free disk space info. Internally can use MR1 or MR2 CLI
#' interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to inspect.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.df <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.df.sh <- function(path)
{
    out <- .hal.dfs.sh(df=path)
    .check.response(out,
        "^Filesystem *Size *Used *Available *Use%$",
        "[^ ]* *[0-9]* *[0-9]* *[0-9]* [0-9]*%")
}

.hal.dfs.df.sh.mr1 <- function(path)
{
    out <- .hal.dfs.sh(df=path)
    .check.response(out,
        "^Filesystem *Size *Used *Avail *Use%$",
        "[^ ]* *[0-9]* *[0-9]* *[0-9]* [0-9]*%")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.mkdir                                                            ##
## ------------------------------------------------------------------------- ##

##
#' Creates a new HDFS directory. Internally can use MR1 or MR2 CLI interface 
#' to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to create.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.mkdir <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.mkdir.sh <- function(path)
{
    out <- .hal.dfs.sh(mkdir=path)
    .check.response(out, 
        "^$",
        "^mkdir: .*: Input/output error$",
        "^mkdir: .*: File exists$")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.exists                                                           ##
## ------------------------------------------------------------------------- ##

##
#' Checks that the specified HDFS path. Internally can use MR1 or MR2 CLI 
#' interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to check.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.exists <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.exists.sh <- function(path)
{
    out <- .hal.dfs.sh(test=NULL, e=NULL, path)
    .check.response(out, "^$")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.stat                                                             ##
## ------------------------------------------------------------------------- ##

##
#' Returns the stat information on the HDFS path. Internally can use MR1 or MR2 
#' CLI interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to check.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.stat <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.stat.sh <- function(path)
{
    out <- .hal.dfs.sh(stat=path)
    .check.response(out, 
        "^[0-9]+-[0-9]+-[0-9]+ [0-9]+:[0-9]+:[0-9]+$",
        "^stat: .*: No such file or directory$")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.mv                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Moves HDFS files from source to destination. Internally can use MR1 or MR2 
#' CLI interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param src HDFS source path.
#' @param dst HDFS destination path.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.mv <- function(src, dst)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.mv.sh <- function(src, dst)
{
    if (ends(src, "/*")) {
        # Fix: Hadoop's "mv" function has a bug. When you move "*" into a
        # a non-existing directory it will rename the 1st directory from "*"
        # list into the destination directory and then move the rest into this 
        # directory. We need "*" to move everything into a new directory.
        .hal.dfs.exists(dst)
        if (.sh.error() != 0) {
            out <- .hal.dfs.mkdir(dst)
            if (.sh.error() != 0) {
                # no reason to run "mv" if "mkdir" failed
                return (out)
            }
        }
    }
    out <- .hal.dfs.sh(mv=src, dst)
    .check.response(out, 
        "^$",
        "^mv: .*: No such file or directory$",
        "^mv: .*: Input/output error$")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.cp                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Copy HDFS files from source to destination. Internally can use MR1 or MR2 
#' CLI interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param src HDFS source path.
#' @param dst HDFS destination path.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.cp <- function(src, dst)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.cp.sh <- function(src, dst)
{
    out <- .hal.dfs.sh(cp=src, dst)
    .check.response(out, 
        "^$",
        "^cp: .*: No such file or directory$",
        "^cp: .*: Input/output error$")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.ls                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Returns a list of an HDFS directory direct children as in unix. Internally 
#' can use MR1 or MR2 CLI interface to interact with HDFS depending on the 
#' detected Hadoop version.
#' 
#' @param path HDFS path to list.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.ls <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.ls.sh <- function(path)
{
    out <- .hal.dfs.sh(ls=path)
    .check.response(out, 
        "^$",
        "^Found .+ items$",
        "^ls: .*: No such file or directory$",
        "^ls: .*: Input/output error$",
        "^[drwxt-]+ .*$")
    
    # "hdfs fs -ls" returns "Found 'x' items" in the first line, remove it!
    if (.sh.error() == 0) {
        if (!is.null(out) && length(out) > 0) {
            out <- out[-1]
        }
    }
    out
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.cat                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Copies source paths to stdout. Internally can use MR1 or MR2 CLI interface 
#' to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to list.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.cat <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.cat.sh <- function(path)
{
    out <- .hal.dfs.sh(cat=path)
    if (.sh.error() != 0) {
        .check.response(out, 
            "^$",
            "^cat: .*: No such file or directory$",
            "^cat: .*: Is a directory$")
    }
    else {
        # "cat" command is unique in a sense that we can't really verify
        # its output if it succeeds because file which was printed out can
        # contail any text including Hadoop logs with error messages.
        out
    }
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.acat                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Copies source paths to stdout. Internally can use MR1 or MR2 CLI interface 
#' to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to list.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.acat <- function(path, timeout)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.acat.sh <- function(path, timeout)
{
    if (missing(timeout)) {
        .hal.dfs.sh(cat=path, async=TRUE)
    }
    else {
        out <- .hal.dfs.sh(cat=path, async=timeout)
        if (.sh.error() != 0 && !.sh.killed()) {
            .check.response(out, 
                "^$",
                "^cat: .*: No such file or directory$",
                "^cat: .*: Is a directory$")
        }
        else {
            # "cat" command is unique in a sense that we can't really verify
            # its output if it succeeds because file which was printed out can
            # contail any text including Hadoop logs with error messages.
            out
        }
    }
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.put                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Copy a single \p src from a local file system to the destination HDFS 
#' file system. Internally can use MR1 or MR2 CLI interface to interact with 
#' HDFS depending on the detected Hadoop version.
#' 
#' @param src HDFS source path.
#' @param dst HDFS destination path.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.put <- function(src, dst)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.put.sh <- function(src, dst)
{
    out <- .hal.dfs.sh(put=src, dst)
    .check.response(out, 
        "^$",
        "^put: .*: File exists$",
        "^put: .*: No such file or directory$")
}

.hal.dfs.put.sh.mr1_1 <- function(src, dst)
{
    # in CDH4_MR1 "fs -put" does not create directory
    .hal.dfs.mkdir.sh(dirname(dst))
    .hal.dfs.put.sh(src, dst)
}

.hal.dfs.put.sh.mr2 <- function(src, dst)
{
    # in CDH4_MR2 "fs -put" does not create directory
    .hal.dfs.mkdir.sh(dirname(dst))
    .hal.dfs.put.sh(src, dst)
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.get                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Copy a single \p src from a HDFS file system to the destination local 
#' file system. Internally can use MR1 or MR2 CLI interface to interact with 
#' HDFS depending on the detected Hadoop version.
#' 
#' @param src HDFS source path.
#' @param dst HDFS destination path.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.get <- function(src, dst)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.get.sh <- function(src, dst)
{
    out <- .hal.dfs.sh(get=src, dst)
    .check.response(out, 
        "^$",
        "^get: .*: File exists$",
        "^get: .*: No such file or directory$")
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.aget                                                               ##
## ------------------------------------------------------------------------- ##

##
#' Asynchronous copy a single \p src from a HDFS file system to the destination 
#' local file system. Internally can use MR1 or MR2 CLI interface to interact 
#' with HDFS depending on the detected Hadoop version.
#' 
#' @param src HDFS source path.
#' @param dst HDFS destination path.
#' @param timeout Run for the specified number of second and abort.
#' @return Command stdout + stderr output as a char vector if [timeout] is 
#'     specified, otherwise PID of a background copy process. Also retrieves 
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.aget <- function(src, dst, timeout)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.aget.sh <- function(src, dst, timeout)
{
    if (missing(timeout)) {
        .hal.dfs.sh(get=src, dst, async=TRUE)
    }
    else {
        out <- .hal.dfs.sh(get=src, dst, async=timeout)
        .check.response(out, 
            "^$",
            "^get: .*: File exists$",
            "^get: .*: No such file or directory$")
    }
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.tail                                                             ##
## ------------------------------------------------------------------------- ##

##
#' Displays last kilobyte of the file to stdout. Internally can use MR1 or MR2 
#' CLI interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to read.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.tail <- function(path)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.tail.sh <- function(path)
{
    out <- .hal.dfs.sh(tail=path)
    if (.sh.error() != 0) {
        .check.response(out, 
            "^$",
            "^tail: .*: Is a directory$",
            "^tail: .*: No such file or directory$")
    }
    else {
        # "tail" command is unique in a sense that we can't really verify
        # its output if it succeeds because file which was printed out can
        # contail any text including Hadoop logs with error messages.
        out
    }
}

## ------------------------------------------------------------------------- ##
## .hal.dfs.head                                                             ##
## ------------------------------------------------------------------------- ##

##
#' Displays last kilobyte of the file to stdout. Internally can use MR1 or MR2 
#' CLI interface to interact with HDFS depending on the detected Hadoop version.
#' 
#' @param path HDFS path to read.
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.dfs.head <- function(path, timeout=3)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.dfs.head.sh <- function(path, timeout=3)
{
    out <- .hal.dfs.sh(cat=path, async=timeout)
    if (.sh.error() != 0) {
        .check.response(out, 
            "^$",
            "^cat: .*: No such file or directory$",
            "^cat: .*: Is a directory$")
    }
    else {
        # "cat" command is unique in a sense that we can't really verify
        # its output if it succeeds because file which was printed out can
        # contail any text including Hadoop logs with error messages.
        out
    }
}

## ------------------------------------------------------------------------- ##
## .hal.hadoop.jobs                                                          ##
## ------------------------------------------------------------------------- ##

##
#' Displays list of currently running jobs of a cluster. Internally can use MR1 
#' or MR2 CLI interface to interact with Hadoop jobtracker.
#' 
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.hadoop.jobs <- function()
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.hadoop.jobs.sh <- function(path)
{
    out <- .hadoop.sh('job', list=NULL)
    .check.response(out, 
        "^[0-9]* jobs currently running$",
        "^JobId\tState\tStartTime\tUserName\tPriority\tSchedulingInfo$",
        "^[0-9]*\t[^ ]*\t[^ ]*\t[^ ]*\t[0-9]*\t[^ ]*$")
}

## ------------------------------------------------------------------------- ##
## .hal.hadoop.streaming.path                                                ##
## ------------------------------------------------------------------------- ##

##
#' Returns Hadoop streaming library path specific for the current version of
#' mapReduce. Unfortunately the guys are changing the structure of Hadoop
#' deployment from version to version.
#' 
#' @return Command stdout + stderr output as a char vector. Also retrieves
#'     and sets .sh.error() to the last error code from Hadoop.
##
.hal.hadoop.streaming.path <- function(home)
{
    orch.dlog.fatal("HAL not initialized", 
        stop=T, cat=T)
}

.hal.hadoop.streaming.path.sh <- function(home)
{
    if (home == "/usr") {
        # RPM installation detected, look for mapreduce directory. 
        path <- "/usr/lib"
        home <- dir(path, pattern="^hadoop-.*-mapreduce$")
        if (length(home) == 0) {
            orch.dloge("Hadoop home is not found at \"%s\"", 
                path, stop=T, cat=T)
            home <- NULL
        }
        else if (length(home) > 1) {
            orch.dloge("multiple Hadoop versions found at \"%s\"", 
                path, stop=T, cat=T)
            home <- NULL
        }
        else {
            home <- paste(path, home, sep='/')
            orch.dlog.info("found hadoop home at \"%s\"", home)
        }
    }
    if (!is.null(home)) {
        home <- sprintf("%s/contrib/streaming", home)
    }
    home
}

.hal.hadoop.streaming.path.sh.mr1 <- function(home)
{
    sprintf("%s/contrib/streaming", home)
}
