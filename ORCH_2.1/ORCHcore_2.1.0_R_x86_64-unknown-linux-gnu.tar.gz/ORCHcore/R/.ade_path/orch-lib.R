# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' Oracle R Connector for Hadoop shared library.
#' @name ORCH package
#' @docType package
##

###############################
# DO NOT INCLUDE ANY SOURCES! #
###############################

##
#' Packs one (key, value) pair into mapReduce-compatible structure. 
#' To make value-only keyval object use .make.keyval(<values>).
#' To make key-only keyval object use .make.keyval(key=<key>).
#' 
#' @param val vector / list / data.frame[1,] / NULL.
#' @param i Key value index in \p val (if key==NULL).
#' @param key Key value (if i==0).
#' 
#' @return keyval data structure as
#'     list(key=<value>|NULL, val=list(<value>,...))
##
.make.keyval <- function(val, i=0, key=NULL)
{
    if (i > 0) {
        # values contain the key too.
        .assert(is.null(key))
        key <- val[[i]]
        val <- val[-i]
    }
    if (missing(val) || length(val) == 0) {
        # no-value pair detected
        val <- NULL
    }
    
    # Create keyval structure with the following format: 
    # list(key=<value>|NULL, val=list(<value>,...))
    .assert(is.null(key) || length(key) == 1)
    kv <- list(key = key, val = c(val))
    attr(kv, 'orch.kv1') <- TRUE
    
    # Good to go.
    .assert(.is.keyval(kv))
    kv
}

##
#' Returns TRUE is this is the keyval data type.
#' @note Works for both lists and single values.
##
.is.keyval <- function(kv)
{
    if (!is.list(kv)) {
        FALSE
    }
    else {
        chk.attr <- function(kv) {
            type <- attr(kv, 'orch.kv1', exact=T)
            !is.null(type) && type
        }
        chk.attr(kv) || 
            all(sapply(kv, chk.attr))
    }
}

##
#' Serializes ORCH metadata attached to a keyValue object into a string.
#' The string can be stored in a file alongside with the data itself for 
#' persistency.
#'
#' Extracted metadata format (<...> = replace keyword):
#' [mandatory meta fields]
#'     orch.kvs\t<TRUE=reserved>
#'     orch.class\t"<R_type_name>"
#'     orch.types\t"<type_name_1>"[,"type_name_2"[...]]
#'     orch.keyi\t<-1=has no key|0=key is empty|1+=has key #>
#' [the rest of of meta fields are optional]
#'     orch.names\t<R_colnames>
#'     orch.dim\t<rows>,<cols>
#'     orch.rownamei\t<0=no rownames|1+=rownames at col #>
#' [deprecated meta fields]
#'     orch.rnames\t<R_colnames>
#'     orch.cnames\t<R_colnames>
#' 
#' @param obj An object containing meta attributes (if \p attr is missing).
#' @param attr Meta attributes as a list (if \p obj is missing).
#' @return A string with all "orch." attributes.
#' 
#' @seealso .parse.meta
#' @seealso .valdate.meta
##
.paste.meta <- function(obj, attr)
{
    # Grab all attributes from the object.
    if (missing(attr)) {
        .assert(.is.keyvals(obj))
        attr <- attributes(obj)
    }
    mnames <- names(attr)
    nattr <- length(attr)
    
    # Filter and convert into a string.
    out <- ''
    for (i in 1:nattr) {
        name <- mnames[i]
        if (substr(name, 1, 5) != 'orch.') {
            next
        }
        val <- attr[[i]]
        if (length(val) == 0) {
            val <- paste0(class(val), "()")
        }
        else if (is.character(val)) {
            val <- sprintf('"%s"', 
                gsub("\t", "\\t", fixed=T, x=
                gsub("\n", "\\n", fixed=T, x=
                gsub('"', '\\"', fixed=T, x=val))))
        }
        out <- paste0(out, 
            name, '\t', 
            paste(val, collapse=','), '\n')
    }
    
    # Output format is:
    # <attr name> \t <number> | "<string>" [, ...]
    .assert(out != '')
    out
}

##
#' Serializes ORCH metadata stored as a list of attributes into a string.
#' This is a usability function 
#' The string can be storeto a file with data itself for persistency.
#'
##
.paste.metalist <- function(meta)
{
    x <- list()
    attributes(x) <- meta
    .paste.meta(x)
}

##
#' Parses a meta data string [vector] from .paste.meta(). This function
#' re-creates all serialized attributes and assigns them to the \p obj object.
#' Example: .parse.meta(list(), "orch.class\tnumeric")
#'
#' @param obj An object to assign parsed attributes to | NULL.
#' @param meta String containing meta attributes to parse.
#' @param stop Abort execution if an error found in meta data.
#' @param validate Validate \p meta and return NULL if not valid.
#' 
#' @return Updated \p obj object with ORCH meta attributes set.
#' @return List of ORCH meta attributes if \p obj is NULL.
#' @return NULL if \p validate is TRUE and meta attributes are not valid.
#' 
#' @see .paste.meta()
#' @see .validate.meta()
##
.parse.meta <- function(
        obj, 
        meta, 
        stop = FALSE, 
        validate = FALSE)
{
    # Supports vector of strings or one long '\n'-sep string.
    meta <- unlist(strsplit(meta, '\n'))
    meta <- meta[meta != '']
    if (length(meta) == 0) {
        orch.dloge("no meta attributes found at all", stop=stop)
        if (validate) {
            return (NULL)
        }
    }
    
    # Deserialize "orch.*" attributes. ORCH meta-attributes are stored
    # in a form of key-values tab-separated pairs: <key>\t<value>.
    attr <- list()
    nattr <- 0
    for (pair in meta) {
        kv <- strsplit.one(pair, '\t', fixed=T)[[1]]
        if (length(kv) != 2) {
            orch.dloge("\"%s\" is not a meta attribute", pair, stop=stop)
            if (validate) {
                return (NULL)
            }
        }
        name <- kv[1]
        val <- kv[2]
        if (substr(name, 1, 5) != 'orch.') {
            orch.dloge("\"%s\" is not an ORCH meta attribute", name, stop=stop)
            if (validate) {
                return (NULL)
            }
            else {
                next
            }
        }
        valR <- sprintf("c(%s)", val)
        val <- try(eval(parse(text=valR)), silent=T)
        if (class(val) != "try-error") {
            attr[[name]] <- val
            nattr <- nattr + 1
        }
        else {
            orch.dloge("meta attribute %s is invalid = \"%s\"", name, valR, stop=stop)
            if (validate) {
                return (NULL)
            }
        }
    }
    if (nattr == 0) {
        orch.dloge("no valid ORCH meta attributes found", stop=stop)
        if (validate) { 
            return (NULL)
        }
    }
    
    # Make sure default attributes are set. Some ORCH core code might not
    # check meta attributes for NULLs and fail if it's was not set in HDFS 
    # __ORCHMETA__ files created by older versions of ORCH.
    if (is.null(attr$orch.kvs)) {
        attr$orch.kvs <- TRUE
    }
    if (is.null(attr$orch.class)) {
        attr$orch.class <- "data.frame"
    }
    if (is.null(attr$orch.keyi)) {
        attr$orch.keyi <- -1
    }
    if (is.null(attr$orch.key.sep)) {
        attr$orch.key.sep <- .orch.env$key.sep
    }
    if (is.null(attr$orch.value.sep)) {
        attr$orch.value.sep <- .orch.env$val.sep
    }
    if (is.null(attr$orch.types)) {
        attr$orch.types <- "character"
    }
    if (is.null(attr$orch.names)) {
        attr$orch.names <- paste0("val", seq_along(attr$orch.types))
    }
    if (is.null(attr$orch.origin)) {
        attr$orch.origin <- "unknown"
    }
    if (is.null(attr$orch.dim)) {
        attr$orch.dim <- c(-1, length(attr$orch.types))
    }
    if (is.null(attr$orch.pristine)) {
        attr$orch.pristine <- FALSE
    }
    if (is.null(attr$orch.quote)) {
        attr$orch.quote <- ''
    }
    if (is.null(attr$orch.trim)) {
        attr$orch.trim <- FALSE
    }
    
    # Meta data can be incorrect if it was eding manually in HDFS and we have
    # no way to prevent it. If somehow names|types have extra leading or 
    # tailing " " this can brake driver's or user's R code. E.g. if a column 
    # names is set to " val1" then code like "data$ val1" will fail to run.
    if (any(grepl("^ +[^ ]*|[^ ]* +$", attr$orch.names))) {
        orch.dlogw("orch.names has lead|tail spaces, cleaned")
        attr$orch.names <- strim(attr$orch.names)
    }
    if (any(grepl("^ +[^ ]*|[^ ]* +$", attr$orch.names))) {
        orch.dlogw("orch.types has lead|tail spaces, cleaned")
        attr$orch.types <- strim(attr$orch.types)
    }
    
    # Now validate that all attributes are set correctly and attach attributes
    # to the \p obj (if one one was given by the user). If meta attributes
    # did not pass validity check return NULL.
    valid <- !validate || .validate.meta(attr=attr, stop=stop)
    if (!valid) {
        NULL
    }
    else {
        if (is.null(obj)) {
            attr
        }
        else {
            attributes(obj) <- attr
            obj
        }
    }
}

##
#' Validation of metadata makes sure that metadata is consistent and we don't 
#' have any logical error that can cause unpredictible behavior of ORCH 
#' functions later on.
#' 
#' @param obj An object containing meta attributes (if \p attr is missing).
#' @param attr Meta attributes as a list (if \p obj is missing).
#' @param stop Abort execution if an error found in meta data.
#' @return TRUE if attributes are valid, otherwise FALSE.
#' 
#' @seealso .parse.meta
#' @seealso .paste.meta
##
.validate.meta <- function(obj, attr, stop=FALSE)
{
    if (missing(attr)) {
        attr <- attributes(obj)
    }
    required = c(
        "orch.kvs",
        "orch.keyi",
        "orch.types",
        "orch.names",
        "orch.dim")
    valid <- TRUE
    for (reqAttr in required) {
        if (is.null(attr[[reqAttr]])) {
            orch.dloge("missing \"%s\" attribute", reqAttr, stop=stop)
            valid <- FALSE
            break
        }
    }
    if (!valid) {
        FALSE
    }
    else
    if (length(attr$orch.types) != length(attr$orch.names)) {
        orch.dloge("number of types and names is not the same", stop=stop)
        FALSE
    }
    else if (length(unique(attr$orch.names)) != length(attr$orch.names)) {
        orch.dloge("names are not unique", stop=stop)
        FALSE
    }
    else if (attr$orch.keyi < -1) {
        orch.dloge("keyi has invalid values < -1", stop=stop)
        FALSE
    }
    else if (attr$orch.keyi > length(attr$orch.types)) {
        orch.dloge("keyi value is out of range > columns", stop=stop)
        FALSE
    }
    else if (nchar(attr$orch.key.sep) > 1) {
        orch.dloge("key separator can be 1 character only", stop=stop)
        FALSE
    }
    else if (nchar(attr$orch.value.sep) > 1) {
        orch.dloge("value separator can be 1 character only", stop=stop)
        FALSE
    }
    else if (attr$orch.dim[2] != length(attr$orch.types)) {
        orch.dloge("number of columns is not the same as number of types", stop=stop)
        FALSE
    }
    else if (attr$orch.key.sep != '' && 
            grepl(attr$orch.key.sep, attr$orch.quote, fixed=T)) {
        orch.dloge("key separator is used for quoting", stop=stop)
        FALSE
    }
    else if (attr$orch.value.sep != '' &&
            grepl(attr$orch.value.sep, attr$orch.quote, fixed=T)) {
        orch.dloge("value separator is used for quoting", stop=stop)
        FALSE
    }
    else {
        # all attributes are good
        TRUE
    }
}

##
#' Same as file() function but with debug logging. Suppresses all warning
#' messages too if failed. Error messages are logged only.
#'
#' @param name file name to open
#' @param open mode can be r|w|a
#' @param stop abort execution if failed
#' @return file descriptior | NULL if failed.
##
.orch.open <- function(name, open='r', stop=T, secure=F, mode=7)
{
    # Verify input file open mode and security options.
    # Stdin/stdout pipes require special handling.
    if (name == "") {
        name <- "stdin"
    }
    if (name == "stdin") {
        if (secure) {
            orch.dlogw("can't open stdin in secure mode")
            secure <- FALSE
        }
        if (!grepl("r", open)) {
            orch.dlogw("can't open stdin in \"%s\" mode", open)
            open <- "rt"
        }
    }
    if (name == "stdout") {
        if (secure) {
            orch.dlogw("can't open stdout in secure mode")
            secure <- FALSE
        }
        if (!grepl("w", open)) {
            orch.dlogw("can't open stdout in %s mode", open)
            open <- "wt"
        }
    }

    # Ready to open the file (or pipe).
    orch.dlog.trace('open file "%s", mode=%s', name, open)
    if (name == "stdout") {
        return (stdout())
    }
    if (secure && grepl('w', open)) {
        orch.dlogw('file secure access is OFF when reading')
        secure <- FALSE
    }
    
    # Prevent file "hijacking" in secure mode.
    if (secure) {
        mode <- sprintf('%d00', mode)
        if (file.exists(name)) {
            orch.dloge('file "%s" already exists, security check failed', 
                name, stop=stop)
            return(NULL)
        }
        else {
            orch.dlog.trace('chmod file "%s",%s', name, mode)
            file.create(name, showWarnings=F)
            Sys.chmod(name, mode)
        }
    }
    
    # Create new or open existing file.
    f <- suppressWarnings(try(file(name, open), silent=T))
    if (class(f)[1] == 'try-error') {
        if (.orch.env$debug) {
            err <- strsplit(f, '\n')[[1]]
            orch.dlog.debug(err)
        }
        orch.dloge('can\'t open file "%s"', 
            name, stop=stop)
        f <- NULL
    }
    else {
        # for log in .close()
        attr(f, 'filename') <- name
        attr(f, 'secure') <- secure
    
        # Post check file access permissions
        if (secure) {
            fmode <- file.info(name)['mode']
            orch.dlog.debug('file mode = %s', fmode)
            if (fmode != as.octmode(mode)) {
                orch.dloge('file "%s" permissions security check failed', 
                    name, stop=stop)
                f <- NULL
            }
            fuser <- file.info(name)['uname']
            orch.dlog.debug('file owner = %s', fuser)
            if (fuser != Sys.info()['user']) {
                orch.dloge('file "%s" user security check failed', 
                    name, stop=stop)
                f <- NULL
            }
        }
    }
    
    # connection | NULL
    # -> if "hijecking" check passed
    f
}

##
#' Same as close() function but with debug logging. Suppresses all warning
#' messages too if failed. Error messages are logged only.
#'
#' @param con connection to close
#' @param stop abort execution if failed
#' @return TRUE | FALSE if failed.
##
.orch.close <- function(con, stop=F)
{
    # Disallow closing of standard connections.
    if (con == stdout()) {
        orch.dlog.info('can\'t close stdout, ignored')
        return (TRUE)
    }
    if (con == stdin()) {
        orch.dlog.info('can\'t close stdin, ignored')
        return (TRUE)
    }
    if (con == stderr()) {
        orch.dlog.info('can\'t close stderr, ignored')
        return (TRUE)
    }
    
    # Files opened with .orch.open() contains a special attributes
    # like the original file names. This is needed for debugging only.
    name <- attr(con, 'filename')
    if (is.null(name)) {
        name <- 'unknown'
    }
    orch.dlog.trace('close file "%s"', name)
    
    # Try to close the file and process any errors.
    ok <- suppressWarnings(try(close(con), silent=T))
    if (class(ok) == 'try-error') {
        if (.orch.env$debug) {
            err <- strsplit(ok, '\n')[[1]]
            orch.dlog.debug(err)
        }
        orch.dloge('can\'t close file "%s"', 
            name, stop=stop)
        ok <- FALSE
    }
    else {
        ok <- TRUE
    }
    
    # Done.
    ok
}

##
#' Same as unlink() function but with debug logging. Suppresses all warning
#' messages if call failed. Error messages are logged only but not displayed.
#' If \p filename is a connection object then first closes the connection
#' and then unlinks the file assosiated with this connections.
#'
#' @param filename File name or connection to be unlinked.
#' @param stop Abort execution if failed.
##
.orch.unlink <- function(filename, stop=F)
{
    if (class(filename)[1] == 'file') {
        filename <- attr(con, 'filename')
        .orch.close(filename)
    }
    if (.orch.env$debug) {
        orch.dlog.trace('unlink file "%s"', filename)
    }
    if (unlink(filename) != 0) {
        orch.dloge('can\'t delete file "%s"', 
            filename, stop=stop)
		FALSE
    }
	else {
		TRUE
	}
}

##
#' Normalizes full path, e.g. removes extra '/', folds './' and '/..', etc.
#' @example .scrub.path("/aaa/.a/../c/d/.././d") -> "/aaa/c/d"
#' 
#' @param path Unix-line path(s). Can be a vector.
#' @return Cleaned and normalized path(s).
##
.scrub.path <- function(path)
{
    .assert(is.character(path))

    path <- strim(path)
    normPath <- c()
    for (path in path) {
        # Remove meaningless "//" and "/./" sub-paths.
        p <- rgsub("//", "/", path, fixed=T)
        p <- rgsub("/./", "/", p, fixed=T)
        p <- rgsub("^[.]/|/[.]$|^[.]$", "", p)
        
        # Remove "/*/../" sub-paths. Regexp is a bit convoluted due to inability
        # to specify NOT expression in a POSIX regexp therefore we have to match 
        # subdir to any non ".." string.
        cd.. <- "([^/.][^/]*|[.][^/.]*|[.][.][^/.]+)/[.][.]"
        p <- rgsub(sprintf("/%s/", cd..), "/", p)
        p <- rgsub(sprintf("^%s/", cd..), "", p)
        p <- rgsub(sprintf("/%s$", cd..), "", p)
        p <- rgsub(sprintf("^%s$", cd..), "", p)
        
        # Remove the very last "/" symbol if any.
        # Also make sure that the very first "/" is not removed.
        if (begins(path, "/")) {
            p <- sub("^(.+)/$", "\\1", p)
            if (!begins(p, '/')) {
                p <- sprintf("/%s", p)
            }
        }
        else {
            p <- sub("^(.*)/$", "\\1", p)
            if (begins(p, '/')) {
                p <- substr(p, 2, nchar(p))
            }
        }
        normPath %c=% p
    }
    
    .assert(is.character(normPath))
    normPath
}

##
#' Expands (...) arguments into local variables.
#' @example
#'     foo <- function(...) {
#'         .orch.assigndots(...)
#'         x + y
#'     }
#'     foo(x=1, y=2)
#'     # prints out 3
##
.orch.assigndots <- function(...)
{
	args <- list(...)
	names <- sapply(substitute(list(...))[-1], deparse)
	if (is.null(names(args))) {
		names(args) <- names
	}
	else {
		nnm <- (names(args)=='')
		names(args)[nnm] <- names[nnm]
	}
	for (nm in names(args)) {
		assign(nm, args[[nm]], parent.frame())
	}
}
