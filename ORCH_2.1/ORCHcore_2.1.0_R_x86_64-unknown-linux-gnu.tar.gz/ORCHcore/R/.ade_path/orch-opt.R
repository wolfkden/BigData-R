# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' Oracle R Connector for Hadoop getopt custom library.
#' @name ORCH package
#' @docType package
##

###############################
# DO NOT INCLUDE AND SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

## ------------------------------------------------------------------------- ##
##                             PUBLIC FUNCTIONS                              ##
## ------------------------------------------------------------------------- ##

##
#' Implements getopt package functionality.
#'
#' getopt is primarily intended to be used with "Rscript". It facilitates 
#' writing "#!"shebang scripts that accept short and long flags/options. It 
#' can also be used from "R" directly, but is probably less useful in this 
#' context.
#'
#' getopt() returns a list data structure containing names of the flags that 
#' were present in the character vector passed in under the opt argument. Each 
#' value of the list is coerced to the data type specifed according to the 
#' value of the spec argument. See below for details.
#'
#' @seealso getopt package documentation.
##
getopt <- function (
        spec = NULL,
        opt = commandArgs(T),
        flag = NULL,
        ncol = NULL,
        usage = F)
{
    if (is.null(flag)) {
        flag <- strsplit(commandArgs(F)[4],"=")[[1]][2]
    }

    # [spec] matrix dimensions.
    mincol <- 4
    maxcol <- 5
    
    # [spec] matrix layout:
    optLongName  <- 1
    optShortName <- 2
    optHasArg    <- 3
    optMode      <- 4
    optDescr     <- 5
    optXXX       <- 6

    # [optHasArg] values:
    modeNoArg       <- 0
    modeRequireArg  <- 1
    modeOptionalArg <- 2

    # Check input parameters
    if (missing(spec)) {
        orch.dlog.stop('[spec] is missing')
    }

    # Convert [spec] to a matrix.
    if (!is.matrix(spec)) {
        if (is.null(ncol)) {
            orch.dlog.stop('[ncol] is missing, can\'t use [spec]')
        }
        spec = matrix(spec, ncol=ncol, byrow=TRUE)
    }

    # Check [spec] dimensions.
    if (dim(spec)[2] < mincol) {
        orch.dlog.stop("[spec] must have at least %d columns", mincol)
    }
    if (dim(spec)[2] > maxcol ) {
        orch.dlog.stop("[spec] must have less than %d columns", maxcol+1)
    }
    nrow <- dim(spec)[1]
    ncol <- dim(spec)[2]

    # Check all option names are unique.
    specLongNames <- spec[,optLongName]
    if (length(unique(specLongNames)) != length(specLongNames)) {
        orch.dlog.stop("non-unique long names found")
    }
    specShortNames <- na.omit(spec[,optShortName])
    if (length(unique(specShortNames)) != length(specShortNames)) {
        orch.dlog.stop("non-unique short names found")
    }

    # Check data type of "HasArg" column.
    checkArg <- suppressWarnings(as.numeric(spec[,optHasArg]))
    if (any(is.na(checkArg))) {
        orch.dlog.stop("[spec] column %d must be numeric", optHasArg)
    }
    
    # If [usage] is TRUE, just print out a help text.
    if (usage) {
        ret <- paste("Usage: ", flag, sep='')
        for (i in 1:(dim(spec))[1]) {
            if (is.na(spec[i, optShortName])) {
                ret <- paste(ret, 
                    ' [--', spec[i, optLongName],
                    sep='')
            }
            else {
                ret <- paste(ret, 
                    ' [-[-', spec[i, optLongName], 
                    '|', spec[i, optShortName], ']',
                    sep='')
            }
            if (spec[i, optHasArg] == modeNoArg) {
                ret <- paste(ret, ']', sep='')
            }
            else if (spec[i, optHasArg] == modeRequireArg) {
                ret <- paste(ret, 
                    ' <', spec[i, optMode], '>]', 
                    sep='')
            }
            else if (spec[i, optHasArg] == modeOptionalArg) {
                ret <- paste(ret,
                    ' [<', spec[i, optMode], '>]]',
                    sep='')
            }
        }
        
        # include usage strings
        ret <- paste(ret, '\n', sep='')
        if (ncol >= 5) {
            maxLongName <- max(sapply(spec[,optLongName], nchar))
            fmtLongName <- paste("\t-%s|--%-",maxLongName,"s\t%s\n", sep='')
            for (i in 1:nrow) {
                ret <- paste(ret, 
                    sprintf(fmtLongName,
                        spec[i,optShortName],
                        spec[i,optLongName],
                        spec[i,optDescr]
                    ),
                    sep='')
            }
        }

        # stop processing options
        return(ret)
    }

    # Result of this function:
    ret <- list()
    ret$ARGS <- vector(mode="character")

    i <- 1
    while (i <= length(opt)) {
        optStr <- opt[i]
        orch.dlog.debug("option #%d: \"%s\"", i, optStr)

        # option with missing argument:
        pending <- 0

        # Try to search long options first.
        if (substr(optStr, 1, 2) == '--') {
            orch.dlog.debug("long flag detected")
            optStr <- substring(optStr,3)
            if (optStr == '') {
                orch.dlog.stop("empty long flag --")
            }

            # extract flag and value from the command line
            fv = strsplit(optStr, '=')[[1]]
            if (is.na(fv[2])) {
                flag <- optStr
                val <- NA
            }
            else {
                flag <- fv[1]
                val <- paste(fv[-1], collapse="=")
            }


            # match option flag with long names from the spec
            match <- grep(flag, spec[,optLongName], fixed=T)
            if (length(match) == 0) {
                orch.dlog.stop("long flag \"%s\" is invalid", flag)
            }
            if (length(match) > 1) {
                orch.dlog.stop("long flag \"%s\" is ambiguous", flag)
            }
            mspec <- spec[match,]
            mname <- mspec[optLongName]
            orch.dlog.debug("matched to #%d: \"%s\"", match, mname)

            # assign value to the option flag
            if (is.na(val)) {
                ret[mname] <- TRUE
                pending <- match
                orch.dlog.debug("pending=%d, %s=T", match, mname)
            }
            else {
                if (mspec[optHasArg] == modeNoArg) {
                    orch.dlog.stop("long flag \"%s\" accepts no arguments", flag)
                }
                x <- .as.any(val, mspec[optMode])
                if (is.na(x)) {
                    orch.dlog.stop("argument \"%s\" must be %s", val, mspec[optMode])
                }
                ret[mname] <- x
                i <- i + 1
                orch.dlog.debug("set %s=%s", mname, x)
                next
            }
        }

        # Next try to search short options.
        else if (substr(optStr, 1, 1) == '-') {
            orch.dlog.debug("short flag detected")
            flags <- strsplit(optStr, '')[[1]] # "-ab" -> c("a","b")
            if (length(flags) == 1) {
                orch.dlog.stop("empty short flag -")
            }
            
            done <- FALSE
            for (j in 2:length(flags)) {
                flag <- flags[j]

                # match option flag with long names from the spec
                match <- grep(flag, spec[,optShortName], fixed=T)
                if (length(match) == 0) {
                    orch.dlog.stop("short flag \"%s\" is invalid", flag)
                }
                if (length(match) > 1) {
                    orch.dlog.stop("short flag \"%s\" is ambiguous", flag)
                }
                mspec <- spec[match,]
                mname <- mspec[optLongName]
                orch.dlog.debug("matched to #%d: \"%s\"", match, mname)

                # check/assign default values
                if (j < length(flags) & mspec[optHasArg] == modeRequireArg) {
                    orch.dlog.stop("flag \"%s\" requires argument and not tailing", flag)
                }
                else if (mspec[optHasArg] == modeNoArg) {
                    ret[mname] <- TRUE
                    done <- TRUE
                    orch.dlog.debug("set %s=T", mname)
                }
                else {
                    ret[mname] <- TRUE
                    pending <- match
                    done <- FALSE
                    orch.dlog.debug("pending=%d(%s)", match, mname)
                }
            }
            if (done) {
                i <- i + 1
                next
            }
        }

        # Found an unknown option.
        if (pending == 0) {
            orch.dlog.stop("\"%s\" is not a valid option", optStr)
        }

        # Found an argument.
        if (pending > 0) {
            orch.dlog.debug("argument?")

            pspec <- spec[pending,]
            pmode <- pspec[optMode]
            pname <- pspec[optLongName]
            pharg <- pspec[optHasArg]

            if (length(opt) > i) {
                nextOptStr <- opt[i + 1]
                orch.dlog.debug("next option: \"%s\"", nextOptStr)

                # Found an argument! Attach it to the pending option, increment 
                # the index, and move on to the next option. Don't accept arguments 
                # starting with '-' unless option mode in [spec] is numeric in 
                # which case allow the leading '-' plus verify that this is a
                # numeric value.
    
                # Try to use the value for the pending options.
                ok <- FALSE
                if (pmode == "logical") {
                    if (nextOptStr %in% c('0','F','FALSE')) {
                        ret[pname] <- FALSE
                        ok <- TRUE
                    }
                    else if (nextOptStr %in% c('1','T','TRUE')) {
                        ret[pname] <- TRUE
                        ok <- TRUE
                    }
                }
                else if (pmode == "character" && (
                        nextOptStr == '-' || 
                        substr(nextOptStr,1,1) != '-')) {
                    ret[pname] <- nextOptStr
                    ok <- TRUE
                }
                else if (pmode %in% c("numeric","double","integer")) {
                    x <- .as.any(nextOptStr, pmode)
                    if (!is.na(x)) {
                        ret[pname] <- x
                        ok <- TRUE
                    }
                }
                
                # Verify that option was assigned the argumnet.
                if (!ok) {
                    if (pharg == modeRequireArg) {
                        orch.dlog.stop("flag \"%s\" requires an argument", flag)
                    }
                    if (pharg == modeOptionalArg ||
                            pharg == modeNoArg) {
                        x <- TRUE
                        x <- .as.any(x, pmode)
                        ret[pname] <- x
                        orch.dlog.debug("set %s=%s", pname, x)
                    }
                    else {
                        orch.dlog.stop("internal error")
                    }
                }
                else {
                    orch.dlog.debug("set %s=%s", pname, ret[pname])
                    i <- i + 1
                }
            }

            # Last option without required argument.
            else if (pharg == modeRequireArg) {
                orch.dlog.stop("flag \"%s\" requires an argument", flag)
            }

            # Last option without optional argument.
            else if (pharg == modeOptionalArg ||
                    pharg == modeNoArg) {
                x <- TRUE
                x <- .as.any(x, pmode)
                ret[pname] <- x
                orch.dlog.debug("set %s=%s", pname, x)
            }
        }
        else {
            orch.dlog.stop("internal error")
        }

        i = i + 1
    }
        
    # All done!
    ret
}

## ------------------------------------------------------------------------- ##
##                             PRIVATE FUNCTIONS                             ##
## ------------------------------------------------------------------------- ##

##
#' Converts a value to any type and suppresses warnings.
#' @return NA is the value can't be converted.
##
.as.any <- function(x, mode)
{
    if (mode == 'logical') {
        if (x %in% c('1','T','TRUE')) {
            x <- TRUE
        }
        else if (x %in% c('0','F','FALSE')) {
            x <- FALSE
        }
        else {
            x <- NA
        }
    }
    else {
        suppressWarnings(
            storage.mode(x) <- mode
        )
    }
    x
}

## ------------------------------------------------------------------------- ##
##                              TEST FUNCTIONS                               ##
## ------------------------------------------------------------------------- ##

##
#' Unit test for getopt() custom impelemtation.
##
.getopt.test <- function()
{
    require(RUnit)
    spec <- c(
        "aa", "a", 0, "logical", "test option 1", 
        "bb", "b", 1, "character", "test option 2",
        "cc", "c", 2, "integer", "test option 3",
        "dd", "d", 2, "logical", "test option 4") 
        
    x <- try(getopt(spec, c('-abc'), ncol=5))
    checkTrue(orch.dbg.lasterr() == "flag \"b\" requires argument and not tailing")
    x <- try(getopt(spec, c('-abc', 'x'), ncol=5))
    checkTrue(orch.dbg.lasterr() == "flag \"b\" requires argument and not tailing")
    x <- try(getopt(spec, c('-acb', 'x'), ncol=5))
    checkTrue(x$aa == T && x$bb == 'x' && x$cc == T)
    x <- try(getopt(spec, c('-acb', '-x'), ncol=5))
    checkTrue(orch.dbg.lasterr() == "flag \"b\" requires an argument")
    x <- try(getopt(spec, c('-acb', '-'), ncol=5))
    checkTrue(x$aa == T && x$bb == '-' && x$cc == T)
    x <- try(getopt(spec, c('-ac', '-1'), ncol=5))
    checkTrue(x$aa == T && x$cc == -1)
    x <- try(getopt(spec, c('-ac', '-'), ncol=5))
    checkTrue(orch.dbg.lasterr() == "empty short flag -")
    x <- try(getopt(spec, c('--cc=a'), ncol=5))
    checkTrue(orch.dbg.lasterr() == "argument \"a\" must be integer")
    x <- try(getopt(spec, c('--dd=T', "--aa", "--bb=x", '--cc=1'), ncol=5))
    checkTrue(x$aa == T && x$bb == 'x' && x$cc == 1 && x$dd == T)
    x <- try(getopt(spec, c('--dd=TRUE', "--bb=\"x\"", '--cc=-1'), ncol=5))
    checkTrue(x$bb == '"x"' && x$cc == -1 && x$dd == T)
    x <- try(getopt(spec, c('--dd=1', "--bb='x'", '--cc=.1'), ncol=5))
    checkTrue(x$bb == "'x'" && x$cc == 0 && x$dd == T)
    
    spec <- c("input", "i", 0, "character", "input file")
    x <- try(getopt(spec, flag='test', ncol=5, usage=T))
    checkTrue(x == "Usage: test [-[-input|i]]\n\t-i|--input\tinput file\n")
    
    cat("getopt() is fine\n")
    TRUE
}
