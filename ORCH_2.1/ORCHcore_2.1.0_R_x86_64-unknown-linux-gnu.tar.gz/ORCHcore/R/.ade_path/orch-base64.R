# Copyright (c) 2012, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' @name Oracle R Connector for Hadoop
#' @docType package
#' 
#' The Base64 encoding is designed to encode arbitrary binary information for 
#' transmission by electronic mail. It is defined by MIME (Multipurpose Internet 
#' Mail Extensions) specification RFC 1341, RFC 1421, RFC 2045 and others. 
#' Triplets of 8-bit octets are encoded as groups of four characters, each 
#' representing 6 bits of the source 24 bits. Only a 65-character subset 
#' ([A-Z,a-z,0-9,+,/,=]) present in all variants of ASCII and EBCDIC is used, 
#' enabling 6 bits to be represented per printable character
##

if (!exists('.orch.env')) {
    orch.dlog.stop("wrong loading order")
}

###############################
# DO NOT INCLUDE AND SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

##
#' Initializes and configures base64 encodoing/decoding module. Tries to find
#' and load native base64 encoding C library and if can't configures to use
#' slow R implementation.
#' 
#' @param lib.path Where to look for the library (optional).
#' @param cat Print user info message to stdout.
#' @return None.
##
.base64.init <- function(lib.path, cat=FALSE)
{
    # Try to load the shared library first. It is located in "<package>/libs/<arch>"
    # folder normally. Note that on platforms with single architecture (Linux x64) 
    # it will be located in "<package>/libs". 
    if (missing(lib.path)) {
        if (.orch.env$pkg) {
            pkgPath <- system.file(package="ORCHcore")
            lib.path <- path(pkgPath, "libs", .Platform$r_arch) 
        }
        else {
            pkgPath <- "./"
            lib.path <- "./"
        }
    }
    lib <- path(lib.path, paste0("ORCHcore", .Platform$dynlib.ext))
    dynlib <- try(dyn.load(lib), silent=T)
    if (class(dynlib) == "try-error") {
        .orch.env$base64.native <- F
        orch.dlogw("%s library was not found at \"%s\"", 
            basename(lib), dirname(lib))
    }
    else {
        .orch.env$base64.native <- T
        orch.dlog.info("found \"%s\"", dynlib["path"])
    }
    
    # Validate loaded symbols, all base64 functions must be in place.
    if (.orch.env$base64.native) {
        symbols <- c(
            "base64_encode", 
            "base64_decode")
        loaded <- sapply(symbols, is.loaded)
        if (any(!loaded)) {
            .orch.env$base64.native <- F
            missSym <- symbols[!loaded]
            orch.dloge("%s library doesn't contain base64 encoding function%s:", 
                basename(lib), .s(obj=missSym), toString(missSym))
        }
    }
    if (.orch.env$base64.native) {
        orch.dlog.info("using native C base64 encoding implementation", 
            cat=cat)
    } else {
        orch.dlog.warning("using pure R base64 encoding implementation", 
            cat=cat)
    }
}

## ------------------------------------------------------------------------- ##
##                             STATIC VARIABLES                              ##
## ------------------------------------------------------------------------- ##

## 6-bit value to character mapping.
## We want to pre-cache for better base64 encoding.
##   [0  - 25]  ->  A-Z
##   [26 - 51]  ->  a-z
##   [52 - 61]  ->  0-9
##   [62 - 64]  ->  +,/,=
.orch.base64map <- strsplit(paste0(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ", # 0-25
    "abcdefghijklmnopqrstuvwxyz", # 26-51
    "0123456789+/="),             # 52-64
    '')[[1]]

## ------------------------------------------------------------------------- ##
##                             PRIVATE FUNCTIONS                             ##
## ------------------------------------------------------------------------- ##

##
#' Pure R base64 encoding implementation. Very slow.
#' @param x R's raw object to encode.
#' @return Base64 compliant String.
##
.base64_encode <- function(x)
{
    .assert(is.raw(x))
    x <- as.integer(x)
    size <- length(x)
    
    # Data input and output size.
    blocks <- ceiling(size/3)
    bytes <- 4 * blocks
    padSize <- 3 * blocks - size
    
    # Convert into matrix with each column = 1 encode block.
    block3 <- 3 * blocks
    if (size < block3) {
        # pad raw input data with 0s if size is not 3x
        x[(size+1):block3] <- 0L
    }    
    dim(x) <- c(3L, blocks)
    
    # Split up every 3 bytes into 4 pieces like this:
    #   from: aaaaaabb bbbbcccc ccdddddd
    #   to  : 00aaaaaa 00bbbbbb 00cccccc 00dddddd
    # This section is based on Matlab code by Peter Acklam
    # http://home.online.no/~pjacklam/matlab/software/util/datautil/
    y <- matrix(0L, nrow=4L, ncol=blocks)
    y[1,] <- x[1,] %>>% 2
    y[2,] <- (x[1,] %<<% 4) %or% (x[2,] %>>% 4)
    y[3,] <- (x[2,] %<<% 2) %or% (x[3,] %>>% 6)
    y[4,] <- x[3,]
    y <- y %and% 63
    
    # Map integers to base64 symbols and pad if needed.
    z <- .orch.base64map[y+1] 
    if (padSize > 0) {
        # pad with '='
        z[(bytes-padSize+1):bytes] <- '='
    }
    paste(z, collapse='')
}

##
#' Pure R base64 decoding implementation. Very slow.
#' @param x Base64 compliant string.
#' @return Decoded R's raw object.
##
.base64_decode <- function(x)
{
    # Convert character into int numbers.
    x <- strsplit(x, NULL)[[1]]
    size <- length(x)
    if (size %% 4 != 0) { 
        orch.dlogw("length of base64 data is not multiple of 4")
    }
    x <- match(x, .orch.base64map, nomatch=-1) - 1 
    if (any(x < 0)) {
        orch.dlog.stop("input string is not in Base64 format")
        return (NULL)
    }
    
    # Remove "=" padding.
    last <- size
    while (x[last] == 64) {
        last <- last - 1
    }
    if (size - last > 3) {
        orch.dlog.stop("base64 padding is too long")
        return (NULL)
    }
    length(x) <- last
    if (any(x == 64)) {
        orch.dlog.stop("base64 padding is corrupted")
        return (NULL)
    }
    
    blocks <- ceiling(last / 4) # number of blocks/groups
    bytes <- 3 * blocks # number of decoded bytes
    tailSize <- last %% 4
    
    # Convert input data into a matrix.
    size <- 4*blocks
    if (last < size) {
        x[(last+1):size] <- 0
    }
    dim(x) <- c(4, blocks);
    
    # Collapse 4 bytes into 3 bytes like this:
    #    from: 00aaaaaa 00bbbbbb 00cccccc 00dddddd
    #    to  : aaaaaabb bbbbcccc ccdddddd
    # This section is based on Matlab code by Peter Acklam
    # http://home.online.no/~pjacklam/matlab/software/util/datautil
    y <- matrix(as.integer(0), nrow=3L, ncol=blocks)
    y[1,] <- (x[1,] %<<% 2) %or% (x[2,] %>>% 4)
    y[2,] <- (x[2,] %<<% 4) %or% (x[3,] %>>% 2)
    y[3,] <- (x[3,] %<<% 6) %or% x[4,]
    y <- (y %and% 255)
    
    # Remove padding if needed and we are done.
    if (tailSize > 1) {
        y <- y[1:(bytes+tailSize-4)]
    }
    as.raw(y)
}

##
#' "what" parameter convertion table.
#' @slot name Allowed type names and shortcuts.
#' @slot alias Corresponding R type names.
#' @slot size Expected size of the corresponding data type.
##
.base64.types <- data.frame(
    name = c(
        "logical", "l", 
        "integer", "i",
        "double", "d",
        "complex", "x",
        "character", "c",
        "raw", "r",
        "numeric", "n", 
        "int", "i",
        "float", "f"),
    alias = c(
        rep("logical", 2), 
        rep("integer", 2), 
        rep("double", 2), 
        rep("complex", 2), 
        rep("character", 2), 
        rep("raw", 2), 
        rep("numeric", 2), 
        rep("integer", 2),
        rep("double", 2)),
    size = c(
        4, 4,
        4, 4,
        8, 8,
        16, 16,
        1, 1,
        1, 1,
        8, 8,
        4, 4,
        8, 8)
)

##
#' Normalizes and converts "what" parameter on orch.decode() function in
#' a vector of type names. Allows to use a mix of typed values and type names
#' in "what" specification.
#' 
#' @param what Type specification as vector or list.
#' @param x Input data to which "what" will be applied.
#' @return Normalized "what" specification.
##
.base64.what.param <- function(what, x)
{
    ret <- unlist(what)
    if (length(what) > length(x)) {
        orch.dlog.stop("[what] is too long")
    }
    what <- .rep_length(x, what)[[2]]
    for (i in seq_along(what))
    {
        if (is.character(what[[i]])) {
            if (!(what[[i]] %in% .base64.types$name)) {
                # "random" string given as a template
                ret[i] <- "character"
            }
            else {
                j <- match(what[[i]],.base64.types$name)
                ret[i] <- toString(.base64.types$alias[j])
            }
        }
        else {
            # "random" non-string values is given as a template
            ret[i] <- typeof(what[[i]])
        }
    }
    ret
}

## ------------------------------------------------------------------------- ##
##                             PUBLIC FUNCTIONS                              ##
## ------------------------------------------------------------------------- ##

##
#' Encodes an R object in Base64 character format for text serialization. Does
#' not work for complex data types like data.frame or list, only scalar values
#' can be encoded or vectors of scalar.
#' 
#' @param x object to be encoded.
#' @param size The number of bytes per element in the byte stream. The default, 
#'     'NA_integer_', uses the natural size. Size changing is not supported 
#'     for raw and complex vectors.
#' @param endian The endian-ness ('"big"' or '"little"') of the target system
#' 	   for the file.  Using '"swap"' will force swapping endian-ness.
#' 
#' @seealso base64.decode
#' @seealso base64.compress
#' @seealso writeBin
##
base64.encode <- function(
        x, 
        size = NA_integer_, 
        endian = .Platform$endian)
{
    # Prepare input data.
    if (typeof(x) != "raw") {
        x <- writeBin(x, 
            raw(), 
            size = size, 
            endian = endian)
    }
    if (.orch.env$base64.native) {
        .Call("base64_encode", x)
    } else {
        .base64_encode(x)
    }
}

##
#' Decodes previously encoded R object and return its original value. Note that
#' base64 encoded value contains no information about its original data type
#' and this information must be provided via the function parameters.
#' 
#' @param x Bas64 encoded object as string.
#' @param what Original (or expected) data type or a "template" object. You can 
#'     specify or a name of the target type (one of "numeric", "double", 
#'     "integer", "int", "logical", "complex", "character", "raw") or just 
#'     a sample object value of the target type like 0L.
#' @param size The number of bytes per element in the byte stream. The default, 
#'     'NA_integer_', uses the natural size. Size changing is not supported for 
#'     raw and complex vectors.
#' @param signed Only used for integers of sizes 1 and 2, when it determines 
#'     if the quantity on file should be regarded as a signed or unsigned integer.
#' @param endian The endian-ness ("big" or "little") of the target system
#' 	   for the file.  Using "swap" will force swapping endian-ness.
#' 
#' @seealso base64.encode
#' @seealso base64.decompress
#' @seealso readBin
##
base64.decode <- function(
        x,
        what, 
        size = NA_integer_, 
        signed = TRUE, 
        endian = .Platform$endian)
{
    # Initialize final conversion from 'raw' to type given by 'what'.
    # 'what' can be specified by a "template" value or by type's name.
    .assert(is.character(x))
    what <- .base64.what.param(what, x)
    
    # Decode each string separately.
    ret <- if(length(x) > 1) list() else c()
    for (i in seq_along(x))
    {
        # Decode base64 string.
        if (.orch.env$base64.native) {
            raw <- .Call("base64_decode", x[i])
        } else {
            raw <- .base64_decode(x[i])
        }
            
        # Perform final conversion from 'raw' to type given by 'what'.
        if (what[i] == "raw") {
            ret <- c(ret, raw)
        }
        else {
            if (is.na(size)) {
                j <- match(what[i], .base64.types$name)
                size <- .base64.types$size[j]
            }
            n <- length(raw)
            if (n %% size) {
                orch.dlog.stop("number of elements in raw data is not multiple of size")
                return (NULL)
            }
            y <- readBin(raw, 
                what = what[i], 
                n = n%/%size, 
                size = size, 
                signed = signed, 
                endian = endian)
            if (what[i] == "character") {
                # convert arrays of characters to strings
                y <- paste(y, collapse = '')
            }
            ret <- c(ret, y)
        }
    }
    
    # All done.
    orch.dlog.debug("base64 decoded from %s to %s",
        mem2str(obj=x), mem2str(obj=ret))
    ret
}

##
#' Encodes and optionally compresses an R object in Base64 character format for 
#' text serialization. Does not work for complex data types like data.frame or 
#' list, only scalar values can be encoded or vectors of scalar. Compression
#' can lower the resulting encoded string size several times.
#' 
#' @note The resulting encoded and compressed object is not base64 complient
#'     because compression information gets stored within the encoded object 
#'     itself and uses non-base64 symbols for it.
#' 
#' @param x object to be encoded.
#' @param size The number of bytes per element in the byte stream. The default, 
#'     'NA_integer_', uses the natural size. Size changing is not supported 
#'     for raw and complex vectors.
#' @param endian The endian-ness ('"big"' or '"little"') of the target system
#' 	   for the file.  Using '"swap"' will force swapping endian-ness.
#' @param compress Allows compression of the input data before base64 encoding
#'     to lower its size. 3 values are accepted: 
#'     * -1 (default) - let function decide, objects >1KB will be compressed; 
#'     * >=0 - compress if size of the object > this values;
#'     * TRUE - enforce compression always;
#'     * FALSE - disable compression.
#' @param smart Compare and choose compressed vs uncompressed encoding. This
#'     guarantees that the result will have the smallest size possible but
#'     increases encoding time *twice*. Compressed size is driven by the input
#'     data content and it's not possible to make deterministic choice to
#'     compress or not based only on the input size.
#' 
#' @seealso base64.decompress
#' @seealso base64.encode
#' @seealso writeBin
##
base64.compress <- function(
        x, 
        size = NA_integer_, 
        endian = .Platform$endian,
        compress = -1,
        smart = FALSE)
{
    # Turn on/off default compression. User has a choise to override compression 
    # threshold right in the parameters of base64.compress function by specifying 
    # it as "compress" argument numeric value.
    forceCompress <- is.logical(compress) && compress
    if (is.numeric(compress) || forceCompress) {
        len <- -1 # !attention! len is used later in the code
        if (is.character(x)) {
            len <- sum(nchar(x))
        }
        else if (is.raw(x)) {
            len <- length(x)
        }
        if (len < 0) {
            orch.dlogw("can't compress %s, disabled", class(x))
            compress <- FALSE
        }
        else if (!forceCompress)
        {
            if (compress >= 0) {
                # user have specified compression threshold as "compress" argument 
                # numeric value and we use it instead of the default 1K value.
                orch.dlog.debug("compression threshold is set to %s", mem2str(compress))
                compress <- len > compress
            }
            else {
                # Default 1K threshold was choosen based on heuristical analysis 
                # of compression + base64 encoding sizes. It looks like compression
                # gives you lower base64 encoded string length at around 300-400 
                # chars input string of normally distribution 50 symbols. Try out
                # .orch.analysis().
                compress <- len > .orch.env$base64.compress.threshold
            }
        }
    }
    .assert(is.logical(compress))
    
    # Compress if required.
    if (compress) {
        if (!(class(x) %in% c("character", "raw"))) {
            orch.dloge("compression of type \"%s\" is not supported", 
                class(x), stop=T, cat=T)
        }
        else {
            # Default 10K threshold was choosen based on heuristical analysis of 
            # gzip vs bzip2 R built-in compression of a raw vector containing 
            # normally distributed integers in range [0-49]. It looks like gzip 
            # is better at on inputs below 10K and then bzip2 takes over input. 
            # Try out .orch.analysis(type="gzip-vs-bzip2").
            if (len < .orch.env$base64.bzip2.threshold) {
                codec <- "gzip"
            } else {
                codec <- "bzip2"
            }
            code <- switch(codec,
                bzip2 = '$',
                gzip = '%',
                xz = '&')
            .assert(!is.null(code))
            x_ <- x
            x <- memCompress(x_, type=codec)
            orch.dlog.debug("compressed with %s from %s to %s", codec,
                mem2str(obj=x_), mem2str(obj=x))
        }
    }
    
    # And base64 encode ontop the dataset
    enc <- base64.encode(
        x = x,
        size = size,
        endian = endian)
    if (compress) {
        # "$%&" is not part of base64 charset, this character indicates
        # compressed and then base64 encoded string plus includes information
        # about type of codec used.
        enc <- sprintf("%s%s", code, enc)
    }
    
    # This part actually desides to use the compressed data or uncompressed
    # if somehow magically compression just makes things worse (happens).
    if (smart && compress) {
        enc_ <- base64.encode(
            x = x_,
            size = size,
            endian = endian)
        if (nchar(enc_) <= nchar(enc)) {
            orch.dlog.debug("choosing direct encoding, %d <= %d(%s)", 
                nchar(enc_), nchar(enc), code)
            enc <- enc_
        }
        else {
            orch.dlog.debug("choosing compressed encoding, %d > %d(%s)", 
                nchar(enc_), nchar(enc), code)
        }
    }
    
    # All done.
    orch.dlog.debug("base64 encoded from %s to %s",
        mem2str(obj=x), mem2str(obj=enc))
    enc
}

##
#' Decodes and decompresses a previously encoded R object and return its 
#' original value. Note that base64 encoded value contains no information about 
#' its original data type and this information must be provided via the function 
#' parameters. Compression information is stored within the encoded object
#' itself and you don't need to specify it in parameters.
#' 
#' @param z Bas64 encoded (optionally compressed) object as string.
#' @param what Original (or expected) data type or a "template" object. You can 
#'     specify or a name of the target type (one of "numeric", "double", 
#'     "integer", "int", "logical", "complex", "character", "raw") or just 
#'     a sample object value of the target type like 0L.
#' @param size The number of bytes per element in the byte stream. The default, 
#'     'NA_integer_', uses the natural size. Size changing is not supported for 
#'     raw and complex vectors.
#' @param signed Only used for integers of sizes 1 and 2, when it determines 
#'     if the quantity on file should be regarded as a signed or unsigned integer.
#' @param endian The endian-ness ("big" or "little") of the target system
#' 	   for the file.  Using "swap" will force swapping endian-ness.
#' 
#' @seealso base64.encode
#' @seealso base64.decompress
#' @seealso readBin
##
base64.decompress <- function(
        x,
        what, 
        size = NA_integer_, 
        signed = TRUE, 
        endian = .Platform$endian)
{
    # Prepare final conversion from 'raw' to type given by 'what'.
    # 'what' can be specified by a "template" value or by type's name.
    .assert(is.character(x))
    what <- .base64.what.param(what, x)
    
    # Now for the return value we will use a list if input value is a vector
    # or a list. If input is only once value then result should be just one
    # value too.
    ret <- if(length(x) > 1) list() else c()
    for (i in seq_along(x))
    {
        x1 <- x[[i]]
        code <- substr(x1, 1, 1)
        if (code %in% c('$','%','&')) {
            x1 <- substring(x1, 2, nchar(x1))
            if (code == '$') {
                codec <- "bzip2"
            }
            else if (code == '%') {
                codec <- "gzip"
            }
            else if (code == '%') {
                codec <- "xz"
            }
            y <- base64.decode(x1, "raw")
            z <- memDecompress(y, type=codec)
            if (what[i] == "character") {
                z <- rawToChar(z)
            }
            else if (what[i] != "raw") {
                orch.dlog.stop("compressed %s not supported", what)
            }
            orch.dlog.debug("decompressed with %s from %s to %s", codec, 
                mem2str(obj=y), mem2str(obj=z))
        }
        else {
            z <- base64.decode(x1, 
                what = what[i],
                size = size,
                signed = signed,
                endian = endian)
        }
        ret <- c(ret, z)
    }
    ret
}

## ------------------------------------------------------------------------- ##
##                            INTERNAL UNIT TESTS                            ##
## ------------------------------------------------------------------------- ##

.orch.test.base64 <- function()
{
    ret <- T
    input <- list(123L, 1.23, T, F, "abc", as.raw(c(1,2,3)))
    for (x in input) {
        y <- base64.encode(x)
        z <- base64.decode(y, x)
        if (any(x != z)) {
            orch.dloge("base64 encoding of %s failed", x)
            ret <- F
        }
    }
    input <- list("abc", as.raw(c(1,2,3)))
    for (x in input) {
        y <- base64.compress(x, compress=T)
        z <- base64.decompress(y, x)
        if (any(x != z)) {
            orch.dloge("base64 compression of %s failed", x)
            ret <- F
        }
    }
    ret
}

##
#' Analyses compressed vs uncompressed base64 encoding performance. Prints out
#' GLM fit models for uncompressed and compressed encoding, plots compression
#' analysis graphs.
#' 
#' @param size Maximum input data size.
#' @param step Measurement stepping.
#' @param dictionary Length of sampling dictionary or set of strings to use
#'     in "sample" function to generate input data. The larger its size
#'     the lower compression level will be.
#' @return data.frame with measurements.
## 
.base64.analysis <- function(size = 1*KB, step=10, dict.len=50, from=1, type = "")
{
    if (type == "base64-compression" || type == "") {
        xFn <- function(x) nchar(base64.compress(as.raw(x), compress=F))
        zFn <- function(x) nchar(base64.compress(as.raw(x), compress=T))
        xName <- "uncompressed"
        zName <- "compressed"
    }
    else if (type == "gzip-vs-bzip2") {
        xFn <- function(x) length(memCompress(as.raw(x), type="gzip"))
        zFn <- function(x) length(memCompress(as.raw(x), type="bzip2"))
        xName <- "gzip"
        zName <- "bzip2"
    }
    else {
        orch.dlog.stop("unknown type")
    }
    
    # Create a dictionaly for sampling of input data.
    if (dict.len > 256) {
        orch.dlog.stop("max dictionary size is 256")
    }
    dict <- seq_len(dict.len) - 1
    orch.dcat("dictionary size=%d", dict.len)
    
    # Collect compression statistics.
    input <- c()
    res <- data.frame(size=0., x=.0, z=.0)
    midPt <- NULL
    midPtFound <- FALSE
    for (i in from:(from+(size/step))*step) {
        for (j in 1:step) {
            input <- c(input, sample(dict, 1))
        }
        x <- xFn(input)
        z <- zFn(input)
        res <- rbind(res, c(i, z, x))
        if (z < x) {
            if (!midPtFound) {
                midPtFound <- TRUE
                midPt <- c(midPt, i)
            }
        }
        else if (midPtFound) {
            midPtFound <- FALSE
        }
    }
    if (!is.null(midPt)) {
        orch.dcat("mid-point=%d-%d", midPt[1], midPt[length(midPt)])
        orch.dcat("mean=%g", mean(midPt))
    }
    else {
        orch.dcat("mid-point not found")
    }
    
    # Run GLM analysis
    xFit <- lm(x~size, res)
    zFit <- lm(z~size, res)
    diff <- coef(xFit) - coef(zFit)
    print(xFit)
    print(zFit)
    
    # Plot analysis graphs.
    plot(x = c(0, res$size),
        y = c(diff[1], res$z), 
        type = 'l', 
        col = 'red', 
        xlab = "input size", 
        ylab = sprintf("%s (red), %s (green)", zName, xName))
    abline(0, 0) 
    points(x = res$size, 
        y = res$x, 
        type = 'l', 
        col = 'green')
    abline(coef(zFit), 
        lty = 2,
        col = 'blue')
    abline(coef(xFit), 
        lty = 2,
        col = 'blue')
    abline(diff, 
        lty = 1,
        col = 'purple')
    
    # Return collected data for further analysis.
    invisible(res)
}
