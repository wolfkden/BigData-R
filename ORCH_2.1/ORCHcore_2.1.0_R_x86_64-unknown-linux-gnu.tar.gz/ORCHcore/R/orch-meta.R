# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' Oracle R Connector for Hadoop metadata support.
#' @name ORCH package
#' @docType package
#' @note Experimental!
##

###############################
# DO NOT INCLUDE ANY SOURCES! #
###############################

##
#' This function allows to use complex types in values and create nested
#' data types in keyval structure returned by mapper or reducer.
##
.orch.val.encode <- function(
        x,
        compress = -1, 
        smart = FALSE)
{
    code <- ''
    vt <- class(x)
    if (length(x) != 1) {
        # Any vector w/ 2+ elements must be encoded. Theoretically we can
        # don't do it if we are not using ',' record values delims though.
        str <- deparse(x)
        enc <- base64.compress(
            x = str, 
            compress = compress, 
            smart = smart)
        code <- paste0(code, '%')
    }
    else {
        # This is only one element. Encoding depends on the data type.
        if (is.character(x)) {
            # text must be encoded, we don't know which symbols are used in it
            enc <- base64.compress(
                    x = x, 
                    compress = compress, 
                    smart = smart)
            code <- paste0(code, 'c')
        }
        else {
            if (is.data.frame(x) || 
                    is.matrix(x) || 
                    is.list(x)) {
                # Structures must be encoded. Again theoretically we can
                # don't do it if we are not using ',' record values delims.
                str <- deparse(x)
                enc <- base64.compress(
                        x = str, 
                        compress = compress, 
                        smart = smart)
                code <- paste0(code, '%')
            }
            else if (is.null(x)) {
                # NULL value can't be base64 encoded
                code <- '-'
                enc <- ''
            }
            else if (is.logical(x)) {
                # Logical values can be base64 encoded but get too large.
                enc <- ''
                if (is.na(x)) {
                    code <- '='
                } else if (x == T) {
                    code <- 'T'
                } else {
                    code <- 'F'
                }
            }
            else {
                # Simple scalar values can be written as the are, not changes.
                # Though we must be cautious about "." symbol.
                enc <- toString(x)
                if (is.integer(x)) {
                    code <- 'i'
                } else if (is.numeric(x)) {
                    code <- 'n'
                } else if (is.logical(x)) {
                    code <- 'l'
                } else {
                    orch.dlog.stop("unsupported data type %s", class(x))
                }
            }
        }
    }
    paste(code, enc, sep='')
}

##
#' This function allows to use complex types in values and create nested
#' data types in keyval structure returned by mapper or reducer.
##
.orch.val.decode <- function(enc)
{
    # Values taken from a data.frame can come in as factors but teh code works
    # with strings only. Note: this "if" is faster than toString("").
    if (is.factor(enc)) {
        enc <- toString(enc)
    }
    
    # !BUGFIX! Do not use substring(str, pos) function to cutoff 1st chars as
    # by default it limits the length of the result to 1M chars! See R help.
    code <- substr(enc, 1, 1)
    if (code == "@") {
        code <- substr(enc, 2, 2)
        compresses <- TRUE
    }
    enc <- substr(enc, 2, nchar(enc))
    if (code == "%") {
        # Complex structure. Lists, matrices, data.frames, etc are deparced,
        # compacted and encoded into base64 charset to allow passing through
        # text files.
        str <- base64.decompress(enc, "character")
        val <- eval(parse(text=str))
    }
    else if (code == "-") {
        val <- NULL
    }
    else if (code == "=") {
        val <- NA
    }
    else if (code == "T") {
        val <- TRUE
    }
    else if (code == "F") {
        val <- FALSE
    }
    else {
        # Simple data type. Numbers, logic values, strings, etc are just
        # encoded int base64 charset. Note that base63 float is smaller than
        # its string representation.
        if (code == 'i') {
            type <- "integer"
            val <- as.integer(enc)
        } else if (code == 'n') {
            type <- "numeric"
            val <- as.numeric(enc)
        } else if (code == 'l') {
            type <- "logical"
            val <- as.logical(enc)
        } else if (code == "c") {
            type <- "character"
            val <- base64.decompress(enc, type)
        } else {
            orch.dlog.stop("unsupported type code '%s'", code)
        }
    }
    
    # All done.
    val
}

##
#' Packs a bunch of R objects into a string stream friendly format. Syntax is
#' the same as list(...), e.g. you can use it like pack(a=1, b='x'). The main
#' motivation is to provide an ability to output complex data sets from a
#' mapper or reducer. Example: keyval(key, pack(anything)).
#'
#' @param ... any R objects to pack
#' @param compress Allows compression of the input data before base64 encoding
#'     to lower its size. 3 values are accepted: 
#'     * -1 (default) - let function decide, objects >1KB will be compressed; 
#'     * TRUE - enforce compression always;
#'     * FALSE - disable compression entierly.
#' @return custom base64-based encoded and optionally compressed data
#'   
#' @seealso orch.unpack
##
orch.pack <- function(
        ..., 
        compress = -1,
        smart = FALSE)
{
    # Check input parameters.
    .orch.test.input.stop(compress, c("logical","numeric"))
    .orch.test.input.stop(smart, "logical")
    
    # Prepare objects for encoding and compression. Multiple objects or one 
    # named object must be rolled into a list to preserve their names.
    x <- list(...)
    if (length(x) == 0) {
        # nothing to compress
        x <- NULL
    }
    else if (length(x) == 1 && 
            is.null(names(x))) {
        # one simple object without a name
        x <- x[[1]]
    }
    .orch.val.encode(
        x = x, 
        compress = compress,
        smart = smart)
}

##
#' Unpacks a bunch of R objects from a string stream friendly format. The main
#' motivation is to provide an ability to output and input complex data types 
#' in a mapper or reducer via text-only streams.
#' 
#' @note If [vals] contain only one packed object then will unpack and return 
#' this object alone as-is (unless [list]==TRUE). If [vals] is a vector of 
#' several packed objects then will unpack every one of them and return then as
#' a list.
#' 
#' @example
#'     orch.unpack(orch.pack(a=1)) -> list(a=1).
#'     orch.unpack(orch.pack(a=1), list=T) -> list(list(a=1))
#'     orch.unpack(rep(orch.pack(a=1),2)) -> list(list(a=1), list(a=1))
#' 
#' @param vals Result of pack() function, may be a vector.
#' @param list Always return a list of unpacked objects.
#' @return original R object(s).
#' 
#' @seealso orch.pack
##
orch.unpack <- function(vals, list=FALSE)
{
    # Check input parameters.
    # .orch.test.input.stop(vals, c("character","factor"), 1:100)
    # .orch.test.input.stop(vals, "logical")
    
    if (length(vals) == 1 && !list) {
        objs <- .orch.val.decode(vals)
    }
    else {
        objs <- vector('list', length(vals))
        i <- 1
        for (val in vals) {
            objs[[i]] <- .orch.val.decode(val)
            i <- i + 1
        }
    }
    objs
}

##
#' Converts any R basic type into a string with metadata embedded.
#' Does not support frames, containers, classes, etc.
##
orch.mencode <- function(val)
{
    vt <- class(val)
    if (vt == 'character') {
        pfx <- 'c$'
    }
    else if (vt == 'numeric') {
        pfx <- 'n$'
    }
    else if (vt == 'logical') {
        pfx <- 'l$'
    }
    else if (vt == 'NULL') {
        pfx <- '-$'
    }
    paste(pfx, val, sep='')
}

##
#' Convers a string with metadata embedded back into its original form.
#' @param val result of mencode() call.
##
orch.mdencode <- function(val)
{
    if (!is.character(val)) {
        val
    }
    else {
        pfx <- substr(val, 1, 2)
        x <- substr(val, 3, nchar(val))
        if (pfx == 'c$') {
            x
        }
        else if (pfx == 'n$') {
            as.numeric(x)
        }
        else if (pfx == 'l$') {
            as.logical(x)
        }
        else if (pfx == '-$') {
            as.null(x)
        }
        else {
            val
        }
    }
}
