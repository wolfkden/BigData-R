# Copyright (c) 2012, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' @name Oracle R Connector for Hadoop
#' @docType package
#' 
#' A collection of function to validate input parameters of ORCH external API.
#' The functions must be called at the very beginning of a functon body to
#' ensure that all input preconditions are met.
##

###############################
# DO NOT INCLUDE ANY SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

## ------------------------------------------------------------------------- ##
##                             PRIVATE FUNCTIONS                             ##
## ------------------------------------------------------------------------- ##

##
#' Common template body for R standard data type checks.
#' Example: .orch.test.input.impl(1, 1:10, "numeric", F, "x")
#' 
#' @param v is a parameter value(s) to test
#' @param length is expected length or 
#'     NULL if any length including 0
#'     Inf for any length excluding 0
#' @param type is expected type name, plus:
#'     "<type>NA" no enable NAs as input for this type.
#'     "string" to test for non-empty string
#'     "char" to test for 1 symbol only
#'     "word" to test for non empty string without spaces
#'     "positive" to test for numeric >= 0
#'     "negative" to test for numeric < 0
#' @param stop TRUE to force stop() call of failure
#' @param pnames is a name of the tested parameter
#' 
#' @return TRUE if input check has passed.
#' @return FALSE if input is invalid.
##
.orch.test.input.impl <- function(v, length, type, stop, pnames)
{
    v.name = pnames['v']
    
    # Allow "<type>NA" as input value typespec.
    allowNA <- F
    typeNA <- ends(type, "NA")
    if (any(typeNA)) {
        i <- 0
        type <- sapply(type,
            function(x) {
                i <<- i + 1
                if (typeNA[i]) {
                    x <- substr(x, 1, nchar(x)-2)
                    if (x == '') {
                        # allows non-types NAs.
                        allowNA <<- T
                        x <- "NA"
                    }
                }
                x
            })
    }
#    orch.dlogv(
#        type, 
#        typeNA,
#        allowNA)
    
    # Setup extended types handling.
    # Note: I have deliberately copy-pasted code!
    typeChecks <- list()
    t <- (type == "char") # ***
    if (any(t)) {
        rt <- "character"
        type[t] <- rt
        typeChecks[[rt]] <- c(typeChecks[[rt]], list(list(
            fn = function(x) {nchar(x) == 1},
            msg = "one character")))
    }
    t <- (type == "string") # ***
    if (any(t)) {
        rt <- "character"
        type[t] <- rt
        typeChecks[[rt]] <- c(typeChecks[[rt]], list(list(
            fn = function(x) {nchar(x) >= 1},
            msg = "non-empty string")))
    }
    t <- (type == "word") # ***
    if (any(t)) {
        rt <- "character"
        type[t] <- rt
        typeChecks[[rt]] <- c(typeChecks[[rt]], list(list(
            fn = function(x) {x != '' && !grepl(' ', x)},
            msg = "one word no spaces")))
    }
    t <- (type == "positive") # ***
    if (any(t)) {
        rt <- "numeric"
        type[t] <- rt
        typeChecks[[rt]] <- c(typeChecks[[rt]], list(list(
            fn = function(x) {x >= 0},
            msg = "equal or greater than 0")))
    }
    t <- (type == "negative") # ***
    if (any(t)) {
        rt <- "numeric"
        type[t] <- rt
        typeChecks[[rt]] <- c(typeChecks[[rt]], list(list(
            fn = function(x) {x < 0},
            msg = "less than 0")))
    }
    
    # Verify input value length first.
    if (missing(v) || is.null(v)) {
        orch.dlog.error(
            "[%s] is missing", 
            v.name, 
            stop=stop,
            cat=T)
        return (FALSE)
    }
    # length=NULL means any length is good
    else if (!is.null(length))
    {
        if (length(v) == 0) {
            if (!(0 %in% length)) {
                orch.dlog.error(
                    "[%s] is empty",
                    v.name, 
                    stop=stop,
                    cat=T)
                return (FALSE)
            }
        }
        # length=Inf means any length except 0 is good
        else if (!(length(length) == 1 && is.infinite(length))) {
            vlen <- length(v)
            if (!(vlen %in% length)) {
                if (all(vlen < length)) {
                    orch.dlog.error(
                        "too few [%s], expected > %s", 
                        v.name, min(length), 
                        stop = stop,
                        cat = T)
                    return (FALSE)
                }
                else if (all(vlen > length)) {
                    orch.dlog.error("too many [%s], expected < %s", 
                        v.name, max(length), 
                        stop = stop,
                        cat = T)
                    return (FALSE)
                }
                else {
                    orch.dlog.error("wrong [%s] length, expected %s", 
                        v.name, toString(length), 
                        stop = stop,
                        cat = T)
                    return (FALSE)
                }
            }
        }
    }
    
    # is.na(v) without warning and only logical result
    isNA <- !is.function(v) && length(v) > 0 && is.na(v)
    .assert(is.logical(isNA))
    
    # Verify input value type next. Note that is.na() for 0-length object will 
    # abort or return NULL for data.frames. This case should be handled carefully.
    if (isNA && allowNA) {
        return (TRUE)
    }
    match <- (class(v) == type)
    if (all(!match)) {
        orch.dlog.error(
            "[%s] is %s, expected %s",
            v.name, class(v), toString(type), 
            stop=stop,
            cat=T)
        return (FALSE)
    }
    else if (isNA && all(!typeNA[match])) {
        orch.dlog.error(
            "[%s] can't be NA", 
            v.name, 
            stop = stop,
            cat = T)
        return (FALSE)
    }
    
    # Run special type checks at the end.
    tc <- typeChecks[[class(v)]]
    if (!is.null(tc)) {
        # any of type checks must pass
        ok <- FALSE
        for (test in tc) {
            if (test[["fn"]](v)) {
                ok <- TRUE
                break
            }
            else {
                # use last error message
                msg <- test[["msg"]]
            }
        }
        if (!ok) {
            orch.dlog.error("[%s] must be %s",
                v.name, msg, 
                stop = stop,
                cat = T)
            return (FALSE)
        }
    }
        
    # All checks passed OK.
    TRUE
}

## ------------------------------------------------------------------------- ##
##                             PUBLIC FUNCTIONS                              ##
## ------------------------------------------------------------------------- ##

##
#' Validates one function input parameter. \p length defines number of allowed
#' parameters, use as "min:max" notation. \p stop is used to assert in case of
#' an error instead of just returning FALSE.
#' 
#' \p type can be a vector of different types. At this case if any of the
#' specified types checks out then the input is accepted as valid. Same way
#' \p length can be specified as a vector of valid length values (like c(n,m) 
#' which will accept a range [n,m] of lengths).
#' 
#' @param v is a parameter value(s) to test
#' @param length is expected length(s) or NA if any length. Can be specified as
#'     a vector of valid length values. c(n,m) will accept the range [n,m].
#' @param type is expected type name. Can be specified as a vector of allowed
#'     types which will required that input would match to any of them. Any of
#'     R built-in types can be specified plus:
#'     - "<type>NA" no enable NAs as input for this type.
#'     - "string" to test for non-empty string
#'     - "char" to test for 1 symbol only
#'     - "word" to test for non empty string without spaces
#' @param stop TRUE to force stop() call of failure
#' 
#' @return TRUE if input check has passed.
#' @return FALSE if input is invalid.
##
.orch.test.input <- function(v, 
        type = NULL, 
        length = 1, 
        stop = FALSE)
{
    pnames <- sapply(match.call()[-1], deparse)
    .orch.test.input.impl(
        v = v, 
        length = length, 
        type = type, 
        stop = stop, 
        pnames = pnames)
}

##
#' Same as .orch.test.input(..., stop=T)
##
.orch.test.input.stop <- function(v, 
        type = NULL, 
        length = 1)
{
    pnames <- sapply(match.call()[-1], deparse)
    .orch.test.input.impl(
        v = v, 
        length = length, 
        type = type, 
        stop = TRUE, 
        pnames = pnames)
}

##
#' Validates one function input parameter if it is not NULL. NULL parameter is
#' considered to be a valid input. See .orch.test.input for detailed parameters 
#' description.
#' 
#' @seealso .orch.test.input
#' @seealso .orch.mtest.input
##
.orch.ntest.input <- function(v, 
        type = NULL, 
        length = 1, 
        stop = FALSE,
        missing = FALSE)
{
    if (missing && missing(v)) {
        TRUE
    }
    else if (is.null(v)) {
        TRUE
    }
    else {
        pnames <- sapply(match.call()[-1], deparse)
        .orch.test.input.impl(
            v = v, 
            length = length, 
            type = type, 
            stop = stop, 
            pnames = pnames)
    }
}

##
#' Same as .orch.ntest.input(..., stop=T)
##
.orch.ntest.input.stop <- function(v, 
        type = NULL, 
        length = 1,
        missing = FALSE)
{
    if (missing && missing(v)) {
        TRUE
    }
    else if (is.null(v)) {
        TRUE
    }
    else {
        pnames <- sapply(match.call()[-1], deparse)
        .orch.test.input.impl(
            v = v, 
            length = length, 
            type = type, 
            stop = TRUE, 
            pnames = pnames)
    }
}

##
#' Validates one function input parameter if it is not missing. Missing 
#' parameter is considered to be a valid input. See .orch.test.input for
#' detailed parameters description.
#' 
#' @seealso .orch.test.input
#' @seealso .orch.ntest.input
##
.orch.mtest.input <- function(v, 
        type = NULL, 
        length = 1, 
        stop = FALSE,
        null = FALSE)
{
    if (null && is.null(v)) {
        TRUE
    }
    else if (missing(v)) {
        TRUE
    }
    else {
        pnames <- sapply(match.call()[-1], deparse)
        .orch.test.input.impl(
            v = v, 
            length = length, 
            type = type, 
            stop = stop, 
            pnames = pnames)
    }
}

##
#' Same as .orch.mtest.input(..., stop=T)
##
.orch.mtest.input.stop <- function(v, 
        type = NULL, 
        length = 1,
        null = FALSE)
{
    if (null && is.null(v)) {
        TRUE
    }
    else if (missing(v)) {
        TRUE
    }
    else {
        pnames <- sapply(match.call()[-1], deparse)
        .orch.test.input.impl(
            v = v, 
            length = length, 
            type = type, 
            stop = TRUE, 
            pnames = pnames)
    }
}

##
#' Common template body for special data type checks.
#' Example: .orch.test.special.impl(1, "num", is.numeric, F, "x")
##
.orch.test.special.impl <- function(v, type, func, stop, pnames)
{
    ok <- TRUE
    if (missing(v) || is.null(v)) {
        orch.dloge("[%s] is missing", pnames['v'], stop=stop)
        ok <- FALSE
    }
    else if (length(v) == 0) {
        orch.dloge("[%s] is empty", pnames['v'], stop=stop)
        ok <- FALSE
    }
    else if (!do.call(func, list(v))) {
        orch.dloge("[%s] is not %s", pnames['v'], type, stop=stop)
        ok <- FALSE
    }
    ok
}

##
#' Special data type checks, invokes a custom function \p fn which should 
#' return TRUE or FALSE depending on the input value \p v.
#' Example: .orch.test.special(1, "+", function(x) x>=0, F)
#' 
#' @param v is the value to test
#' @param type is the expected type name
#' @param func special test function
#' @param stop invoke stop() if test fails T|F
##
.orch.ntest.special <- function(v, type, func, stop = FALSE)
{
    ok <- TRUE
    if (!is.null(v)) {
        pnames <- sapply(match.call()[-1], deparse)
        ok <- .orch.test.special.impl(
            v = v, 
            type = type, 
            func = func, 
            stop = stop, 
            pnames = pnames)
    }
    ok
}

##
#' Same as .orch.ntest.special(..., stop=T)
#' @seealso .orch.ntest.special
##
.orch.ntest.special.stop <- function(v, type, func)
{
    ok <- TRUE
    if (!is.null(v)) {
        pnames <- sapply(match.call()[-1], deparse)
        ok <- .orch.test.special.impl(
            v = v, 
            type = type, 
            func = func, 
            stop = TRUE, 
            pnames = pnames)
    }
    ok
}

##
#' Special data type checks, invokes a custom function \p fn which should 
#' return TRUE or FALSE depending on the input value \p v.
#' Example: .orch.test.special(1, "+", function(x) x>=0, F)
#' 
#' @param v is the value to test
#' @param type is the expected type name
#' @param fn special test function
#' @param stop invoke stop() if test fails T|F
##
.orch.test.special <- function(v, type, func, stop = FALSE)
{
    pnames <- sapply(match.call()[-1], deparse)
    .orch.test.special.impl(
        v = v, 
        type = type, 
        func = func, 
        stop = stop, 
        pnames = pnames)
}

##
#' Same as .orch.test.special(..., stop=T)
#' @seealso .orch.test.special
##
.orch.test.special.stop <- function(v, type, func)
{
    pnames <- sapply(match.call()[-1], deparse)
    .orch.test.special.impl(
        v = v, 
        type = type, 
        func = func, 
        stop = TRUE, 
        pnames = pnames)
}

##
#' Use this function to indicate which functions are going to be removed
#' in the future and users should avoid them.
#' 
#' @param new.func Replacement function name or definition (optional).
#' @param version Version in which this function become deprecated (optional).
##
.orch.deprecated <- function(new.func, version)
{
    if (is.function(new.func)) {
        new.func <- deparse(substitute(new.func))
    }
    old.func <- strsplit(deparse(sys.call(1)), '(', fixed=T)[[1]][1]
    verStr <- ''
    if (!missing(version)) {
        verStr <- sprintf(" after %s", version)
    }
    useStr <- ''
    if (!missing(new.func)) {
        useStr <- sprintf(", use \"%s\" instead", new.func)
    }
    orch.dlog.warning("function \"%s\" is deprecated%s%s", 
        old.func, verStr, useStr, cat=T)
}

##
#' Use this function to indicate which functions are removed and users must 
#' not use them. Note that 1st you need to indicated a function as deprecated
#' and only in the next version it can be declared as disabled.
#' 
#' @param new.func Replacement function name or definition (optional).
#' @param version Version in which this function become deprecated (optional).
##
.orch.disabled <- function(new.func, version)
{
    if (is.function(new.func)) {
        new.func <- deparse(substitute(new.func))
    }
    old.func <- strsplit(deparse(sys.call(1)), '(', fixed=T)[[1]][1]
    verStr <- ''
    if (!missing(version)) {
        verStr <- sprintf(" after %s", version)
    }
    useStr <- ''
    if (!missing(new.func)) {
        useStr <- sprintf(", use \"%s\" instead", new.func)
    }
    orch.dlog.stop("function \"%s\" is disabled%s%s", 
        old.func, verStr, useStr, cat=T)
}

##
#' Warns if a parameter was given while it was not expected. Used to warn
#' users about parameters that will be ignored by a function.
##
.orch.not.expected <- function(param)
{
    if (!missing(param)) {
        if (is.character(param)) {
            param <- sprintf('"%s"', param)
        }
        orch.dlogw("unused argument (rownames = %s)", param, cat=T)
    }
}
