# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

#' @name Oracle R Connector for Hadoop
#' @docType package
#' 
#' ORCH Hadoop driver. This file is deployed onto Hadoop as a streaming job
#' and responsible for recieving an input data stream, formatting and convetion
#' of the stream into R data types and invoking user's mapReduce function.
#' 
#' @TODO (vlad) Rewrite on java, hstreaming is too slow.
##

###############################
# DO NOT INCLUDE AND SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

# Pull driver options into local scope, it allows a bit faster access to
# the values compared to access via R's environment variable. Also fixes 
# compatibility (e.g. missing configs) with older ORCH client versions.
cfgDebug           <- null.to(.orch.drv$debug, FALSE)
cfgAssert          <- null.to(.orch.drv$assert, FALSE)
cfgLogSeverity     <- null.to(.orch.drv$log.severity, "all")
cfgMapInput        <- null.to(.orch.drv$map.input, "data.frame")
cfgRedInput        <- null.to(.orch.drv$red.input, "data.frame")
cfgMapOutQuote     <- null.to(.orch.drv$map.out.quote, NULL)
cfgRedOutQuote     <- null.to(.orch.drv$red.out.quote, NULL)
cfgMapOutPristine  <- null.to(.orch.drv$map.out.pristine, TRUE)
cfgRedOutPristine  <- null.to(.orch.drv$red.out.pristine, TRUE)
cfgMapOutKeySep    <- null.to(.orch.drv$map.out.key.sep, "\t")
cfgMapOutValSep    <- null.to(.orch.drv$map.out.val.sep, "\t")
cfgMapOutNullTo    <- null.to(.orch.drv$map.out.null.to, NULL)
cfgMapOutDigits    <- null.to(.orch.drv$map.out.digits, 15)
cfgRedOutKeySep    <- null.to(.orch.drv$red.out.key.sep, "\t")
cfgRedOutValSep    <- null.to(.orch.drv$red.out.val.sep, "\t")
cfgRedOutNullTo    <- null.to(.orch.drv$red.out.null.to, NULL)
cfgRedOutDigits    <- null.to(.orch.drv$red.out.digits, 15)
cfgSkipNARecs      <- null.to(.orch.drv$skip.na.recs, FALSE)
cfgReadBuffer      <- null.to(.orch.drv$read.buffer, 250*K.)
cfgWriteBuffer     <- null.to(.orch.drv$write.buffer, 100*K.)
cfgInputCache      <- null.to(.orch.drv$map.input.cache, 0)
cfgOutputCache     <- null.to(.orch.drv$map.output.cache, 10*K.)
cfgMapSplit        <- null.to(.orch.drv$map.split, -1)
cfgRedSplit        <- null.to(.orch.drv$red.split, -1)
cfgStats           <- null.to(.orch.drv$stats, FALSE)
cfgProfile         <- null.to(.orch.drv$profile, FALSE)
cfgMapValkey       <- null.to(.orch.drv$map.valkey, FALSE)
cfgMapFilter       <- null.to(.orch.drv$map.filter, FALSE)
cfgRedValkey       <- null.to(.orch.drv$red.valkey, FALSE)
cfgRedFilter       <- null.to(.orch.drv$red.filter, FALSE)
cfgInputHeartbeat  <- null.to(.orch.drv$input.heartbeat, 0)
cfgOutputHeartbeat <- null.to(.orch.drv$output.heartbeat, 0)
cfgMapEOS          <- null.to(.orch.drv$map.eos, FALSE)
cfgRedEOS          <- null.to(.orch.drv$red.eos, FALSE)
cfgMapMemuse       <- null.to(.orch.drv$map.memuse, -1)
cfgRedMemuse       <- null.to(.orch.drv$red.memuse, -1)
cfgLogMemSize      <- null.to(.orch.drv$log.mem.size, FALSE)

# !ATTENTION! All R output must be diverted to stderr(). Otherwise any 
# invokation of print(), or cat() in user's mapReduce callback will brake
# (key,vals) stream format. stderr on another had gets diverted to Hadoop 
# log.
sink(stderr())

# Initialize debugging and profiling facilities.
if (cfgDebug) {
    # Enable script debugging. STDOUT is used for streaming out (key,vals),
    # STDERR is stored in a log file on each Hadoop's node.
    orch.dbg.output(stderr())
    orch.dbg.on(cfgLogSeverity, cfgAssert)
} else {
    orch.dbg.off()
    orch.dbg.assert(F)
}
if (cfgProfile) {
    # Enable script profiling.
    orch.perf.on(TRUE)
    orch.perf.tune(10^2, F)
}

# Validate and correct configuration options. This suppose to increase
# compatibily with older ORCH clients and provide useful log information.
if (cfgMapSplit < 0) {
    orch.dlog.info("map splitting disabled")
    cfgMapSplit <- Inf
}
if (cfgRedSplit < 0) {
    orch.dlog.info("reduce splitting disabled")
    cfgRedSplit <- Inf
}
if (cfgReadBuffer < 1) {
    orch.dlog.info("read bufferring is disabled")
    cfgReadBuffer <- -1
}
if (cfgWriteBuffer < 1) {
    orch.dlog.info("write bufferring is disabled")
    cfgWriteBuffer <- -1
}
if (cfgInputCache < 0) {
    orch.dlog.info("initial input cache is disabled")
    cfgInputCache <- -1
}
if (cfgOutputCache < 0) {
    orch.dlog.info("initial output cache is disabled")
    cfgOutputCache <- -1
}

## ------------------------------------------------------------------------- ##
##                          ORCH PUBLIC FUNCTIONS                            ##
## ------------------------------------------------------------------------- ##

##
#' Converts a key and a value into packed keyVal structure ready for streaming
#' out of mapReduce job. This is a "return" expression of a mapReduce user 
#' function.
#'
#' @param key The key value, or NULL for key-less, or "" for no-key output.
#' @param ... key's value(s), values
#' @return None
#' 
#' @example
#'     orch.keyval(key=1, 1,2,3)     -> "1\t1,2,3"
#'     orch.keyval(key=1, c(1,2), 3) -> "1\t1,2,3"
#'     orch.keyval(key=NULL, 1,2,3)  -> "1,2,3"
#'     orch.keyval(key="", 1,2,3)    -> "\t1,2,3"
#'     orch.keyval(key=1)            -> "1\t"
#'     orch.keyval()                 -> no output
#' 
#' @seealso orch.keyvals
##
orch.keyval <- function(key=NULL, ...)
{
    if (length(key) > 1) {
        orch.dloge("multiple keys given for one row output: %s", key)
    }
    else {
        # IMPORTANT. Assigning factors to a preallocated buffer of numeric
        # or logical type will convert strings into indexes rendering output
        # invalid. Factors must be turned into character before copying to
        # the output buffer to preserve values!
        val <- unlist(list(...))
        if (is.null(key) && is.null(val)) {
            orch.dlog.debug("orch.keyval got 0 rows, no output")
        }
        else {
            val <- .orch.defactorize(val)
            .orch.out.grow(1, length(val))
            for (i in seq_len(.orch.out.width)) {
                .orch.out.vbuf[[i]][.orch.out.index] <<- val[i]
            }
            if (!is.null(key)) {
                .orch.out.grow.key()
                .orch.out.kbuf[.orch.out.index] <<- .orch.defactorize(key)
            }
            .orch.out.index <<- .orch.out.index + 1
            orch.dlog.debug("appended 1 to outCache, index=%.0f", 
                .orch.out.index)
        }
    }
}

##
#' Converts a key and a list of value into packed keyval structure ready for 
#' streaming out of mapReduce job. This is a bulk "return" expression of a 
#' mapReduce user function. Outputs the same key for each value if only one key 
#' value is givem.
#'  
#' @example
#'     reducer = function(key, vals) {
#'         # strip keys out of keyVal pairs
#'         orch.keyvals(key=NULL, val=vals)
#'     }
#' 
#' @attention Depending on the "bulk" data type this function will a bit behave 
#'     differently. The faster is data.frame as it's native storage type in 
#'     ORCH, next is vector slightly slower, next is matrix and list is the 
#'     slowest one.
#' 
#' @param key The key value(s), or NULL, or NA (same as ""). If is has more than 
#'     1 value then its length must be equal to number of output rows otherwise
#'     the same key will be repeated for each output row. Special values:
#'       * NULL indicate no-key keyValue.
#'       * NA (or "") indicates that key-less keyValue.
#' @param vals Key's values, can be a list, data.frame, matrix, or vector. If
#'     only one key is specified then in case of a list or a vector the key is 
#'     repeated for each list element, for data.frame and matrix the key is 
#'     repeated for each row.
#' @return None
#' 
#' @seealso orch.keyval
##
orch.keyvals <- function(key=NULL, val=NULL)
{
    # Convert output values data type into a list of columns. Values are 
    # allowed to be NULL, at this case it's considered to be key-only output.
    if (is.null(val)) {
        size <- length(key)
        width <- 0
    }
    else {
        if (is.data.frame(val)) {
            # natively supported
        }
        else if (is.list(val)) {
            val <- do.call(fast.rbind, val)    
        }
        else if (is.vector(val) || is.matrix(val)) {
            val <- as.data.frame(val, stringsAsFactors=F)
        }
        else if (is.factor(val)) {
            val <- as.data.frame(val, stringsAsFactors=T)
        }
        else {
            orch.dlog.stop("unsupported output type %s", class(val))
        }
        size <- nrow(val)
        width <- ncol(val)
    }
    if (size == 0) {
        orch.dlog.debug("got 0 rows, no output")
        return()
    }
    
    # Now for the key, repeat for each value if only one is given. If many keys
    # are given as a vector then make sure the length is the same as values.
    if (length(key) == 0) {
        # key-less output
        key <- NULL
    }
    else if (!is.vector(key) && !is.factor(key)) {
        # unsupported key data type
        orch.dlog.fatal("key must be vector or NULL", stop=T)
    }
    else if (length(key) == 1) {
        # write same key for all rows
        key <- rep(key, size)
    }
    else if (length(key) != size) {
        # write own key for each row
        orch.dlog.stop("length of key and values are not equal")
    }
    
    # Insert a list of keyvals into the output cache. Output cache accumulates 
    # all output keyvals from a mapReduce user's callback up the point when
    # write condition is satisfied.
    if (.orch.out.index == 1 && size >= .orch.out.size)
    {
        # Output cache is smaller than output keyvals chunk and is not touched
        # yet, or cache is not initialized. In any case we can just overwrite 
        # it with the new set of keyvals.
        .orch.out.kbuf <<- key
        .orch.out.vbuf <<- as.list(val)
        .orch.out.width <<- width
        .orch.out.size <<- size
        .orch.out._init <<- TRUE
        orch.dlog.info("direct outCache write, size=%s%s",
            size2str(.orch.out.size), 
            .orch.logmem(obj=.orch.out.vbuf, 
                obj2=.orch.out.vbuf)
        )
        # log "write" message for log integrity
        .assert(.orch.out.index == 1)   
        .orch.out.index <<- size + 1
        orch.dlog.debug("wrote %.0f to outCache, index=%.0f", 
            size, .orch.out.index)
    }
    else
    {
        # Grow output cache if needed and insert key+values into the cache by
        # copying them into pre-allocated cache vectors. This is the fastest
        # way to append data in R.
        .assert(.orch.out._init)
        last <- .orch.out.grow(size, width)
        .assert(.orch.out.width >= width)
        for (i in seq_len(.orch.out.width)) {
            # IMPORTANT. Assigning factors to a preallocated buffer of numeric or 
            # logical type will convert strings into indexes rendering output invalid. 
            # Factors must be turned into character before copying to the output 
            #buffer to preserve values!
            .orch.out.vbuf[[i]][.orch.out.index:last] <<- 
                .orch.defactorize(val[[i]])
        }
        if (!is.null(key)) {
            .orch.out.grow.key()
            # IMPORTANT. See explamntion of defactorization above.
            .orch.out.kbuf[.orch.out.index:last] <<- .orch.defactorize(key)
        }
        .orch.out.index <<- last + 1
        orch.dlog.debug("appended %.0f to outCache, index=%.0f", 
            size, .orch.out.index)
    }
}

##
#' Returns currently running job specification.
#' $name:
#'     "map" - mapper job is running
#'     "reduce" - reducer job is running
#'     "combine" - combiner job is running
#' $type:
#'     1 - mapper job is running
#'     2 - reducer job is running
#'     3 - combiner job is running
##
orch.job <- function()
{
    .assert(.orch.job$.init)
    .orch.job
}

# Current running job attributes
.orch.job <- list(
    name = "",
    type = 0,
    .init = FALSE)

# Global constanst:
ORCH.MAP     <- 1
ORCH.REDUCE  <- 2
ORCH.COMBINE <- 4

## ------------------------------------------------------------------------- ##
##                             ORCH INPUT CACHE                              ##
## ------------------------------------------------------------------------- ##

## Input buffer global data.
.orch.in.buf <- NULL
.orch.in.index <- 0
.orch.in.size <- -1
.orch.in.width <- 0
.orch.in._init <- FALSE

##
#' Initializes the input buffer. Must be called by the driver prior any
#' .orch.in.insert calls. Pre-allocates configured amount of memory.
#' 
#' @param size Expected number of input rows. -1 = do not preallocate.
#' @param width Expected number of input columns.
#' @return None.
##
.orch.in.init <- function(size, width)
{
    .assert(!.orch.in._init)
    if (size >= 0) {
        .orch.in.buf <<- rep(list(rep(NA, size)), width)
        .orch.in._init <<- TRUE
        orch.dlog.info("prealloc inCache, size=%s%s", 
            size2str(size), 
            .orch.logmem(obj=.orch.in.buf))
    }
    .orch.in.index <<- 1
    .orch.in.size <<- size
    .orch.in.width <<- width
}

##
#' Forcibly overwrites the input buffer with new chunk of data. This is useful
#' when it's known that no more data will be received and buffer can be reset.
#' 
#' @param x Then last block of read data as list(vector).
#' @return None.
##
.orch.in.write <- function(x)
{
    if (.orch.in.index > 1) {
        # oops, bug is the code?
        orch.dloge("cache poison avoided")
        .orch.in.append(x)
    }
    else {
        # knowing that this is the last write to cache we can simply replace 
        # the whole cache dataset instead of copying new data into it.
        nrec <- length(x[[1]])
        .orch.rm(.orch.in.buf, rm=F)
        .orch.in.buf <<- x
        .orch.in.size <<- nrec
        .orch.in._init <<- TRUE
        orch.dlog.info("direct inCache overwrite, size=%s%s",
            size2str(.orch.in.size), 
            .orch.logmem(obj=.orch.in.buf))
        
        # log "write" message for log integrity
        .assert(.orch.in.index == 1)
        .orch.in.index <<- nrec + 1
        orch.dlog.debug("wrote %.0f to inCache, index=%.0f", 
            nrec, .orch.in.index)
    }
}

##
#' Reallocates the input buffer memory when needed to fit more input rows
#' and appends new chunk of data. Grows the buffer in increments of 2x.
#' 
#' @param x Then next block of read data as list(vector).
#' @return None.
##
.orch.in.append <- function(x)
{
    nrec <- length(x[[1]])
    if (.orch.in.index == 1)
    {
        # Writing to an empty cache, do "smart" overwrite, e.g. if size of the
        # cache is smaller than data we want to append then we can replace the
        # cache with this data directly.
        if (nrec >= .orch.in.size) {
            .orch.rm(.orch.in.buf, rm=F)
            .orch.in.buf <<- x
            .orch.in.size <<- nrec
            .orch.in._init <<- TRUE
            orch.dlog.info("direct inCache write, size=%s%s",
                size2str(.orch.in.size), 
                .orch.logmem(obj=.orch.in.buf))
        }
        else {
            .assert(.orch.in._init)
            for (i in seq_len(.orch.in.width)) {
                .orch.in.buf[[i]][1:nrec] <<- x[[i]]
            }
        }
        .orch.in.index <<- nrec + 1
        orch.dlog.debug("wrote %.0f to inCache, index=%.0f", 
            nrec, .orch.in.index)
    }
    else
    {
        # Writign to a non-empty input cache, only insert would work. First
        # grow the input cache in 2x increments (as std::vector) and then
        # copy appended data into the cache vectors.
        .assert(.orch.in._init)
        last <- .orch.in.index + nrec - 1
        if (last > .orch.in.size) {
            while (last > .orch.in.size) {
                .orch.in.size <<- .orch.in.size * 2
            }
            for (i in seq_len(.orch.in.width)) {
                length(.orch.in.buf[[i]]) <<- .orch.in.size
            }
            orch.dlog.info("grown inCache, size=%s%s",
                size2str(.orch.in.size), 
                .orch.logmem(obj=.orch.in.buf))
        }
        .assert(last <= .orch.in.size)
        for (i in seq_len(.orch.in.width)) {
            .orch.in.buf[[i]][.orch.in.index:last] <<- x[[i]]
        }
        .orch.in.index <<- last + 1
        orch.dlog.debug("appended %.0f to inCache, index=%.0f", 
            nrec, .orch.in.index)
    }
}

##
#' Resets memory used by the input buffer and rolls back the index back to
#' the first insert position. The pre-allocated memory size remains the same.
#' Should be used to purge the buffer when more data is expected to come in.
##
.orch.in.reset <- function()
{
    if (.orch.in._init) {
        orch.dlog.info("resetting inCache, index=%s%s", 
            size2str(.orch.in.index), 
            .orch.logmem(obj=.orch.in.buf))
        .orch.rm(.orch.in.buf, rm=F)
        .orch.in.index <<- 1
        .orch.gc()
    }
}

##
#' Release all the memory used by the input buffer. This function must be 
#' invoked after all input rows are retreived and no more input is expected.
##
.orch.in.release <- function()
{
    if (.orch.in._init) {
        orch.dlog.trace("releasing inCache, size=%s%s",
            size2str(.orch.in.size), 
            .orch.logmem(obj=.orch.in.buf))
        .orch.rm(.orch.in.buf, rm=T)
        .orch.in.buf <<- NULL
        .orch.in.index <<- 0
        .orch.in.size <<- -1
        .orch.in._init <<- FALSE
        .orch.gc()
    }
}

## ------------------------------------------------------------------------- ##
##                            ORCH OUTPUT CACHE                              ##
## ------------------------------------------------------------------------- ##

## Ouput buffer global data.
.orch.out.kbuf <- NULL
.orch.out.vbuf <- NULL
.orch.out.size <- -1
.orch.out.width <- 0
.orch.out.index <- 0
.orch.out._init <- FALSE

##
#' Initializes the output buffer. Must be called by the driver prior any 
#' orch.keyval or orch.keyvals calls. Pre-allocates configured amount of 
#' memory.
#' 
#' @param size Expected number of output rows. -1 = do not preallocate.
#' @param width Expected number of output columns.
#' @return None.
##
.orch.out.init <- function(size, width=0, key=FALSE)
{
    .assert(!.orch.out._init)
    if (size >= 0 && width > 0) {
        .orch.out.vbuf <<- rep(list(rep(NA, size)), width)
        if (key) {
            .orch.out.kbuf <<- rep(NA, size)
        }
        .orch.out._init <<- TRUE
        orch.dlog.info("prealloc outCache%s, size=%s%s",
            ifelse(key, "+key", ""), 
            size2str(size),
            .orch.logmem(obj=.orch.out.vbuf, 
                obj2=.orch.out.vbuf)
        )
    }
    .orch.out.index <<- 1
    .orch.out.size <<- size
    .orch.out.width <<- width
}

##
#' Reallocates the output value buffer memory when needed to fit more output
#' keyval pairs. Grows the buffer in increments of 2x for the original 
#' preallocated size.
#' 
#' @param size Numner of rows expected to be inserted.
#' @param width Number of columns expected to be inserted.
#' @return Last cache insert index = (cache index + grow size - 1).
#' 
#' @seealso .orch.out.grow.key
#' @seealso .orch.out.init
##
.orch.out.grow <- function(size=1, width)
{
    # Check if output buffer is exhausted. Here we are using STL's vector 
    # dynamic memory allocation stragety and grow cache size 2x if we go over 
    # the limit.
    last <- .orch.out.index + size - 1
    if (!.orch.out._init)
    {
        # cache wasn't initialised yet
        if (width > .orch.out.width) {
            .orch.out.width <<- width
        }
        # prealloc at least the requested grow size  
        if (last > .orch.out.size) {
            .orch.out.size <<- last
        }
        .orch.out.vbuf <<- rep(list(rep(NA, .orch.out.size)), width)
        .orch.out._init <<- TRUE
        .orch.out.width <<- width
        orch.dlog.info("prealloc outCache, size=%s%s", 
            size2str(.orch.out.size),
            .orch.logmem(obj=.orch.out.vbuf, 
                obj2=.orch.out.vbuf)
        )
    }
    else if (last > .orch.out.size)
    {
        # grow input size cache in 2x increments
        while (last > .orch.out.size) {
            .orch.out.size <<- .orch.out.size * 2
        }
        for (i in seq_len(.orch.out.width)) {
            length(.orch.out.vbuf[[i]]) <<- .orch.out.size
        }
        .assert(last <= .orch.out.size)
        orch.dlog.info("grown outCache, size=%s%s", 
            size2str(.orch.out.size), 
            .orch.logmem(obj=.orch.out.vbuf, 
                obj2=.orch.out.vbuf)
        )
        # expand cache width if needed
        if (width > .orch.out.width) {
            for (i in (.orch.out.width+1):width) {
                .orch.out.vbuf[[i]] <<- list(rep(NA, size))
            }
            .orch.out.width <<- width
            orch.dlog.info("expanded outCache, width=%s%s", 
                size2str(.orch.out.width), 
                .orch.logmem(obj=.orch.out.vbuf, 
                    obj2=.orch.out.vbuf)
            )
        }
    }
    
    .assert(last <= .orch.out.size)
    last
}

##
#' Reallocates the output key buffer memory when needed to fit more output
#' keyval pairs. Must be called after after .orch.out.grow() as it relies on
#' the its shared results.
#' 
#' @return None.
#' @seealso .orch.out.grow
##
.orch.out.grow.key <- function()
{
    if (is.null(.orch.out.kbuf)) {
        .orch.out.kbuf <<- rep(NA, .orch.out.size)
        orch.dlog.debug("expanded outCache w/+key")
    }
    else {
        length(.orch.out.kbuf) <<- .orch.out.size
    }
}
    
##
#' Resets memory used by the output buffer and rolls back the index back to
#' the first insert position. The pre-allocated memory size remains the same.
#' Should be used to purge the buffer when more data is expected to come in.
##
.orch.out.reset <- function()
{
    if (.orch.out._init) {
        orch.dlog.info("resetting outCache, index=%s%s", 
            size2str(.orch.out.index),
            .orch.logmem(obj=.orch.out.vbuf, 
                obj2=.orch.out.vbuf)
        )
        .orch.rm(.orch.out.vbuf, rm=F)
        .orch.rm(.orch.out.kbuf, rm=F)
        .orch.out.index <<- 1
        .orch.gc()
    }
}

##
#' Release all the memory used by the output buffer. This function must be 
#' invoked after all output keyval data was streamed and the run is finished.
##
.orch.out.release <- function()
{
    if (.orch.out._init) {
        orch.dlog.trace("releasing outCache, size=%s%s",
            size2str(.orch.out.index), 
            .orch.logmem(obj=.orch.out.vbuf, 
                obj2=.orch.out.vbuf)
        )
        .orch.rm(.orch.out.vbuf, rm=T)
        .orch.out.vbuf <<- NULL
        .orch.out.kbuf <<- NULL
        .orch.out.size <<- -1
        .orch.out.width <<- 0
        .orch.out.index <<- 0
        .orch.out._init <<- FALSE
        .orch.gc()
    }
}

##
#' Defines a custom formatter of output float and double values if used chooses
#' a non-standard output precision (non 15-digits). Non-standard precision will 
#' lower overall output throughput even if user sets lower precision.
#'
#' @param digits Output precision in number of deciman digits.
#' @return Formatting function of output cache.
##
.orch.format.fn <- function(digits)
{
    .assert(.orch.out.index > 1)
    fn <- NULL
    if (digits != 15) {
        fn <- if (.orch.out.index <= .orch.out.size) {
            fn <- function(x) 
                format(x[1:(.orch.out.index-1)],
                    trim = TRUE,
                    justify = "none", 
                    digits = digits)
        }
        else {
            .assert(.orch.out.index+1 == .orch.out.size)
            function(x) 
                format(x,
                    trim = TRUE,
                    justify = "none", 
                    digits = digits)
        }
    }
    else {
        fn <- if (.orch.out.index <= .orch.out.size) {
            function(x) x[1:(.orch.out.index-1)]
        }
        else {
            .assert(.orch.out.index+1 == .orch.out.size)
            function(x) x
        }
    }
    .assert(is.function(fn))
    fn
}

##
#' Formats and pastes output cache columns into one vector of [sep] separated
#' text lines. Can output key column with value columns but it will use the
#' same separator for key and value fields.
#' 
#' ATTENTION! Preserves pecision of float values but explicitely formatting
#' then with format(x, digits=22) R call. 22 digits is the maximum float and
#' double type precision in R as of now.
#' 
#' @param sep Values separator to use.
#' @param with.key Append key column and use the same value separator.
#' @param digits Output precision in number of deciman digits.
#' @return Vector of strings.
##
.orch.out.paste <- function(sep, with.key, digits)
{
    if (.orch.out.index <= 1) {
        character(0)
    }
    else {
        buf <- .orch.out.vbuf
        if (with.key) {
            .assert(!is.null(.orch.out.kbuf))
            buf <- c(list(.orch.out.kbuf), buf)
        }
        rown <- .orch.out.index - 1
        coln <- length(buf)
        if (coln > 1)
        {
            if (rown < .orch.out.size || digits != 15) {
                # 1) slowest possible paste
                .format <- .orch.format.fn(digits)
                do.call(paste, c( 
                    lapply(buf, .format),
                    sep = sep
                ))
            }
            else {
                # 2) about 5% faster than 1)*
                .assert(digits == 15)
                do.call(paste, c( 
                    buf, 
                    sep = sep
                ))
            }
        }
        else if (coln > 0)
        {
            if (digits == 15) {
                if (rown < .orch.out.size) {
                    # 3) about 11% faster 2)
                    as.character(
                        buf[[1]][1:rown]
                    )
                }
                else {
                    # 4) about 2% faster than 3)
                    as.character(
                        buf[[1]]
                    )
                }
            }
            else {
                # 5) approx. the same as 3)*
                .format <- .orch.format.fn(digits)
                .format(buf[[1]])
            }
        }
        else {
            # no values and keys to output
            character(0)
        }
        # * - only if digits=15
    }
}

##
#' Uses write.table R native function to write output cache keys and values 
#' (only if key separator is the same as value separator). This wouldn't work 
#' for non-default precision because write.table has no precision configuration 
#' via arguments.
#' 
#' @param file Write to connection.
#' @param sep Values separator to use.
#' @param null.key Replacement string of NULL key.
#' @return None. 
##
.orch.out.direct.write <- function(
        file, 
        sep, 
        null.key = NULL)
{
    .assert(.orch.out.index > 1)
    buf <- .orch.out.vbuf
    if (!is.null(.orch.out.kbuf)) {
        buf <- c(list(.orch.out.kbuf), buf)
    }
    else if (!is.null(null.key)) {
        .assert(is.null(.orch.out.kbuf))
        buf <- c(list(rep(null.key, .orch.out.size)), buf)
    }
    rown <- .orch.out.index - 1
    if (rown < .orch.out.size) {
        buf <- as.data.frame(buf,
            stringsAsFactors = F)[1:rown,]
    }
    write.table(
        x = buf,
        file = file,
        col.names = FALSE,
        row.names = FALSE,
        sep = sep,
        eol = "\n",
        quote = FALSE
    )
}

##
#' Writes out to [file] connection current cached output keys and values.
#' If cached keys are NULL then uses [null.key] string instead for each
#' value.
#'
#' @param key.sep Key/values separator to use.
#' @param val.sep Value/value separator to use.
#' @param file Write to connection.
#' @param digits Output precision in number of deciman digits.
#' @param null.key Replacement string of NULL key. 
#' @param eos End of stream status.
#' @return None.
##
.orch.out.write <- function(
        key.sep, 
        val.sep,
        file,
        digits, 
        null.key = NULL, 
        eos = FALSE)
{
    # Fix stderr sink and write lines.
    if (file == stdout() && stdout() == stderr()) {
        sink(NULL)
        file <- stdout()
        sink(stderr())
    }
    
    # Choose the fastest way to write output cache. If there are no keys or
    # keys and values have the same separator we can use write.table which is
    # by fast better then paste+cat.
    writeKey <- !is.null(.orch.out.kbuf)
    if ((key.sep == val.sep || !writeKey) && 
            digits == 15)
    {
        # Use write.table R native function to write values and keys (only if
        # key separator is the same as value separator). This wouldn't work
        # for non-default precision too because write.table has no precision
        # configuration via arguments.
        orch.dlog.debug("direct write of%s %.0f line%s",
            ifelse(eos, " last", ""),
            .orch.out.index-1, 
            .s(.orch.out.index-1))
        .orch.out.direct.write(
            file = file, 
            sep = val.sep,
            null.key = null.key)
    }
    else
    {
        # Convert output cache into text. This is much slower than using a
        # direct write path but can support different key and value separator
        # and non-default precision.
        orch.dlog.info("pasting output into a text buffer")
        if (key.sep == val.sep && writeKey) {
            # 1) fastest, one paste() call
            buf <- .orch.out.paste(
                with.key = TRUE, 
                sep = val.sep,
                digits = digits)
        }
        else if (!writeKey) {
            # 2) about 12% slower than 1)
            if (is.null(null.key)) {
                buf <- .orch.out.paste(
                    with.key = FALSE, 
                    sep = val.sep,
                    digits = digits)
            }
            else {
                buf <- sprintf(
                    paste0(null.key, key.sep, "%s"),
                    .orch.out.paste(
                        with.key = FALSE, 
                        sep = val.sep,
                        digits = digits))
            }
        }
        else {
            # 3) about 56% slower than 1)
            .format <- .orch.format.fn(digits)
            buf <- paste(
                .format(.orch.out.kbuf),
                .orch.out.paste(
                    with.key = FALSE, 
                    sep = val.sep,
                    digits = digits),
                sep = key.sep)
        }
        orch.dlog.debug("writing%s %.0f line%s",
            ifelse(eos, " last", ""),
            length(buf), .s(obj=buf))
        cat(buf, sep = '\n', file = file)
    }
}

## ------------------------------------------------------------------------- ##
##                          ORCH MEMORY MANAGEMENT                           ##
## ------------------------------------------------------------------------- ##

## Approximate total memory used my ORCH driver.
.orch.mem.total <- 0
.orch.mem.max <- Inf

##
#' Log a memory usage information at the end of a message string. Turns out
#' object.size() is very expensive to invoke for large and complex objects
#' as it will traverse the whole object's tree to sum up sizes of all leaf
#' objects. This function turns ON or OFF logging of memory sizes depending
#' on driver configuration.
#' 
#' @param format Optional custom format string, default is ", mem=%s".
#' @param ... Object(s) to get its memory size.
#' @retunr Message string.
#' 
#' @example 
#'     orch.dlog.debug("object A size=%g%s", length(a), .orch.logmem(obj=a))
#'     orch.dlog.debug("%s", .orch.logmem("object A mem=%s", obj=a))
##
.orch.logmem <- if (cfgLogMemSize)
{
    function(format, ...) {
        bytes <- 0
        for (obj in list(...)) {
            bytes <- object.size(obj)
        }
        if (missing(format)) {
            format <- ", mem=%s"
        }
        sprintf(format, mem2str(bytes))
    }
} else {
    .orch.logmem <- function(...) {
        ""
    }
}

##
#' Check for excessive memory usage by an object.
#' Example: .orch.check.mem.usage('a', 50) -> warning reported!
#' 
#' @param x An object or object.size() result.
#' @param normal Expected memory usage in bytes.
#' @param high High threshold memory usage in bytes, by default = normal*2.
#' @param veryhigh Highest threshold memory usage in bytes, by default = high*2.
#' @param gc Level of memory usage [1-3] when to invoke R garbage collector.
#'     Or logical: TRUE - always invoke, FALSE - never invoke.
#' @param rm Level of memory usage [1-3] when to force object delete.
#'     Or logical: TRUE - always delete, FALSE - never delete.
#' @return None.
#' 
#' @seealso .orch.gc
##
.orch.rm <- function(x,
    normal = 25*MB,
    high, 
    veryhigh, 
    gc = FALSE,
    rm = 3)
{
    # Retreive object's memory footprint.
    # @TODO (vlad) object.size is too slow, how to approximale?
    xName <- deparse(substitute(x))
    if (!exists(xName, envir=parent.frame())) {
        orch.dlog.debug("object \"%s\" doesn't exist", xName)
        xSize <- 0
    }
    else {
        xSize <- object.size(x)
    }
    
    # Inspect memory size of the object and issue a warning to the log 
    # if the object uses too much memory. 3 levels can be set: 
    #   1 = normal, 
    #   2 = high (2x normal),
    #   3 = very_high (4x normal). 
    level <- 0 # = normal usage
    if (xSize > normal)
    {
        if (missing(high)) {
            high <- normal * 2
        }
        if (missing(veryhigh)) {
            veryhigh <- high * 2
        }
        
        # report memory over-usage warning
        if (xSize > veryhigh) {
            level <- 3
            warnMsg <- "very high memory"
            maxUsage <- veryhigh
        }
        else if (xSize > high) {
            level <- 2
            warnMsg <- "high memory"
            maxUsage <- high
        }
        else {
            level <- 1
            warnMsg <- "memory"
            maxUsage <- normal
        }
        .assert(level > 0)
        orch.dlogw("%s usage by object \"%s\", %s > %s", 
            warnMsg, xName,
            mem2str(xSize), 
            mem2str(maxUsage))
    }
    
    # Allow to use logical conditions for "rm" and "gc" options.
    # TRUE - always "remove object"/"collect garbage", FALSE - never.
    if (is.logical(rm)) {
        rm <- ifelse(rm, 0, 4)
    }
    if (is.logical(gc)) {
        gc <- ifelse(gc, 0, 4)
    }
    # + memory usage level based action
    rm <- !is.null(rm) && level >= rm
    gc <- !is.null(gc) && level >= gc
    
    # Now trace apporimate memory usage by driver's unlinked objects.
    # If it gets too high then force garbage collection.
    .orch.mem.total <<- .orch.mem.total + object.size(x) 
    
    # Try to lower the memory usage by removing the object + run garbage 
    # collector if required. Driven by the memory usage level [0-3].
    if (rm && xSize > 0) {
        orch.dlog.trace("forcing release of object \"%s\", mem=%s", 
            xName, mem2str(xSize))
        assign(xName, NULL, envir=parent.frame())
        rm(x) # otherwise R will simply copy the object
    }
    if (gc && rm) {
        .orch.gc()
    }
}

##
#' ORCH-controlled garbage collector. Invokes garbage collector when total
#' memory usage is suspected to be over preconfigured limit.
##
.orch.gc <- function()
{
    if (.orch.mem.total > .orch.mem.max) {
        orch.dlogw("total memory usage %s > max %s, running gc()",
            mem2str(.orch.mem.total), 
            mem2str(.orch.mem.max))
        gc()
        .orch.mem.total <<- 0
    }
}

## ------------------------------------------------------------------------- ##
##                           ORCH PRIVATE FUNCTIONS                          ##
## ------------------------------------------------------------------------- ##

##
#' Simple inline ifelse evaluator, allows to retun NULL which is not possible 
#' with R's ifelse (have no idea why).
##
.orch.if <- function(cond, yes, no)
{
    if (cond) {
        yes
    }
    else {
        no
    }
}

##
#' Converts factor data type into character only. All other data types will
#' be left intact. E.g. .orch.defactorize(1) -> 1.
#' 
#' @param x A vector.
#' @return As character if [x] is factor, otherwise intact.
##
.orch.defactorize <- function(x)
{
    if (is.factor(x)) {
        as.character(x)
    }
    else {
        x
    }
}

##
#' Converts a data.frame into row-wise list of lists of its values as:
#' list(list(col1_v1, col2_v1, ...), list(col1_v2, col2_v2, ...), ...)
#' @example .orch.df2list(cars)
##
.orch.df2list <- function(x)
{
    ll<-apply(x, 1, list)
    lapply(ll, function(x) as.list(unlist(x))) 
}

##
#' Converts a data.frame into row-wise vector of values as:
#' vector(col1_v1, col2_v1, ..., col1_v2, col2_v2, ...)
#' @example .orch.df2list(cars)
##
.orch.df2vector <- function(x)
{
    as.vector(apply(x, 1, unlist))
}

##
#' Parses command line and sets execution options.
#' @note Must guarantee validity of all options set.
##
.orch.cmdline <- function(args = commandArgs(TRUE))
{
    # Command line specification:
    spec <- c(
        "mapper",   "m", 0, "logical",   "Execute the mapper.",       FALSE, 
        "reducer",  "r", 0, "logical",   "Execute the reducer.",      FALSE, 
        "combiner", "c", 0, "logical",   "Execute the combiner.",     FALSE, 
        "debug",    "d", 0, "logical",   "Produce debugging output.", FALSE,
        "input",    "i", 1, "character", "Input file|pipe name.",     "stdin",
        "output",   "o", 1, "character", "Output file|pipe name.",    "stdout")
    
    # Parse the command line.
    mspec <- matrix(spec, ncol = 6, byrow = TRUE)
    opt <- getopt(mspec[, 1:5], opt = args)
    
    # Set missing options to their defaults.
    i <- 1
    for (arg in mspec[,1]) {
        val <- opt[[arg]]
        if (is.null(val)) {
            # convert to the specified tyep
            val <- mspec[i,6]
            storage.mode(val) <- mspec[i,4]
            opt[[arg]] <- val
        }
        i <- i+1
    }
    
    # Quick sanity check of options.
    taskCnt <- opt$mapper + opt$reducer + opt$combiner
    if (taskCnt == 0) {
        orch.dlog.stop("must specify at least one task to run")
    }
    else if (taskCnt > 1) {
        orch.dlog.stop("can specify only one task to run")
    }
    
    # Option are fine.
    opt$ok <- TRUE
    opt
}

##
#' Based on the metadata dynamically generates a function which can convert a 
#' vector of strings (streamed in HDFS data) into close to original data type.
#' Restores data data types and data names.
#' 
#' @param meta ORCH meta attributes as a list.
#' @param range Generate range convertions function.
#' @param as.type Apply type conversion to each column.
#' @param log Log generated function.
#' 
#' @note Full conversion function is faster as it operates of a whole vector 
#'     of strings and does not need to select its portion. Range conversion 
#'     function is slower as it has to select a portion of each string vector 
#'     in a list which will affect its performance.
##
.orch.generate.val.parser <- function(meta, 
        range = FALSE,
        as.type = TRUE, 
        log = !range)
{
    # Extract types and names from ORCH metadata.
    keyi <- meta$orch.keyi
    types <- strim(meta$orch.types)
    names <- strim(meta$orch.names)
    if (keyi > 0) {
        types <- types[-keyi]
        names <- names[-keyi]
    }
    
    if (length(types) > 0)
    {
        if (log) {
            orch.dlogv("value", paste(
                sprintf("%s\"", names), types, 
                sep = " as \""))
        }
        if (!range && !as.type)
        {
            # Input data types are already converted and only "factor" types need 
            # to be converted from "character" as all factors are stored as strings 
            # in an HDFS file.
            stringCols <- sum(types == "character")
            factorCols <- sum(types == "factor")
            if (stringCols >= factorCols) {
                # majority of target column types are "character"
                src <- paste0("function(x){",
                    "y<-as.data.frame(x",
                    if (keyi >= 0) "[-1]" else "",
                    ",stringsAsFactors=FALSE);")
                for (i in seq_along(types)) {
                    if (types[i] == "factor") {
                        src <- paste0(src,
                            "y[[",i,"]]<-",
                            "as.factor(y[[",i,"]]);")
                    }
                }
            }
            else {
                # majority of target column types are "factor"
                src <- paste0("function(x){",
                    "y<-as.data.frame(x",
                    if (keyi >= 0) "[-1]" else "",
                    ",stringsAsFactors=TRUE);")
                for (i in seq_along(types)) {
                    if (types[i] == "character") {
                        src <- paste0(src,
                            "y[[",i,"]]<-",
                            "as.character(y[[",i,"]]);")
                    }
                }
            }
        }
        else
        {
            # Ranged conversion always construct a new data.frame from "pieces",
            # e.g. data.frame(col1[range], col2[range], ...). We need to make sure
            # that "factor" type conversion is applied even when input data is
            # already converted as all factors are stored as strings in an HDFS.
            src <- paste0("function(x",
                if (range) ",r" else "",
                "){",
                "y<-data.frame(")
            for (i in seq_along(types)) {
                conv <- (as.type && types[i] != "character") || 
                    (!as.type && types[i] == "factor")
                src <- paste0(src,
                    if (conv) paste0("as.",types[i],"(") else "",
                    "x[[", i + ifelse(keyi>=0, 1, 0), "]]",
                    if (range) "[r]" else "",
                    if (conv) ")" else "",
                    ",")
            }
            src <- paste0(
                # remove tailing ","
                substr(src, 1, nchar(src)-1), 
                ",stringsAsFactors=FALSE);")
        }
        
        # And add names asignment.
        if (!is.null(names)) {
            src <- paste0(src, 
                "names(y)<-c(",
                paste0('"',names,'"', collapse=','),
                ");")
        }
        src <- paste0(src, "y}")
    }
    else {
        if (log) {
            orch.dlogv("value", NULL)
        }
        src <- paste0("function(x",
            if (range) ",r" else "",
            "){as.data.frame(x)[-seq_along(x)]",
            if (range) "[r,]" else "",
            "}")
    }
    
    # Log the parser code for debugging.
    if (log) {
        orch.dlog.debug("value%s parser = %s", 
            ifelse(range, " range", "s"), src)
    }
    
    # Compile into an R function.
    eval(parse(text=src))
}

##
#' Based on the metadata dynamically generates a function which can convert a 
#' string key (streamed in HDFS data) into original data type and name.
#' 
#' @param meta ORCH meta attributes as a list.
#' @param range Generate range convertions function.
#' @param as.type Apply type conversion to each column.
#' @param log Log generated function.
#' 
#' @note Full conversion function is faster as it operates of a whole vector 
#'     of strings and does not need to select its portion. Range conversion 
#'     function is slower as it has to select a portion of each string vector 
#'     in a list which will affect its performance.
##
.orch.generate.key.parser <- function(meta, 
        range = FALSE,
        as.type = TRUE,
        log = !range)
{
    # Extract required attributed from metadata.
    keyi <- meta$orch.keyi
    if (keyi > 0) {
        type <- strim(meta$orch.types[keyi])
        name <- strim(meta$orch.names[keyi])
        if (log) {
            orch.dlogv("key", paste0(
                name, '" as "', type))
        }
        
        # Format key type convertion function source code. Make sure that 
        # "factor" type conversion is applied even when input data is already 
        # converted as all factors are stored as strings in an HDFS.
        conv <- (as.type && type != "character") || 
            (!as.type && type == "factor")
        src <- paste0(
            "function(x", 
            if (range) ",r" else "",
            "){y<-",
            if (conv) paste0("as.",type,"(") else "",
            "x[[1]]",
            if (range) "[r]" else "",
            if (conv) ")" else "",
            ";")
        
        # And add names asignment.
        if (!is.null(name)) {
            src <- paste0(src,
                "attr(y,'name')<-\"",name,"\";")
        }
        src <- paste0(src, "y}")
    }
    else {
        if (log) {
            orch.dlogv("key", NULL)
        }
        src <- paste0("function(x",
            if (range) ",r" else "",
            "){NULL}")
    }

    # Log the parser code for debugging.
    if (log) {
        orch.dlog.debug("key%s parser = %s", 
            ifelse(range, " range", "s"), src)
    }
    
    # Compile into an R function.
    eval(parse(text=src))
}

##
#' Generates an R function for data conversion from a data.frame (native
#' ORCH input data type) into "matrix", "vector", or "list". The funtion
#' is invoked for each input split just before passing it to a mapper or a
#' reducer.
#' 
#' @param input.type Name of the R data type to convert data.frame to.
#' @return R convertion function.
##
.orch.generate.prep.fn <- function(type, name)
{ 
    if (type == "data.frame") {
        # input data is "data.frame" already, nothing to do 
        function(x, nrow) {
            x[nrow,,drop=FALSE]
        }
    }
    else if (type == "vector") {
        # converts data.frame into a vector of rows values, 
        # e.g. vector(col1_v1=1,col1_v2=2,...,col1_v2=3,col2_v2=4,...)
        function(x, nrow) {
            if (ncol(x) > 1) {
                .orch.df2vector(x[nrow,,drop=FALSE])
            } else {
                x[nrow,]
            }
        }
    }
    else if (type == "matrix") {
        # converts data.frame into a matrix of values,
        # e.g. matrix(c(col1_v1=1,col1_v2=2,...,col2_v1=3,col2_v2=4,...))
        function(x, nrow) {
            as.matrix(x[nrow,,drop=FALSE])
        }
    }
    else if (type == "list") {
        # converts data.frame into a list of rows as a list of values, 
        # e.g. list(list(col1_v1=1,col1_v2=2,...),list(col1_v1=1,col1_v2=2,...),...)
        function(x, nrow) {
            .orch.df2list(x[nrow,,drop=FALSE])
        }
    }
    else {
        orch.dloge("bad \"%s\" config value = \"%s\"", 
            name, type, stop=T)
        NULL
    }
}

##
#' Finds the next aggregation block size by the key value. This is used to
#' separate same key blocks in a reducer as Hadoop streaming may stream
#' several different keys into one reducer.
#' 
#' @param keys Vector of keys.
#' @param i Aggregation start position.
#' @param size Keys vector size (may be less then length).
#' @return Size of a block with the same keys keys[i:_] 
##
.orch.aggregate.keys <- function(keys, i, size)
{
    scan <- which(keys != keys[[i]])
    pos <- scan[scan > i & scan < (size+i)]
    if (length(pos) > 0) {
        .assert(length(keys) < pos[1])
        pos[1] - i
    }
    else {
        .assert(length(keys) < i+size)
        size
    }
}

## ------------------------------------------------------------------------- ##
##                               ORCH DRIVER                                 ##
## ------------------------------------------------------------------------- ##

##
#' The driver of the map-reduce functions execition. Controls user R functions
#' executions. Responsible for Hadoop stream retreival, data conversion, and 
#' Hadoop stream output. 
##
.orch.driver <- function()
{
    orch.dlog.info("Oracle R Connector for Hadoop %s (rev. %s)", 
	    null.to(.orch.env$version, "undefined"), 
        null.to(.orch.env$revision, "undefined"))
    
    # Start performance meter.
    .t <- orch.dlogi(t=T)
    orch.dbg.newtimer("ORCH driver v4.0 (alpha)")
    orch.dlog.info("codename Banderlog")
    
    # Print current R environment.
    orch.dlog.info(version$version.string)
    orch.dlogv('lib', search())
    for (v in ls(.orch.drv)) {
        orch.dlogv(
            sprintf(".orch.drv$%s", v),
            get(v, .orch.drv))
    }
    
    # Verify the this node has a required R version.
    if (version$major != 2 || version$minor < 13.2) {
        orch.dlog.fatal("unsupported R version, R-2.13.2+ is required",
            stop=T, cat=T)
    }
    else if (version$minor < 15.0) {
        orch.dlogw("outdated R version, R-2.15.3 is recommended")
    }
    else if (version$minor > 15.3) {
        orch.dlogw("untested R version, R-2.15.3 is recommended")
    }
    
    # Read input options and setup execution schema.
    orch.perf.start()
    opt <- .orch.cmdline()
    if (opt$mapper)
    {
        opt$mode <- ORCH.MAP
        .orch.mem.max <<- cfgMapMemuse
        jobType <- "mapper"
        splitSize <- cfgMapSplit
        valkeyAdd <- cfgMapValkey
        valkeyDel <- cfgMapFilter
        eosSig <- cfgMapEOS
        meta <- .parse.meta(NULL, orch.meta.dfs)
        pristine <- null.to(meta$orch.pristine, FALSE)
        inKeySep <- null.to(meta$key.sep, "\t")
        inValSep <- null.to(meta$value.sep, ",")
        outKeySep <- cfgMapOutKeySep
        outValSep <- cfgMapOutValSep
        outDigits <- cfgMapOutDigits
        outNullTo <- cfgMapOutNullTo
        drop1stCol <- FALSE
        inQuote <- NULL
        outQuote <- cfgMapOutQuote
        aggrFun <- function(x, i, sz) {sz}
        prepFun <- .orch.generate.prep.fn(cfgMapInput, "map.input")
        workFun <- if (cfgStats) {
            # add stats counting to the mapper
            function(k, v) {
                statMapred <<- statMapred + 1
                orch.mapper(k, v)
            }
        } else {
            # directly call user's mapper
            orch.mapper
        }
    }
    else if (opt$reducer)
    {
        opt$mode <- ORCH.REDUCE
        .orch.mem.max <<- cfgRedMemuse
        jobType <- "reducer"
        splitSize <- cfgRedSplit
        valkeyAdd <- cfgRedValkey
        valkeyDel <- cfgRedFilter
        eosSig <- cfgRedEOS
        meta <- .parse.meta(NULL, orch.meta.map)
        pristine <- cfgMapOutPristine
        inKeySep <- cfgMapOutKeySep
        inValSep <- cfgMapOutValSep
        outKeySep <- cfgRedOutKeySep
        outValSep <- cfgRedOutValSep
        outDigits <- cfgRedOutDigits
        outNullTo <- cfgRedOutNullTo
        drop1stCol <- !is.null(cfgMapOutNullTo) && meta$orch.keyi < 0
        inQuote <- cfgMapOutQuote
        outQuote <- cfgRedOutQuote
        aggrFun <- .orch.aggregate.keys
        prepFun <- .orch.generate.prep.fn(cfgRedInput, "red.input")
        workFun <- if (cfgStats) {
            # add stats counting to the reducer
            function(k, v) {
                statMapred <<- statMapred + 1
                .assert(all(k == k[[1]]))
                orch.reducer(k[[1]], v)
            }
        } else {
            # directly call user's reducer; there is a catch, all keys are the 
            # same so we need to pass only one 1st key and discard the rest.
            function(k, v) {
                orch.reducer(k[[1]], v)
            }
        }
    }
    else if (opt$combiner)
    {
        # Reducer and combiner has essentially the same job setup with very
        # marginal differences, e.g. we can use the same code to setup 
        # both.
        opt$mode <- ORCH.COMBINE
        .orch.mem.max <<- cfgMapMemuse
        jobType <- "combiner"
        orch.dlog.stop("not supported")
    }
    else {
        orch.dlog.stop('bug in ORCH driver setup code')
    }
    orch.dlogt("ready to run")
    orch.perf.stop(t.setup)

    # Set orch.job() attributes.
    .orch.job$name <<- jobType
    .orch.job$type <<- opt$mode
    .orch.job$.init <<- TRUE
    
    # Invoke user's initialization callback.
    orch.perf.start()
    orch.dlog.info("invoking initialization callback")
    orch.init()->.
    orch.perf.stop(t.init)
    
    # Prepare input and ouput connections. I have no idea why but I have
    # to open stdin connection instead of using stdin(), otherwise I do not
    # get the HDFS stream.
    sink()
    opt$icon <- .orch.open(opt$input, "rt", stop=T)
    opt$ocon <- .orch.open(opt$output, "wt", stop=T)
    sink(stderr())
    
    # Extract input data meta attributes and configure data scanning and
    # data parsing settings. This mostly configures how are we going to
    # read data in (see scan() below).
    m.keyi <- null.to(meta$orch.keyi, -1)
    m.types <- null.to(meta$orch.types, "character")
    m.ncol <- length(m.types) + ifelse(m.keyi==0, 1, 0)
    m.names <- null.to(meta$orch.names, paste0("val", seq_along(m.types)))
    m.quote <- null.to(inQuote, null.to(meta$orch.quote, ''))    
    m.trim <- null.to(meta$orch.trim, FALSE)
    
    # Generate data type conversion functions specifically for the input 
    # metadata. There are two flavors - one which converts the whole input 
    # cache and one which converts a range of values from the cache.
    convKeysFun <- .orch.generate.key.parser(meta, 
        range = FALSE,
        as.type = !pristine,
        log = TRUE)
    convValsFun <- .orch.generate.val.parser(meta, 
        range = FALSE, 
        as.type = !pristine,
        log = TRUE)
    convKeyRangeFun <- .orch.generate.key.parser(meta, 
        range = TRUE,
        as.type = !pristine,
        log = FALSE)
    convValRangeFun <- .orch.generate.val.parser(meta, 
        range = TRUE,
        as.type = !pristine,
        log = FALSE)
    
    # Configure how scan() will split fields and how manu scan()'s we'll need
    # to run. Apparently the secondary scan() is required only if we have
    # two different separators present in a line as scan can use only one
    # separator at a time.
    if (m.ncol <= 1) {
        # input is: "key\n" or "val\n" or "\n"
        scan1Sep <- inValSep # whole line
        secondScan <- FALSE
    }
    else if (m.ncol == 2 && m.keyi >= 0) {
        # input is: "key\tval\n"
        scan1Sep <- inKeySep
        secondScan <- FALSE
    }
    else {
        # input is: "key\tval,val\n" or "val,val\n"
        scan1Sep <- inValSep
        secondScan <- (m.keyi >= 0 && inKeySep != inValSep)
    }
    
    # This variable defines how many fields scan() expects to split into
    # each input row. Normally it's number of data columns with 2 excptions:
    #   1. Empty key is not included in the data types spec => +1.
    #   2. Second scan means key column is merged to 1st value column => -1.
    #   3. Drop 1st column a way to remove system injected empty key column.
    scanWidth <- length(m.types) + 
        ifelse(m.keyi==0, 1, 0) +
        ifelse(secondScan, -1, 0) +
        ifelse(drop1stCol, 1, 0)
    
    # Now prepare a specification of columns for scan() invokation. In
    # so-called "pristine" mode we assume that input data is absolutely
    # clean as does not contain any bad values, NAs or NULLs, missing or
    # extra fields. With this assumption we can configure scan() to run
    # 10+x faster but it will abort if input stream is not "pristine".
    if (pristine) {
        # Convert R column types stored in ORCH HDFS metadata into a scan
        # specification list. Note that "factor" types must be scanned as 
        # "character" because scan() will expect numeric values as factors.
        scan1Spec <- sapply(m.types, function(type) {
            if (type == "factor") { 
                character()
            } else {
                vector(type)
            }
        })
        if (m.keyi > 0) {
            # move key field type to the 1st column
            scan1Spec <- c(scan1Spec[m.keyi], scan1Spec[-m.keyi])
        }
        else if (m.keyi == 0 || drop1stCol) {
            # add empty key 1st column type
            scan1Spec <- c('', scan1Spec)
        }
        if (secondScan) {
            # if key is "glued" to 1st field read it as one string
            scan2Spec <- scan1Spec[1:2]
            scan1Spec <- c('', scan1Spec[-1:-2]) 
        }
        scanFlush <- m.trim
    }
    else {
        scan1Spec <- as.list(rep('', scanWidth))
        scan2Spec <- as.list(rep('', 2))
        scanFlush <- TRUE
    }
    .assert(length(scan1Spec) == scanWidth)
    .assert(!secondScan || length(scan2Spec) == 2)

    # Simple scan means that we read one character field per line without
    # quotes. This allows to use readLines() instead of scan() which is
    # considerably faster.
    simpleScan <- scanWidth == 1 &&
        is.character(scan1Spec[[1]]) && 
        m.quote == '' && !m.trim
    
    # Log scan setup.
    orch.dlog.trace("Scan setup:")
    orch.dlogv("| key column no", m.keyi)
    orch.dlogv("| input columns", m.ncol)
    orch.dlogv("| quoting char", m.quote)
    orch.dlogv("| pristine mode", pristine)
    orch.dlogv("| scan fields", scanWidth)
    orch.dlogv("| scan separator", scan1Sep)
    orch.dlogv("| secondary scan", secondScan)
    orch.dlogv("| simple scan", simpleScan)
    orch.dlogv("| scan flush", scanFlush)
    orch.dlogv("| drop 1st column", drop1stCol)
    
    # Analyse scan setup and issue warnings.
    if (secondScan) {
        orch.dlogw("(!) performance drop due to second scan")
    }
    else if (!pristine) {
        orch.dlogw("(!) performance drop due to non-pristine mode")
    }
    else {
        orch.dlog.info("best performance scan configuration")
    }
    if (outDigits != 15) {
        orch.dlogw("(!) output throughput drop due to non-standard precision")
    }
    if (outKeySep != outValSep) {
        orch.dlogw("(!) direct write can't be used due non-uniform separators")
    }
    
    # Validate driver options and correct if it was misconfigured by a user.
    # After this section ORCH driver is properly configured and ready to run.
    if (m.keyi < 1) {
        # do not insert non-existing keys into values
        if (valkeyAdd || valkeyDel) {
            orch.dloge("no key to insert into vals")
            valkeyAdd <- FALSE
            valkeyDel <- FALSE
        }
    }
    else {
        # do not remove key from values if it wasn't inserted
        if (valkeyDel && !valkeyAdd) {
            orch.dloge("key wasn't inserted into vals")
            valkeyDel <- FALSE
        }
    }
    orch.dlogv2(
        jobType,
        valkeyAdd,
        valkeyDel,
        splitSize,
        eosSig,
        outNullTo,
        drop1stCol)
    
    # Configure memory management. This is very questinable piece of code
    # as I see lots of latency using gc(), rm(), object.size() R functions.
    if (.orch.mem.max < 0) {
        .orch.rm <<- function(...) {}
        .orch.gc <<- function(...) {}
        orch.dlog.info("low memory management is OFF")
    }
    
    # Initialize execution statistics. Counts number of input and output 
    # records, number of map and recude function calls, etc.
    statMapred <- 0L
    statInput <- 0L
    statOutput <- 0L
    statSplit <- 0L
    statBadRec <- 0L
    statNullOut <- 0L
    
    # Setup run profiling. Counts timer spent for each of the driver logical 
    # sections. Only optinal sections that may not be executed need to be
    # set here.
    if (orch.perf.enabled()) {
        t.read <- orch.perf.t()
        t.parse <- orch.perf.t()
        t.gc <- orch.perf.t()
        t.conv <- orch.perf.t()
        t.split <- orch.perf.t()
        t.cache <- orch.perf.t()
        t.mapred <- orch.perf.t()
        t.write <- orch.perf.t()
    }
    
    # This is a heartbeat counter which defines how often to print out
    # "I'm alive" messages to the log indicating that the process still is 
    # running.
    lastInputHB <- 
        if (cfgInputHeartbeat == 0) {
            Inf # never report input heartbeat
        } else {
            as.integer(cfgInputHeartbeat)
        }
    lastOutputHB <- 
        if (cfgOutputHeartbeat == 0) {
            Inf # never report output heartbeat
        } else {
            as.integer(cfgOutputHeartbeat)
        }
    
    # Prepare in/out cache. Input cache accumulates parsed and splitted
    # input data before applying any data type conversions. Output cache
    # accumulates keyVal results of mapper and reducer before formatting 
    # and to stdout.
    orch.perf.start()
    .orch.in.init(cfgInputCache, m.ncol)
    .orch.out.init(cfgOutputCache)
    orch.perf.stop(t.cache)

    # Prepare write buffer. The write buffer is used to output formatted
    # keyval strings to stdout in bulk instead of row-by-row which greatly
    # inmproves write throughput.
    orch.perf.start()
    writeSize <- ifelse(cfgWriteBuffer < 0, Inf, cfgWriteBuffer)
    orch.dlogv("write buffer size", writeSize)
    orch.perf.stop(t.cache)

    orch.dlogt("streaming started")
    streamEnd <- FALSE
    tailKeys <- NULL # left after split keys
    tailVals <- NULL # left after split values
    while (!streamEnd)
    {
        # Read data stream and invoke 1st stage of map-reduce function.
        # At this stage we transfer (1 key, 1 value) pairs to the callback.
        orch.dlogt("step A.%.0f: aggregate", statSplit+1)
        repeat
        {
            # Read the next chunk of lines from stdin. scan() is the fastest 
            # function to read and split input file into tokens. The function 
            # will fail though if type conversion fails, e.g. we have to read 
            # everything as character() first.
            orch.perf.start()
            if (simpleScan) {
                input <- list(readLines(
                    con = opt$icon,
                    n = -1L,
                    ok = TRUE,
                    warn = FALSE))
            }
            else if (pristine) {
                input <- scan(
                    file = opt$icon,
                    what = scan1Spec,
                    nlines = cfgReadBuffer,
                    sep = scan1Sep,
                    skip = 0,
                    flush = scanFlush, #was F
                    fill = F,
                    quiet = T,
                    quote = m.quote,
                    comment.char = '')
            }
            else {
                input <- scan(
                    file = opt$icon,
                    what = scan1Spec,
                    nlines = cfgReadBuffer,
                    sep = scan1Sep,
                    skip = 0,
                    flush = T,
                    fill = T,
                    quiet = T,
                    quote = m.quote,
                    comment.char = '')
            }
            if (length(input) == 0) {
                # read after the EOS
                nlines <- 0
            }
            else {
                nlines <- length(input[[1]])
                .assert(all(sapply(input, length) == nlines))
            }
            if (drop1stCol) {
                input <- input[-1]
            }
            if (nlines < cfgReadBuffer || cfgReadBuffer < 0) {
                orch.dlog.info("input EOS")
                streamEnd <- TRUE
                if (nlines == 0) {
                    # read over EOS
                    break
                }
            }
            statInput <- statInput + nlines
            if (statInput >= lastInputHB) {
                lastInputHB <- lastInputHB + cfgInputHeartbeat
                orch.dlog.info("{HB} received +%d = %d record%s", 
                    nlines, statInput, .s(statInput))
            }
            orch.perf.stop(t.read)

            # Parse the input line and split into string tokens. At the end
            # we will get a transposed matrix of string values where each row 
            # corresponds to each input data column
            orch.perf.start()
            if (secondScan) {
                # split the 1st column into key and value if the key separator
                # is not the same as value separator and key + 1st values
                # was parsed as 1 column together
                if (pristine) {
                    keyVal <- scan(
                        text = input[[1]],
                        what = scan2Spec,
                        sep = inKeySep,
                        skip = 0,
                        flush = F,
                        fill = F,
                        quiet = T,
                        quote = m.quote,
                        comment.char = '')
                    .assert(all(sapply(keyVal, length) == nlines))
                    input <- c(keyVal, input[-1])
                }
                else {
                    keyVal <- scan(
                        text = input[[1]],
                        what = list("", ""),
                        sep = inKeySep,
                        skip = 0,
                        flush = T,
                        fill = T,
                        quiet = T,
                        quote = m.quote,
                        comment.char = '')
                    .assert(all(sapply(keyVal, length) == nlines))
                    input <- c(keyVal, input[-1])
                }
            }
            orch.perf.stop(t.parse)
                
            # Now accumulate read and parsed lines into a split buffer. If the
            # split size is less than the input buffer then it will just copy
            # the input buffer reference, no other overhead.
            orch.perf.start()
            if (streamEnd) {
                # this is the last chunk of data, skip caching
                .orch.in.write(input)
            } else {
                # accumulate in cache untill slit size is reached
                .orch.in.append(input)
            }
            orch.perf.stop(t.cache)
            
            # Purge memory just before reading the next chunk of rows from
            # stdin. This may help us not to run out of memory, experimental.
            orch.perf.start()
            .orch.rm(input)
            .orch.rm(keyVal)
            .orch.gc()
            orch.perf.stop(t.gc)
                       
            # Check splitting conditions. Splitting "simulates" the end-of-stream
            # condition for an aggregate (or user) function. After splitting the 
            # new input record will start a new aggregare.
            if (.orch.in.index > splitSize || streamEnd) {
                statSplit <- statSplit + 1
                orch.dlog.debug("split buffer spill at %d records%s", 
                    .orch.in.index - 1,
                    .orch.logmem(obj=.orch.in.buf))
                # goto the next stage
                break
            }
        }
        orch.dlogt("+cached")
        orch.dlog.info("got %d line%s x %d col%s in inCache", 
            .orch.in.index-1, .s(.orch.in.index-1),
            .orch.in.width, .s(.orch.in.width))
        
        # if end of stream has reached, no data has been received then send 
        # end-of-stream signal to user's mapReduce callback prematurely and
        # quit the loop.
        if (streamEnd) {
            if (.orch.in.index == 1) {
                if (streamEnd) {
                    if (eosSig) {
                        orch.dlog.info("sending %s EOS", jobType)
                        orch.perf.start(twf_)
                        workFun(NULL,NULL)
                        orch.perf.stop(t.mapred, twf_)
                    }
                    break
                }
            }
            else if (.orch.in.index <= splitSize) {
                if (splitSize != Inf) {
                    orch.dlogw("last split is incomplete, got %d < %d",
                        .orch.in.index - 1, 
                        splitSize)
                }
            }
        }
        else {
            .assert(.orch.in.index > splitSize)
        }
        
        # Convert tokens into a vector of keys plus a data.frame of values with 
        # expected types (metadata). If some values can't be converted NA will 
        # be used in place. Rows with NAs will be rejected if skip.na.recs=TRUE.
        orch.perf.start()
        if (.orch.in.index > .orch.in.size) {
            inputKeys <- convKeysFun(.orch.in.buf)
            inputVals <- convValsFun(.orch.in.buf)
        } else {
            inputKeys <- convKeyRangeFun(.orch.in.buf, 1:(.orch.in.index-1)) 
            inputVals <- convValRangeFun(.orch.in.buf, 1:(.orch.in.index-1))
        }
        .assert(length(inputKeys) == ifelse(keyi>0, .orch.in.index-1, 0))
        .assert(ncol(inputVals) == m.ncol - ifelse(keyi>=0, 1, 0))
        .assert(nrow(inputVals) == .orch.in.index-1)
        
        # Important to log!
        orch.dlogv(length(inputKeys))
        orch.dlogv(dim(inputVals))
        
        # Drop records with NA (if configured), e.g. make absolutely input 
        # clean so the user does not need to care about its validity. 
        if (cfgSkipNARecs) {
            naRows <- FALSE
            if (!is.null(inputKeys)) {
                naRows <- is.na(inputKeys)
            }
            for (col in inputVals) {
                naRows <- naRows | is.na(col)
            }
            inputKeys <- inputKeys[!naRows]
            inputVals <- inputVals[!naRows,, drop=FALSE]
            nbad <- sum(naRows)
            statBadRec <- statBadRec + nbad
            orch.dlogw("dropped %.0f NA records", nbad)
        }
        
        # And insert key column into the values if client has configured 
        # so. Performance drop is guatanteed but this adds some flexibility
        # and portablity to the framework.
        if (valkeyAdd) {
            .assert(m.keyi > 0)
            orch.dlog.debug("inserting key into vals, index=%.0f", m.keyi)
            n <- length(inputVals)
            if (m.keyi > 1) {
                if (m.keyi <= n) {
                    inputVals <- data.frame(
                        inputVals[,1:m.keyi-1, drop=F], 
                        key = inputKeys,
                        inputVals[,m.keyi:n, drop=F])
                }
                else if (n > 0) {
                    .assert(n > 0)
                    inputVals <- data.frame(inputVals, key=inputKeys)
                }
            }
            else {
                if (m.keyi <= n) {
                    inputVals <- data.frame(
                        key = inputKeys,
                        inputVals[,m.keyi:n, drop=F])
                }
                else {
                    .assert(n == 0)
                    inputVals <- data.frame(key=inputKeys)
                }
            }
            keyName <- attr(inputKeys, "name")
            if (!is.null(keyName)) {
                m.names(inputVals)[m.keyi] <- keyName
            }
        }
        orch.perf.stop(t.conv)
        
        # And finally it is possible that the buffer was not completely
        # consumed by the last split and some (key, values) are left. This can
        # happen if (split % buffer) != 0.
        orch.perf.start()
        if (!is.null(tailKeys)) {
            inputKeys <- c(tailKeys, inputKeys)
            tailKeys <- NULL
        }
        if (!is.null(tailVals)) {
            inputVals <- rbind(tailVals, inputVals)
            tailVals <- NULL
        }
        orch.perf.stop(t.cache)
        
        orch.dlogt("+converted")
        orch.dlog.info("%.0f key%s loaded", length(inputKeys), .s(obj=inputKeys))
        orch.dlog.info("%.0f*%.0f value%s loaded", nrow(inputVals), ncol(inputVals), .s(df=inputVals))
        
        # Purge memory just before running the mapper. We don't know how
        # much memory will be used in the client's mapper code.
        orch.perf.start()
        .orch.rm(tailKeys)
        .orch.rm(tailVals)
        .orch.in.reset()
        .orch.gc()
        orch.perf.stop(t.gc)
        
        # Now invoke 2nd stage of map-reduce callback if defined.
        # Here we can transfer (1 key, N values) data to the callback.
        orch.dlogt("step B.%.0f: user callback", statSplit)
        
        # Execute map-reduce callback. This is a little be tricky becayse we
        # need to apply splitting conditions and send input data to the user's
        # callback function in chunks.
        orch.perf.start()
        bufSize <- nrow(inputVals)
        if (bufSize == 0) {
            orch.dlog.info("input buffer is empty, skipping over")
        }
        else if (m.keyi < 1) {
            .assert(bufSize > 0)
            key1 <- .orch.if(m.keyi < 0, NULL, "")
            if (splitSize == 1) {
                orch.dlogd("codepath 1:1")
                orch.dlog.info("no aggregation, sending records 1-by-1")
                for (i in seq_len(bufSize)) {
                    val1 <- prepFun(inputVals, i)
                    orch.perf.start(twf_)
                    workFun(key1, val1)
                    orch.perf.stop(t.mapred, twf_)
                }
                inputKeys <- c()
                inputVals <- c()
            }
            else {
                .assert(splitSize != 1)
                orch.dlogd("codepath 1:2")
                bufPos <- 1
                bufEnd <- bufSize + 1
                bufSplit <- ifelse(splitSize>=1, splitSize,
                    ifelse(splitSize<0, Inf, bufEnd-1))
                # important! bufSplit must be Inf accumilate all input data
                # in memory, or = input block size to directly pass it as-is 
                # to user's callback.
                logged <- FALSE
                repeat {
                    while (bufPos + bufSplit <= bufEnd) {
                        splitPos <- bufPos + bufSplit - 1
                        orch.dlog.info("split block[%.0f:%.0f], size %.0f", 
                            bufPos, splitPos, 
                            splitPos-bufPos+1)
                        valSplit <- prepFun(inputVals, bufPos:splitPos)
                        bufPos <- splitPos + 1
                        orch.perf.start(twf_)
                        workFun(key1, valSplit)
                        orch.perf.stop(t.mapred, twf_)
                    }
                    if (streamEnd && bufPos < bufEnd) {
                        if (!logged) {
                            orch.dlogw("last split%s %.0f < %.0f",
                                if (bufSplit!=Inf) " incomplete" else "", 
                                bufEnd - bufPos,
                                bufSplit)
                            logged <- TRUE
                        }
                        bufSplit <- bufEnd - bufPos
                        # repeat the loop and sent incomplete split
                    }
                    else {
                        # no more complete splits
                        break
                    }
                }
                if (bufPos < bufEnd) {
                    orch.dlog.debug("split rollover %.0f", bufEnd-bufPos-1)
                    inputKeys <- inputKeys[bufPos:(bufEnd-1),]
                    inputVals <- inputVals[bufPos:(bufEnd-1),]
                } else {
                    orch.dlog.debug("no split rollover")
                    inputKeys <- c()
                    inputVals <- c()
                }
            }
        }
        else {
            .assert(m.keyi >= 0)
            .assert(bufSize > 0)
            if (splitSize == 1) {
                orch.dlogd("codepath 2:1")
                orch.dlog.info("no aggregation, sending records 1-by-1")
                for (i in seq_along(inputKeys)) {
                    key1 <- inputKeys[[i]]
                    val1 <- prepFun(inputVals, i)
                    orch.perf.start(twf_)
                    workFun(key1, val1)
                    orch.perf.stop(t.mapred, twf_)
                }
                inputKeys <- c()
                inputVals <- c()
            }
            else {
                orch.dlogd("codepath 2:2")
                .assert(splitSize != 1)
                bufPos <- 1
                bufEnd <- bufSize + 1
                bufSplit <- ifelse(splitSize>=1, splitSize,
                    ifelse(splitSize<0, Inf, bufEnd-1))
                # important! bufSplit must be Inf accumilate all input data
                # in memory, or = input block size to directly pass it as-is 
                # to user's callback.
                logged <- FALSE
                repeat {
                    while (bufPos + bufSplit <= bufEnd) {
                        splitPos <- bufPos + aggrFun(inputKeys, bufPos, bufSplit) - 1 
                        orch.dlog.info("aggregate block[%.0f:%.0f], size %.0f", 
                            bufPos, splitPos, 
                            splitPos-bufPos+1)
                        keySplit <- inputKeys[bufPos:splitPos]
                        valSplit <- prepFun(inputVals, bufPos:splitPos)
                        bufPos <- splitPos + 1
                        orch.perf.start(twf_)
                        workFun(keySplit, valSplit)
                        orch.perf.stop(t.mapred, twf_)
                    }
                    if (streamEnd && bufPos < bufEnd) {
                        if (!logged) {
                            orch.dlogw("last split%s, size=%.0f < %.0f",
                                if (bufSplit!=Inf) " incomplete" else "", 
                                bufEnd - bufPos, 
                                bufSplit)
                            logged <- TRUE
                        }
                        bufSplit <- bufEnd - bufPos
                        # repeat the loop and sent incomplete split
                    }
                    else {
                        # no more complete splits or OES
                        break
                    }
                }
                if (bufPos < bufEnd) {
                    orch.dlog.debug("split rollover %.0f", bufEnd-bufPos)
                    inputKeys <- inputKeys[bufPos:(bufEnd-1),]
                    inputVals <- inputVals[bufPos:(bufEnd-1),]
                } else {
                    orch.dlog.debug("no split rollover")
                    inputKeys <- c()
                    inputVals <- c()
                }
            } 
        }
        tailKeys <- inputKeys
        tailVals <- inputVals
        orch.perf.stop(t.split)
        
        orch.dlogt("+callback")
        orch.dlog.info("%.0f key%s left", length(tailKeys), .s(obj=tailKeys))
        orch.dlog.info("%.0f val%s left", null.to(nrow(tailVals),0), .s(df=tailVals))
        orch.dlog.info("outCache has %d keyval%s", 
            .orch.out.index-1, .s(.orch.out.index-1))
        
        # Purge memory just before writing buffered output. All input data
        # was processed by mapReduce user's functions and useless now.
        orch.perf.start()
        .orch.rm(inputKeys)
        .orch.rm(inputVals)
        .orch.gc()
        orch.perf.stop(t.gc)
        
        # Force writing to stdout after each mapper or reducer invocation when 
        # the size is larger then configured maximum or if write buffer size is 
        # configured to a special value 0. Or if buffer grows too large.
        orch.perf.start()
        written <- FALSE
        if (.orch.out.index <= 1) {
            statNullOut <- statNullOut + 1
        }
        else if (.orch.out.index > writeSize) {
            written <- TRUE
            if (valkeyDel) {
                # remove key column from values
                .orch.out.vbuf <<- .orch.out.vbuf[-m.keyi]
            }
            .orch.out.write(
                key.sep = outKeySep,
                val.sep = outValSep,
                null.key = outNullTo,
                file = opt$ocon, 
                eos = streamEnd,
                digits = outDigits)
            # update output heartbeat log
            statOutput %+=% (.orch.out.index-1)
            if (statOutput > lastOutputHB) {
                lastOutputHB %+=% cfgOutputHeartbeat
                orch.dlog.info("{HB} wrote%s +%d = %d record%s", 
                    ifelse(streamEnd, " last", ""), 
                    .orch.out.index-1, 
                    statOutput, .s(statOutput))
            }
        }
        orch.perf.stop(t.write)
        
        # Purge memory just before writing buffered output. All input data
        # was processed by mapReduce user's functions and useless now.
        orch.perf.start()
        if (written) {
            .orch.out.reset()
            .orch.gc()
        }
        orch.perf.stop(t.gc)
        
        # Checkpoint.
        orch.dlogt("+written")
        orch.dlog.debug("output cache has %.0f line%s left", 
            .orch.out.index-1, .s(.orch.out.index-1))

        # Send end-of-stream signal to the callback if needed. This allows
        # user to finilize aggregation or compitation of data is feed to the
        # reducer (or mapper) callback in splits.
        if (streamEnd) {
            if (eosSig) {
                orch.dlog.info("sending %s EOS", jobType)
                orch.perf.start(twf_)
                workFun(NULL,NULL)
                orch.perf.stop(t.mapred, twf_)
            }
            break
        }
    }
    
    # Invoke user's finalization callback. This must be the last call to
    # users function. No mapper or reducer will be called after that. Note
    # that the final callback can invoke orch.keyval() and output rows.
    orch.perf.start()
    orch.dlog.info("invoking finalization callback")
    orch.final()->.
    orch.perf.stop(t.final)
    
    # Write out the rest of the output cache and write buffer. Cache may
    # contain some keyvals left if user's mapper or reducer was invoked with
    # EOS signal or if the final callback output rows.
    orch.perf.start()
    if (.orch.out.index > 1) {
        if (valkeyDel) {
            .orch.out.vbuf <<- .orch.out.vbuf[-m.keyi]
        }
        .orch.out.write(
            key.sep = outKeySep,
            val.sep = outValSep,
            null.key = outNullTo, 
            file = opt$ocon, 
            eos = TRUE,
            digits = outDigits)
        statOutput %+=% (.orch.out.index-1)
        orch.dlog.info("{HB} wrote last +%d = %d record%s", 
            .orch.out.index-1, 
            statOutput, .s(statOutput))
    }
    orch.perf.stop(t.write)
    
    # And release in/out buffers.
    orch.perf.start()
    orch.dlog.info("releasing cache") 
    .orch.in.release()
    .orch.out.release()
    .orch.rm(writeBuf)
    .orch.gc()
    orch.perf.stop(t.gc)
    
    orch.dlogt("finished streaming")
    orch.dlog.trace("%s job is done", jobType)
    
    # Print job stats.
    if (cfgStats) {
        orch.dlog.info("Run statistics:")
        orch.dlog.info("| %s invokations = %.0f", jobType, statMapred)
        orch.dlog.info("| input records  = %.0f", statInput)
        orch.dlog.info("| output records = %.0f", statOutput)
        orch.dlog.info("| bad records    = %.0f", statBadRec)
        orch.dlog.info("| input splits   = %.0f", statSplit)
        orch.dlog.info("| null output MR = %.0f", statNullOut)
    }
    
    # Don't forget to close all streams.
    sink()
    .orch.close(opt$icon, stop=F)->.
    .orch.close(opt$ocon, stop=F)->.
    sink(stderr())

    # Compute unaccounted overhead.
    if (orch.perf.enabled()) {
        t.split <- t.split - t.mapred
        t.sum <- t.setup + t.init + t.read + 
            t.parse + t.conv + t.split + 
            t.cache + t.mapred + + t.write + 
            t.final + t.gc
        t.driver <- as.numeric(Sys.time() - .t, units="secs")
        t.misc <- t.driver - t.sum["time"] - t.sum["cost"]
        t.cost <- t.sum["cost"]
        if (t.misc < 0) {
            t.cost <- t.cost + t.misc
            t.misc <- 0
        }
    }
    
    # Print out performance measurements.
    if (cfgProfile) {
        orch.perf.log("Run profile:")
        orch.perf.log("| driver setup    =", t.setup)
        orch.perf.log("| init callback   =", t.init)
        orch.perf.log("| read input      =", t.read)
        orch.perf.log("| stream parsing  =", t.parse)
        orch.perf.log("| type conversion =", t.conv)
        orch.perf.log("| in/out caching  =", t.cache)
        orch.perf.log("| input splitting =", t.split)
        orch.perf.log("| mapReduce       =", t.mapred)
        orch.perf.log("| writing output  =", t.write)
        orch.perf.log("| final callback  =", t.final)
        orch.perf.log("| garbage collect =", t.gc)
        orch.perf.log("| sum all timers  =", t.sum)
        orch.perf.log("| profiling cost  =", t.cost)
        orch.perf.log("| misc overhead   =", t.misc)
    }
    if (cfgStats && cfgProfile) {
        statInOut <- statInput + statOutput
        orch.perf.log("Throughput:")
        orch.dlog.info("| input read    = %.3f rec/s", statInput/t.read["time"])
        orch.dlog.info("| input parse   = %.3f rec/s", statInput/t.parse["time"])
        orch.dlog.info("| input convert = %.3f rec/s", statInput/t.conv["time"])
        orch.dlog.info("| mapReduce     = %.3f rec/s", statInOut/t.mapred["time"])
        orch.dlog.info("| output write  = %.3f rec/s", statOutput/t.write["time"])
        orch.dlog.info("| total I/O     = %.3f rec/s", statInOut/t.driver)
    }
    
    # All done, stop timer.
    orch.dlogo(t=.t)
}
