# Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' @name Oracle R Connector for Hadoop
#' @docType package
#' @attention Experimental code still.
#' 
#' Oracle R Connector for Hadoop HDFS cache. All interractions with Hadoop
#' via CLI have latency about 3-5 seconds which make simple operations like
#' getting size or metadata unaccaptably slow and impossible to unse in real
#' time.
#' 
#' HCACHE is aimed to put a layer of cache between any HDFS CLI command
#' and Hadoop which would return a cached responce if this command was already
#' invoked once before. For instance once you read HDFS object metadata every
#' following metadata access call will get cached data. There is timeout
#' and max cache access count safeguards around.
##

if (!exists('.orch.env')) {
    orch.dlog.stop("wrong loading order")
}

###############################
# DO NOT INCLUDE ANY SOURCES! #
###############################

##
#' Resets the HDFS cache, all entries are dropped.
##
.orch.hcache.reset <- function()
{
    .orch.env$hcache <- list()
    orch.dlog.info("hcache was reset")
}

##
#' Drops an entry from HDFS cache.
#' 
#' @param dfs.if HDFS object identifier to delete cache for.
#' @return None.
##
.orch.hcache.drop <- function(dfs.id)
{
    dfsPath <- toString(.dfs.path(dfs.id))
    hit <- .orch.env$hcache[[dfsPath]]
    if (!is.null(hit)) {
        .orch.env$hcache[[dfsPath]] <- NULL
        orch.dlog.info("hcache entry dropped \"%s\"", dfsPath)
    }
}

##
#' Moves cached data from one HDFS cache entry to another. If target entry 
#' already exists then it will be overwritten.
#' 
#' @param dfs.src Source HDFS object identifier to move cache from.
#' @param dfs.dst Destination HDFS object identifier to move cache to.
#' @return None.
##
.orch.hcache.move <- function(dfs.src, dfs.dst)
{
    fromDfsPath <- toString(.dfs.path(dfs.src))
    hit <- .orch.env$hcache[[fromDfsPath]]
    if (!is.null(hit)) {
        toDfsPath <- toString(.dfs.path(dfs.dst))
        .orch.env$hcache[[fromDfsPath]] <- NULL
        .orch.env$hcache[[toDfsPath]] <- hit
        orch.dlog.info("hcache entry moved \"%s\" -> \"%s\"", 
            fromDfsPath, toDfsPath)
    }
}

##
#' Copies cached data from one HDFS cache entry to another. If target entry 
#' already exists then it will be overwritten.
#' 
#' @param dfs.src Source HDFS object identifier to move cache from.
#' @param dfs.dst Destination HDFS object identifier to move cache to.
#' @return None.
##
.orch.hcache.copy <- function(dfs.src, dfs.dst)
{
    fromDfsPath <- toString(.dfs.path(dfs.src))
    hit <- .orch.env$hcache[[fromDfsPath]]
    if (!is.null(hit)) {
        toDfsPath <- toString(.dfs.path(dfs.dst))
        .orch.env$hcache[[toDfsPath]] <- hit
        orch.dlog.info("hcache entry copied \"%s\" -> \"%s\"", 
            fromDfsPath, toDfsPath)
    }
}

##
#' Return cached ORCH metadata or invalidates cache if validity timeout has
#' passed or if there were too many access requestes. Timeout enforces re-
#' caching after some period of time. Access counter ensures that frequently
#' accessible object are re-chached more often.
#' 
#' @param dfs.if HDFS object identifier to check cache for.
#' @return Cached metadata or NULL if none available.
##
.orch.hcache.mget <- function(dfs.id)
{
    .assert(is.character(dfs.id))
    ttl <- null.to(.orch.env$hcache.ttl, 300)
    ctl <- null.to(.orch.env$hcache.ctl, 50)
    
    # Look in HDFS cache for metadata and return it if it's not too old.
    # Old cache entries get deleted on first access attempt.
    dfsPath <- toString(.dfs.path(dfs.id))
    hit <- .orch.env$hcache[[dfsPath]]
    if (!is.null(hit)) {
        age <- proc.time()[3] - hit$timestamp
        if (age < ttl && hit$count < ctl) {
            # cache is good
            ret <- hit$meta
            .orch.env$hcache[[dfsPath]]$counter <- hit$counter + 1
            orch.dlog.info("hcache hit \"%s\", age=%g, cnt=%g", 
                dfsPath, age, hit$counter)
        }
        else {
            # cache has aged and must be purged
            .orch.env$hcache[[dfsPath]] <- NULL
            ret <- NULL
            orch.dlog.info("hcache discarded \"%s\", age=%g, cnt=%g", 
                dfsPath, age, hit$counter)
        }
    }
    else {
        # not cached ever
        orch.dlog.info("hcache miss \"%s\"", dfsPath)
        ret <- NULL
    }
    
    .assert(is.character(ret) || is.null(ret))
    ret
}

##
#' Writes ORCH metadata into an HDFS object cache. This will overwrite
#' currect object cache if any.
#' 
#' @param dfs.id HDFS object identifier to set cache for.
#' @param meta Metadata to set as cache or NULL to reset.
#' @return None.
##
.orch.hcache.mput <- function(
        dfs.id,
        meta)
{
    .assert(is.character(dfs.id))
    .assert(is.character(meta) || is.null(meta))
    
    # Overwrites current metadata cache and resets aging counters.
    # NULL metadata is a special case, we just drop the cache entry.
    dfsPath <- toString(.dfs.path(dfs.id))
    if (is.null(meta)) {
        .orch.env$hcache[[dfsPath]] <- NULL
        orch.dlog.info("hcache deleted \"%s\"", dfsPath)
    }
    else {
        .orch.env$hcache[[dfsPath]] <- list(
            meta = meta,
            timestamp = proc.time()[3],
            counter = 0)
        orch.dlog.debug("hcache meta set \"%s\"", dfsPath)
    }
}
