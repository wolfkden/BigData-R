# Copyright (c) 2012, 2013, Oracle and/or its affiliates. All rights reserved. 

##
#' @name Oracle R Connector for Hadoop
#' @docType package
#' 
#' Oracle R Connector for Hadoop HDFS core services. The functionalities
#' in this file is shared by orch-hdfs.R and orch-mapred.R and represent
#' the base layer between ORCH APIs and Hadoop CLI.
##

###############################
# DO NOT INCLUDE ANY SOURCES! #
# See orch.R and DESCRIPTION  #
###############################

## ------------------------------------------------------------------------- ##
##                             GLOBAL VARIABLES                              ##
## ------------------------------------------------------------------------- ##

if (!exists('.orch.env') || 
    is.null(.orch.env$init))
{   
    # ORCH global settings.
    # Note: version # is set in orch-version.R file.
    .orch.env <- new.env()
    .orch.env$init <- FALSE
    .orch.env$dbcon.ok <- FALSE
    .orch.env$dbcon.host <- ''
    .orch.env$dbcon.port <- 1521
    .orch.env$dbcon.sid <- ''
    .orch.env$dbcon.user <- ''
    .orch.env$dbcon.passwd <- ''
    .orch.env$dbcon.secure <- FALSE
    .orch.env$dbcon.propf <- c()
    .orch.env$dbcon.mode <- 'cfg-auth'
    .orch.env$dbcon.drv <- ''
    .orch.env$hdfs.root <- '' # set @init
    .orch.env$hdfs.cwd <- '' # set @init
    .orch.env$hdfs.ok <- FALSE
    .orch.env$key.sep <- '\t' # default key separator
    .orch.env$val.sep <- ',' # default value separator
    .orch.env$hmr.ok <- FALSE
    .orch.env$debug <- TRUE
    .orch.env$devmode <- TRUE
    .orch.env$less.log <- TRUE
    .orch.env$keep.tmp <- TRUE
    .orch.env$dry.run <- FALSE
    .orch.env$dry.direct.io <- FALSE
    .orch.env$pack.src <- FALSE
    .orch.env$encr.str <- '' # set @init
    .orch.env$decr.str <- '' # set @init
    .orch.env$split.size <- 10*MB
    .orch.env$force.gc <- 10*MB
    .orch.env$tmp.path <- '/tmp'
    .orch.env$auth.path <- NULL # set @init
    .orch.env$files <- c() # rename to tmpfiles
    .orch.env$hdfs.tmpfiles <- c()
    .orch.env$pkg <- FALSE
    .orch.env$win <- FALSE
    .orch.env$mac <- FALSE
    .orch.env$has.ore <- FALSE
    .orch.env$sh.error <- 0
    .orch.env$sh.kill.code <- -73815
    .orch.env$fcat.threshold <- 10*KB
    .orch.env$sample.level <- 5
    .orch.env$standalone <- FALSE
    .orch.env$distro <- "unknown"
    .orch.env$whoami <- NULL
    .orch.env$base64.compress.threshold <- 1*KB
    .orch.env$base64.bzip2.threshold <- 10*KB
    .orch.env$base64.native <- FALSE
    .orch.env$ftail.max.download <- 100L*KB
    .orch.env$ftail.timeout <- 5
    .orch.env$hcache.ttl <- 300
    .orch.env$hcache.ctl <- 50
    .orch.env$mapred.upload.libs <- TRUE
    .orch.env$hcache <- list()
    .orch.env$digits <- 15
    #.orch.env$streaming.lib <- NULL # set @.orch.hsjar
}

## ------------------------------------------------------------------------- ##
##                        CORE PROTECTED FUNCTIONS                           ##
## ------------------------------------------------------------------------- ##

##
#' Searches for the home path for a module binary. The path is cached and will
#' be reused the next time the function is invoked. If the binary file can not
#' be located NULL will be cached and it will not try to locate it again.
#' Example: .orch.home('hadoop') -> ${HADOOP_HOME}
#'
#' @param name Name of the module.
#' @param env Environment variable with home path, default "<name>_HOME".
#' @param bin Executable subpath/name, default "/bin/<name>".
#' @param level How many level up home is relative to JAR location.
#' @param stop Abort execution if home directory is not identified.
#' 
#' @return Detected HOME path.
#' @return NULL if path was not found.
##
.orch.home <- function(
        name, 
        env, # optional
        bin,  # optional
        level = 1, 
        stop = FALSE)
{
    varName <- sprintf("%s.home", tolower(name))
    if (exists(varName, .orch.env)) {
        home <- get(varName, .orch.env)
    }
    else {
        # defaults
        if (missing(env)) {
            env <- sprintf("%s_HOME", toupper(name))
        }
        if (missing(bin)) {
            bin <- sprintf("/bin/%s", name)
        }
        
        # Try environment variable 1st.
        home <- Sys.getenv(env)
        if (home == '') {
            # Try "which" *nix command next.
            home <- .sh("which %s", name)
            if (.sh.match(home, "which: no")) {
                home <- NULL
                orch.dloge("can't find %s", name, stop=stop)
            }
            else {
                # strip out "/bin/<name>" from the path
                for (i in seq_len(level+1)) {
                    home <- dirname(home)
                }
            }
        }
        else {
            orch.dlog.debug("env:%s=%s", env, home)
        }
        
        # Cache for future references.
        assign(varName, home, .orch.env)
        orch.dlogv(varName, home, format="stored %s")
    }
    home
}

##
#' Searches for the home path to a module binary. The path is cached and will
#' be reused the next time the function is invoked. If the JAR file can not
#' be located NULL will be cached and it will not try to locate it again.
#' Example: .orch.jhome('OLH', jar="oraloader.jar") -> ${OLH_HOME}
#'
#' @param name Name of the module.
#' @param env Environment variable with home path, default "<name>_HOME".
#' @param bin Executable subpath/name, default "/bin/<name>".
#' @param level How many level up home is relative to JAR location.
#' @param stop Abort execution if home directory is not identified.
#' 
#' @return Detected HOME path.
#' @return NULL if path was not found.
##
.orch.jhome <- function(name, env, jar, level=1, stop=F)
{
    # Check cache 1st, don't search twice.
    cache.name <- sprintf("%s.home", tolower(name))
    if (exists(cache.name, .orch.env)) {
        home <- get(cache.name, .orch.env)
    }
    else {
        # Check environment variables first.
        if (missing(env)) {
            env <- sprintf("%s_HOME", toupper(name))
        }
        if (missing(jar)) {
            jar <- sprintf("%s.jar", name)
        }
        home <- Sys.getenv(env)
        if (home == '') {
            # Search in Java's CLASSPATH.
            home <- NULL
            paths <- c(Sys.getenv("HADOOP_CLASSPATH"), Sys.getenv("CLASSPATH"))
            paths <- unlist(strsplit(paths, ':'))
            if (length(paths) == 0) {
                orch.dlogw("CLASSPATH is not set in environment")
            }
            for (path in paths) {
                orch.dlog.debug("searching \"%s\"", path)
                f <- dir(path, pattern=jar)
                if (length(f) == 0) {
                    next
                }
                else if (length(f) > 1) {
                    orch.dlog.stop("multiple %s JARs (=%d) found at \"%s\"", 
                        name, length(f), path)
                    return (NULL)
                }
                else {
                    if (is.null(home)) {
                        home <- paste(path, f, sep='/')
                    }
                    else {
                        orch.dlogw("duplicate %s JAR found at \"%s\", ignored", 
                            name, path)
                    }
                }
            }
            if (!is.null(home)) {
                # strip "/jlib/<name>.jar" from the path
                for (i in seq_len(level+1)) {
                    home <- dirname(home)
                }
            }
        }
        # Cache for future references.
        assign(cache.name, home, .orch.env)
        orch.dlogv(cache.name, home, format="cached %s")
    }
    if (is.null(home)) {
        orch.dloge("can't find %s JAR", name, stop=stop)
    }
    home
}

##
#' Returns current user's OS name. The OS name is cached and will be reused 
#' the next time you invoke the function.
##
.orch.whoami <- function()
{
    # Check cache 1st, don't search twice.
    whoami <- .orch.env$whoami
    if (is.null(whoami)) {
        # Read user's name form OS.
        whoami <- .sh('whoami')
        .orch.env$whoami <- whoami
        orch.dlogv(.orch.env$whoami, format="cached %s")
    }
    whoami
}

##
#' Generates a new UID string. The returned ID is "guaranteed" to be unique 
#' within a session. Used for generating temporary HDFS and RDBMS object names.
##
.orch.uid <- function()
{
    substring(tempfile(pattern='orch', tmpdir=''), 2)
}

##
#' Generates a new temp file name. Temporary files are located in the local 
#' "/tmp/" mount by default. Used for data transfer between HDFS and R memory 
#' objects. All temp files generated via this interface will be automatically 
#' deleted at the end of ORCH session.
#'
#' @param path File path, by default uses global preset.
#' @param ext File extension, by default ''.
#' @param open Mode to open connection, none = don't open.
#' @param remove Delete temp file if already exists.
#' @return Temp file name or a connection object.
##
.orch.tmpfile <- function(
        path = .orch.env$tmp.path, 
        ext = '', 
        open = NULL,
        remove = FALSE)
{
    tmp <- paste(path, .orch.uid(), sep='/')
    if (!is.null(ext) && ext != '') {
        tmp <- paste(tmp, ext, sep='.')
    }
    .orch.env$files <- c(.orch.env$files, tmp)
    if (remove) {
        if (file.exists(tmp)) {
            .orch.unlink(tmp)
        }
    }
    if (!is.null(open)) {
        tmp <- .orch.open(tmp, open=open, secure=F)
    }
    tmp
}

##
#' Generates a new temp file name. Temporary files are located in the local 
#' "/tmp/" mount by default. Used for data transfer between HDFS and R memory 
#' objects. All temp files generated via this interface will be automatically 
#' deleted at the end of ORCH session.
#'
#' @param path File path, by default uses global preset.
#' @param ext File extension, by default ''.
#' @param open Mode to open connection, none = don't open.
#' @return Temp file name or a connection object.
##
.orch.tmphdfs <- function(path = .orch.env$tmp.path.hdfs)
{
    tmp <- paste(path, .orch.uid(), sep='/')
    .orch.env$hdfs.tmpfiles <- c(.orch.env$hdfs.tmpfiles, tmp)
    tmp
}

##
#' Cleans up temp files.
#' @TODO (vlad) clean up HDFS objects.
##
.orch.cleanup <- function()
{
    orch.dlog.info("removing local temporary files", cat=T)
    cnt <- 0
    for (f in .orch.env$files) {
        if (file.exists(f)) {
            .orch.unlink(f)
            cnt <- cnt + 1
        }
    }
    .orch.env$files <- c()
    orch.dlog.info("%d file%s removed", 
        cnt, ifelse(cnt > 1, "s", ""), cat=T)
    
    orch.dlog.info("removing HDFS temporary directories", cat=T)
    cnt <- 0
    for (f in .orch.env$hdfs.tmpfiles) {
        if (hdfs.exists(f)) {
            hdfs.rmdir(f, force=T)
            cnt <- cnt + 1
        }
    }
    .orch.env$hdfs.tmpfiles <- c()
    orch.dlog.info("%d HDFS director% removed", 
        cnt, ifelse(cnt > 1, "ies", "y"), cat=T)
}

##
#' Runs a generic shell commands. Accepts printf synrtax. Warnings get 
#' suppressed and no output messages are displayed. Client is responsible 
#' for parsing the output to identify errors.
#'
#' @param cmd command in printf format: "echo %s"
#' @param ... command line arguments
#' @param async Execute asychronously with
#' @param quiet don't log anything
#' @param noerr ignore stderr output
#' @return stdout (and stderr) output as a char vector.
##
.sh <- function(cmd, ...,
        async = FALSE, 
        nlines = -1, 
        quiet = FALSE, 
        noerr = FALSE)
{
    .assert(.orch.test.input(cmd, "character"))
    .assert(.orch.test.input(async, c("logical", "numeric")))
    .assert(.orch.test.input(nlines, "numeric"))
    .assert(.orch.test.input(quiet, "logical"))
    .assert(.orch.test.input(noerr, "logical"))
    
    # Put together command and arguments in command line.
    params <- list(...)
    if (length(params) == 0) {
        # no "..." arguments means "sprintf" call is obsolete and in some sense 
        # harmful. "sprintf" has 8K limit for its format string and if a client
        # passes a pre-formatted long commanf line to run it will error out.
        cmd <- strim(cmd)
    }
    else {
        if (nchar(cmd) > 8*KB) {
            orch.dlog.fatal("bug, command line format must be <8KB", stop=T)
        }
        cmd <- strim(
            do.call(sprintf, 
                append(cmd, list(...))
            ))
    }
    
    # Add error stream redirection.
    if (noerr) {
        # stderr->/dev/null
        cmdEx <- paste(cmd, '2>/dev/null')
    }
    else {
        # stderr->stdout
        cmdEx <- paste(cmd, '2>&1')
    }
    
    # Wrap in special shell for async execution.
    killCode <- .orch.env$sh.kill.code
    if (is.logical(async)) {
        if (async) {
            # simple async execution when we just let the process run in
            # background while returning its PID for future reference.
            resf <- .orch.tmpfile(remove=T)
            cmdEx <- paste(
                "(",cmdEx,"1>/dev/null) &",
                sprintf("echo ${!} 1>%s", resf))
            pid <- TRUE
        }
        else {
            # non-async (normal) execution when we wait until the command is
            # completed and return its output as a vector of strings.
            resf <- NULL
            pid <- FALSE
            cmdEx <- paste0(cmdEx, "; echo $?")
        }
    }
    else if (is.numeric(async)) {
        # semi-async mode, we run the command for a specific timeout and if
        # command is not yrt finished kill it returning its partial output
        # only as a vector of strings. 
        resf <- .orch.tmpfile(remove=T)
        cmdEx <- paste(
            "(",
                sprintf("%s 2>/dev/null;", cmdEx),
                sprintf("echo $? 1>%s", resf),
            ") &",
            "pid1=${!};",
            "(",
                sprintf("sleep %g;", async),
                "pkill -9 -P $pid1 2>/dev/null;", # kill forked PIDs
                "kill -9 $pid1 2>/dev/null;",     # kill sub-shell
                sprintf("echo %s 1>%s", killCode, resf),
            ") &",
            "pid2=${!};",
            "wait $pid1;",
            "kill -9 $pid2 2>/dev/null;")
        async <- TRUE
        pid <- FALSE
    }
    else {
        orch.dlog.fatal("bug", stop=T)
    }
    
    # Execute the system command.
    if (.orch.env$debug && !quiet) {
        orch.dlogsh(cmdEx, r=F)
    }
    out <- suppressWarnings(try(
        system(
            command = cmdEx, 
            intern = !pid,
            wait = T,
            ignore.stdout = async,
            ignore.stderr = async),
        silent=T))
    if (class(out) == 'try-error') {
        # sh nuked, the end
        orch.dlog.fatal('"%s" execution error', cmd)
        .orch.env$sh.error <- -100
        return (NULL)
    }
    
    # Extract auxiliary output from a sidecar file. This file is used in
    # async mode to separate output stream from error level stream and resolve
    # ambiguity of the "last line".
    aux <- character(0)
    if (!is.null(resf) && file.exists(resf)) {
        aux <- readLines(resf)
        file.remove(resf)
    }

    if (pid) {
        # we run the command in purely async mode and don't have any output
        # to return but we can return its PID, which was "echo"-ed in the
        # extended command's output.
        .orch.env$sh.error <- attr(out, "status")
        last <- length(aux)
        if (last != 1) {
            orch.dlog.fatal("unexpected result of async execution")
            RET <- -2
        }
        else {
            RET <- as.integer(out)
            if (is.na(RET)) {
                orch.dloge("non-PID result of async execution")
                RET <- -1
            }
            else {
                # asyn execution successful
                RET <- .make.pid(RET)
            }
        }
    }
    else {
        last <- length(out)
        if (async) {
            # This is a semi-async process which gets killed after a specified
            # timeout. Process output to stdout while error codes are written
            # to a sidecar file to distinguish error codes from data.
            if (length(aux) > 1) {
                orch.dlog.fatal("unexpected result of async execution")
                .orch.env$sh.error <- -1
                last %-=% 1
            }
            else if (length(aux) == 0 || aux == killCode) {
                orch.dlog.debug("process was killed")
                .orch.env$sh.error <- .orch.env$sh.kill.code
                last %-=% 1
            }
            else {
                orch.dlog.info("process has finished by itself")
                .orch.env$sh.error <- as.integer(aux)
            }
        }
        else {
            if (last > 0) {
                # command finised by itself and printed its error level in the very 
                # last output line, read the value and drop the error level line 
                # from the output.
                .orch.env$sh.error <- as.integer(out[last])
                last %-=% 1
            }
        }
        # trim output if required
        if (nlines == 0 || last <= 0) {
            RET <- ""
        }
        else if (nlines > 0) {
            RET <- out[1:min(nlines, last)]
        }
        else {
            RET <- out[1:last]
        }
        # fix EOL under cygwin
        if (.orch.env$win) {
            out <- gsub('\r$', '', out)
        }
    }
        
    if (.orch.env$debug && !quiet) {
        log <- out[out != '']
        if (length(log) > 0) {
            orch.dlogsh(log, r=T)
        }
    }
    
    # RETURN: text output or PID if async
    RET
}

##
#' Returns the last error code from .sh() command.
#' @example 
#'     .sh('nuke-me')
#'     .sh.error() == 127 # TRUE
##
.sh.error <- function()
{
    .orch.env$sh.error
}

##
#' Returns TRUE if the last shell command was run in async mode and it was
#' killed due to timeout. .sh.error() will be != 0 at this case too.
##
.sh.killed <- function()
{
    .orch.env$sh.error == .orch.env$sh.kill.code
}

##
#' Returns TRUE if [obj] object is shell's process ID.
#' 
#' @param obj Any R object.
#' @return TRUE if [obj] is a shell process ID.
##
.is.pid <- function(obj)
{
    is.numeric(obj) &&
    null.to(attr(obj, "orch.pid", exact=T), FALSE) && 
    obj > 0 && obj < 99999
}

##
#' Converts a number into PID object.
#' 
#' @param x A value.
#' @return A process ID object.
##
.make.pid <- function(x)
{
    attr(x, "orch.pid") <- TRUE
    .assert(.is.pid(x))
    x
}

##
#' Kills a running process with PID [pid]. PID is returned by .sh() function
#' when you run it with async=TRUE argument.
#' 
#' @param pid Process ID.
#' @return TRUE if killed successfully, FALSE if no such process of can't kill 
#'      it due to privileges (for instans attempt to kill a kernel).
##
.sh.kill <- function(pid)
{
    .assert(.orch.test.special(pid, "PID", .is.pid))
    out <- .sh("kill -9 %s", pid)
    if (.sh.error() != 0) {
        if (.sh.match(out, "No such process")) {
            orch.dlogw("no process with PID %d", pid)
        }
        else {
            orch.dloge("can't kill PID %d", pid)
        }
        FALSE
    }
    else {
        TRUE
    }
}

##
#' Checks the status of a process with process ID [pid].
#
#' @param pid Process ID.
#' @return TRUE if process is still running, FALSE if it was finished.
##
.sh.running <- function(pid)
{
    .assert(.orch.test.special(pid, "PID", .is.pid))
    .sh("(ps -eo pid | grep %d)", pid)
    .sh.error() == 0
}

##
#' Wait till the process with ID [pid] is finished. User can specify a [timeout]
#' in maximum number of second to wait. If process if not finished till the
#' timeout passed then wait is cancelled and FALSE is returned.
#'
#' @param pid Process ID.
#' @param timeout Maximim seconds to wait (default is infinite). 
#' @return TRUE if process if finihed, FALSE if it's still running.
##
.sh.wait <- function(pid, timeout=NULL)
{
    .assert(.orch.test.special(pid, "PID", .is.pid))
    .assert(.orch.ntest.input(timeout, "numeric"))
    
    if (is.null(timeout) || timeout == Inf) {
        timeout = FALSE
    }
    out <- .sh("wait %d", pid, async=timeout)
    if (.sh.killed()) {
        orch.dlogw("timeout waiting on PID %d", pid)
        FALSE
    }
    else if (.sh.error() != 0) {
        orch.dlogw("no process with PID %d", pid)
        FALSE
    }
    else {
        TRUE
    }
}    

##
#' Generic command execution gateway (e.g. CLI).
#' Examples: .sh.cmd('echo', a=1, 'z') ==> 'echo -a 1 "z"'.
#'     .sh.cmd('echo', a=c(1, 2)) ==> 'echo -a 1 -a 2'.
#'     .sh.cmd('echo', c(a=1, b=2)) ==> 'echo -a 1 -b 2'.
#'     .sh.cmd('echo', a=c(1, b=2, 3)) ==> 'echo -a 1 -b 2 -a 3'.
#'     .sh.cmd('echo', a=1, flags='!') ==> 'echo ! -a 1'.
#'
#' @param cmd A command.
#' @param ... Command options like (a=1, 2) => "-a 1 2".
#' @param flags String that gets appended to the command wihtout changes.
#' @param nlines Return only so many lines of the command output.
#' @param print Only print out the final command, do not execute.
#' @param noerr Ignore stderr output.
#' 
#' @return stdout + stderr output as a char vector.
##
.sh.cmd <- function(cmd, ..., 
        flags = '',
        async = FALSE, 
        nlines = -1, 
        print = FALSE, 
        noerr = FALSE)
{
    opts <- list(...)
    if (length(opts) > 0) {
        
        # "Unlist" command options, e.g. convert list(c(1,2)) -> list(1,2).
        # Also extracts value names from unlisted vectors and overrides list
        # element names, e.g. list(a=c(b=1)) -> list(b=1).
        opts2 <- list()
        for (i in 1:length(opts)) {
            opt <- opts[i]
            top.name <- names(opt)
            vals <- opt[[1]]
            if (is.null(vals)) {
                opts2 <- append(opts2, opt)
            }
            else {
                for (i in 1:length(vals)) {
                    val <- vals[i]
                    name <- names(val)
                    if (is.null(name) || name == '') {
                        names(val) <- top.name
                    }
                    opts2 <- append(opts2, val)
                }
            }
        }
        
        # Safe version of is.na(), works for NULL.
        .is.na <- function(x) {
            !is.null(x) && is.na(x)
        }
    
        # Now format a command list with names of options and their values as:
        # "-name value". Names prepended with "." are converted as "--name".
        opts <- opts2
        for (i in 1:length(opts)) {
            opt <- opts[i]
            val <- opt[[1]]
            name <- names(opt)
            cmd <- paste(strim(cmd),
                if (!is.null(name) && name != '' && 
                        !.is.na(val)) {
                    paste(' ',
                        if (begins(name, '.')) {
                            sprintf('--%s', substring(name,2))
                        } else {
                            sprintf('-%s', name)
                        },
                        sep='',
                        collapse='')
                },
                if (length(val) > 0 && !is.na(val)) {
                    paste(' ',
                        if (is.character(val)) {
                            .sh.string(val)
                        } else {
                            val
                        },
                        sep='',
                        collapse='')
                },
                sep='',
                collapse='')
        }
    }
    
    # Append extra flags if any.
    if (!is.null(flags) && flags != '') {
        cmd <- paste(strim(cmd), strim(flags), sep=' ')
    }
    
    # Run and return stdout/stderr.
    if (print) {
        print(cmd)
    }
    else {
        .sh(cmd = cmd,
            async = async, 
            nlines = nlines, 
            noerr = noerr)
    }
}

##
#' Converts a linux style path into current OS style path. Currenty it works
#' only for Windows+Cygwin and does nothing on other platforms.
#' Example: .sh.path('/home/oracle') -> "C:\cygwin\home\oracle"
##
.sh.path <- function(path)
{
    if (.orch.env$win) {
        path <- .sh('cygpath -pw "%s"', path, quiet=T)
    }
    path
}

##
#' Command line string utility. Encloses a string in "" if it contains an
#' illegal symbol(s) that may brake command like invokation. String in vectors
#' are processed independently.
##
.sh.string <- function(s)
{
    if (s == '') {
        s <- '""'
    }
    else {
        for (i in 1:length(s)) {
            if (grepl("[^A-z0-9_.=-]", s[i])) {
                s[i] <- sprintf('"%s"', s[i])
            }
        }
    }
    (s)
}

##
#' Matches shell command execution output with the expected answer.
#' Example: .sh.match('file copy failed', 'OK') -> FALSE
#'
#' @param out .sh()[.*] output, e.g. command result
#' @param ... expected regex pattern(s) to match to
#' @param any match any (T) or all (F) lines of the \p out
#'
#' @return TRUE if any (any=T) or all (defalut) lines are matched
#' @return FALSE \out does not match with expected pattern
##
.sh.match <- function(out, ..., any=F)
{
    # Make one regexp pattern for many given.
    pattern <- list(...)
    pattern <- paste(unlist(pattern), collapse='|')
    
    # Look for matches in every output line.
    for (out1 in out) {
        x <- regexpr(pattern, out1)
        ok <- length(x) > 0 && x[[1]] > 0
        if (ok) {
            if (any) {
                return (T)
            }
        }
        else {
            if (!any) {
                return (F)
            }
        }
    }
    # All TRUE or FALSE!
    (!any)
}

##
#' Detects path to Hadoop installation. This is done based on the environment
#' variables HADOOP_HOME and PATH once at the moment of the very first 
#' invocation of this function. All consequent invocation will retun the
#' last cached result.
#' 
#' @param stop Abort execution if Hadoop is not present
#' @return home directory where Hadoop is installed.
#' @return NULL if Hadoop can not be found.
##
.hadoop.path <- function(stop=F)
{
    .orch.home("hadoop", stop=stop)
}

##
#' Invokes generic "hadoop" CLI.
#' Example: .hadoop.sh('cmd', a=1, 'z') ==> 'hadoop cmd -a 1 "z"'.
#'
#' @param cmd Hadoop command (see hadoop help).
#' @param ... Command options like (a=1, 2) => "-a 1 2".
#' @param flags String that gets appended to the command wihtout changes.
#' @param nlines Return only so many lines of the command output.
#' @param print Only print out the final command, do not execute.
#' @param noerr Ignore stderr output.
#' 
#' @return stdout + stderr output as a char vector.
#' @seealso .sh
##
.hadoop.sh <- function(cmd, ..., flags='', nlines=-1, print=F)
{
    home <- .hadoop.path()
    cmd <- paste(home, '/bin/hadoop ', cmd, sep='')
    .sh.cmd(cmd, ..., 
        flags = flags, 
        nlines = nlines, 
        print = print)
}

##
#' Invokes Hadoop command line interface with simplified properties naming. 
#' Every parameter which name starts with "mr." will be converted to 
#' "-D oracle.hadoop.loader.*" style parameter for simplification.
#' 
#' @example 
#'     .hadoop.shD(mr.outputformat.class=myClass) # is the same as:
#'     .hadoop.sh(sprintf("-D mapreduce.outputformat.class=%s", myClass))
##
.hadoop.shD <- function(..., flags='', nlines=-1, print=F)
{
    input <- list(...)
    vars <- names(input)
    D <- sapply(seq_along(input), function(i) {
        v <- vars[i]
        if (begins(v, "mr.")) {
            v <- sub("^mr", "mapred", v)
            input[i] <<- sprintf("%s=%s", v, input[i])
            ("D")
        }
        else {
            (v)
        }})
    names(input) <- D
    orch.dlogv2(list(...), input)
    do.call(".hadoop.sh", c(input, 
        flags = flags, 
        nlines = nlines, 
        print = print))
}

##
#' Verifies that Hadoop CLI is installed.
#' @return TRUE if hadoop CLI has been found, otherwise FALSE.
##
.hadoop.check <- function()
{
    # Try a simple job list command on Hadoop.
    out <- .hadoop.sh('', nlines=1)
    ok <- length(out) > 0 && 
        .sh.match(out, "^Usage: hadoop.*$", any=T)
    (ok)
}

##
#' Rereives installed Hadoop's version.
#' @return Hadoop version number or NULL if Hadoop is not found.
##
.hadoop.version <- function()
{
    out <- .hadoop.sh('version')
    if (length(out) > 0) {
        ret <- sub('^Hadoop +([^ ]*)$', '\\1', out[1])
    }
    else {
        ret <- NULL
    }
    (ret)
}

##
#' Default simple ROT18 string encryption placeholder.
#' Replaced with strong encryption implementation (AES/DES).
##
.orch.encrypt <- function(string)
{
    chartr(
        old = .orch.env$encr.str, 
        new = .orch.env$decr.str, 
        x = string)
}

##
#' Default simple ROT18 string decryption placeholder.
#' Replaced with strong encryption implementation (AES/DES).
##
.orch.decrypt <- function(string)
{
    chartr(
        old = .orch.env$decr.str, 
        new = .orch.env$encr.str, 
        x = string)
}

##
#' Return the home directory of the current user.
#' @param subdir add sub-directory to the home path (optional)
##
.user.home <- function(subdir)
{
    path <- Sys.getenv('HOME')
    if (!missing(subdir)) {
        path <- sprintf('%s/%s', path, subdir)
        if (!file.exists(path)) {
            dir.create(path)
        }
    }
    if (!file.exists(path)) {
        orch.dlog.stop('can\'t access "%s"', path)
        path <- NULL
    }
    path
}

##
#' Converts a R vector data type into keyVal representation with all 
#' neccessary meta attributes. Can also insert rownames() of the data.frame
#' as a part of keyVal structure (as 1st column) with the specified name
#' \p rownames. By default rownames are not stored in keyVal output. If matrix
#' has no row names then "" will be exported to keyVal. 
#' 
#' @param obj is the data
#' @param keyi is the key index, 0=empty key, -1=no key at all
#' @param rowname is the name of rownames(x) extra column
##
.vector.as.keyvals <- function(
        obj, 
        keyi = -1, 
        rownames = FALSE)
{
    .assert(is.list(obj) || is.vector(obj))
    .assert(is.logical(rownames) || is.character(rownames))
    .assert(keyi >= -1)
    
    # Convert into list of keyval objects.
    if (is.logical(rownames) && !rownames) {
        rownames <- NULL
        kvs <- lapply(1:length(obj), 
            function(n) .make.keyval(list(val1=obj[[n]]), i=keyi)
        )
        # dont' adjust keyval metadata
        rn.i <- 0      # no rowname index
        rn.t <- c()    # no rowname type
        rn.d <- c(0,0) # no rowname dim
    }
    else {
        # default name of rowname column
        if (is.logical(rownames) && rownames) {
            rownames <- "ORCH:ROWNAME"
        }
        # mix in value names into keyvals
        r <- as.character(names(obj))
        if (length(r) == 0) {
            r <- rep('', length(obj))
        }
        kvs <- lapply(1:length(obj), 
            function(n) {
                col <- as.list(r[n])
                names(col) <- rownames
                .make.keyval(append(list(val1=obj[[n]]), col), i=keyi)
            })
        # adjust keyval metadata
        rn.i <- 2           # rowname @ col 1
        rn.t <- "character" # rowname is a str
        rn.d <- c(0,1)      # rowname adds 1 col
    }
    
    # Store metadata for back conversion.
    attr(kvs, 'orch.kvs') <- TRUE
    attr(kvs, 'orch.names') <- c("val", rownames)
    attr(kvs, 'orch.class') <- "vector"
    attr(kvs, 'orch.types') <- c(class(obj), rn.t)
    attr(kvs, 'orch.dim') <- c(length(obj), 1) + rn.d
    attr(kvs, 'orch.keyi') <- keyi
    attr(kvs, 'orch.rownamei') <- rn.i
    attr(kvs, 'orch.trim') <- FALSE
    
    # All good.
    .assert(.is.keyvals(kvs))
    kvs
}

##
#' Converts an R matrix data type into keyVal representation with all 
#' neccessary meta attributes. Can also insert rownames() of the data.frame
#' as a part of keyVal structure (as 1st column) with the specified name
#' \p rownames. By default rownames are not stored in keyVal output. If matrix
#' has no row names then "" will be exported to keyVal.
#' 
#' @param x is the data
#' @param i is the key index, 0=empty key, -1=no key at all
#' @param rowname is the name of rownames(x) extra column
##
.matrix.as.keyvals <- function(
        obj, 
        keyi = -1, 
        rownames = FALSE)
{
    .assert(is.matrix(obj) || is.data.frame(obj))
    .assert(is.logical(rownames) || is.character(rownames))
    .assert(keyi >= -1)
    
    # Convert into list of keyval objects.
    if (is.logical(rownames) && !rownames) {
        # leave row names out of keyvals
        rownames <- c() 
        kvs <- lapply(1:dim(obj)[1], 
            function(n) {
                .make.keyval(as.list(obj[n,]), i=keyi)
            }
        )
        # dont' adjust keyval metadata
        rn.i <- 0      # no rowname index
        rn.t <- c()    # no rowname type
        rn.d <- c(0,0) # no rowname dim
    }
    else {
        # default name of rowname column
        if (is.logical(rownames) && rownames) {
            rownames <- "ORCH:ROWNAME"
        }
        # mix in row names into keyvals
        r <- as.character(rownames(obj))
        if (length(r) == 0) {
            r <- rep('', dim(obj)[1])
        }
        kvs <- lapply(1:dim(obj)[1], 
            function(n) {
                col <- r[n]
                names(col) <- rownames
                .make.keyval(append(as.list(obj[n,]), col), i=keyi)
            })
        # adjust keyval metadata
        rn.i <- dim(obj)[2]+1 # rowname @ col 1
        rn.t <- "character"   # rowname is a str
        rn.d <- c(0,1)        # rowname adds 1 col
    }
    
    # Store metadata for back conversion.
    attr(kvs, 'orch.kvs') <- TRUE
    attr(kvs, 'orch.names') <- c(colnames(obj), rownames)
    attr(kvs, 'orch.class') <- class(obj)
    attr(kvs, 'orch.types') <- c(unlist(lapply(obj[1,], class), use.names=F), rn.t)
    attr(kvs, 'orch.dim') <- dim(obj) + rn.d
    attr(kvs, 'orch.keyi') <- keyi
    attr(kvs, 'orch.rownamei') <- rn.i
    attr(kvs, 'orch.trim') <- FALSE
    
    # All good.
    .assert(.is.keyvals(kvs))
    kvs
}

##
#' Converts an R data.frame data type into keyVal representation with all 
#' neccessary meta attributes. Can also insert rownames() of the data.frame
#' as a part of keyVal structure (as 1st column) with the specified name
#' \p rownames. By default rownames are not stored in keyVal output.
#' 
#' @param obj is the data
#' @param keyi is the key index, 0=empty key, -1=no key at all
#' @param rowname is the name of rownames(x) extra column
#' 
#' @seealso .list.as.keyvals
##
.data.frame.as.keyvals <- function(
        obj, 
        keyi = -1, 
        rownames = FALSE)
{
    # Check inputs.
    .assert(is.data.frame(obj))
    .assert(keyi >= -1)
    
    # Matrix convertion perfectly works for data.frame too.    
    .matrix.as.keyvals(obj, keyi, rownames)
}

##
#' Converts a R list data type into keyVal representation with all 
#' neccessary meta attributes. Note that lists are not natively supported
#' and are converted to data.frame with two columns: val = string values of
#' the list and type = type name of each value.  
#' 
#' @param obj is the data
#' @param key is the key index, 0=empty key, -1=no key at all
#' @param rowname is the name of rownames(x) extra column
#' 
#' @seealso .data.frame.as.keyvals
##
.list.as.keyvals <- function(
        obj, 
        keyi = -1,
        rownames = F)
{
    # Check inputs.
    .assert(is.list(obj))
    .assert(keyi >= -1)
    
    
    df <- data.frame(val=unlist(obj), type=unlist(lapply(obj, class)))
    kvs <- .matrix.as.keyvals(df, keyi, rownames)
    attr(kvs, 'orch.class') <- "list"
    (kvs)
}

##
#' Converts any R data type into keyVal representation with all neccessary
#' meta attributes. This is an R representation of Hadoop key-value data type 
#' and used as an intermediate storage when moving data between R and HDFS.
#' Note that it's better to call .<data_type>.as.keyvals() directly.
##
.any.as.keyvals <- function(x, i=0, rownames=F)
{
    if (is.matrix(x)) {
        .matrix.as.keyvals(x, i, rownames)
    }
    else if (is.data.frame(x)) {
        .data.frame.as.keyvals(x, i, rownames)
    }
    else if (is.list(x)) {
        .list.as.keyvals(x, i, rownames)
    }
    else {
        .vector.as.keyvals(x, i, rownames)
    }
}

##
#' Converts a set of key-values into a data.frame restoring all its original
#' attributes. Note that for to be able to restore attributes they must be
#' stored as ORCH meta attributes along with the [kvs] object.
#' 
#' @param kvs Key-values as a list with ORCH meta attributes.
#' @return A data.frame or NULL if input \p kvs value can't be converted.
##
.keyvals.as.data.frame <- function(kvs)
{
    if (.is.keyvals(kvs))
    {
        # extract metadata as list for easier access in the code
        meta <- attributes(kvs)
        
        # keyi identifies the existance and original position of key column.
        # If keyi == 0 -> key is empty, if keyi == -1, key is absent.
        keyi <- meta$orch.keyi
        if (!is.null(keyi)) {
            keyi <- as.numeric(keyi)
            orch.dlog.debug('key field = %d', keyi)
        }
        else {
            keyi <- -1
            orch.dlog.warning('"keyi" meta field is missing, using -1')
        }
        
        # Detect dimensions of the input keyValue dataset. Note that the set
        # might be empty, e.g. we can't use its data to detect # of columns.
        # Also number of rows can differ from meta "orch.dim" if its a sampled
        # parts of the original dataset.
        rown <- length(kvs)
        coln <- length(meta$orch.types)
        orch.dlog.debug('dim(kvs) = %d x %d', rown, coln)
        
        # Verify consistency of dimensional metadata. It's not fatal if the 
        # data does not pass validation but still worth logging in.
        if (orch.dblock.warning())
        {
            mdim <- meta$orch.dim
            if (!is.null(mdim)) {
                if (mdim[1] != rown && mdim[1] != -1) {
                    orch.dlogw('meta:orch.dim:rows=%d != %d', mdim[1], rown)
                }
                if (mdim[2] != coln) {
                    orch.dloge('meta:orch.dim:cols=%d != %d', mdim[2], coln)
                }
            }
        }
        
        # I don't know how to nicely write multi-type list conversion to data 
        # frame so for now I'll just put together something ugly. Usage of 
        # matrix speeds up convertion quite nicely.
        cols <- matrix(ncol=coln, nrow=rown)
        i <- 1
        valn <- coln - ifelse(keyi>0,1,0)
        if (meta$orch.trim) {
            kvs <- lapply(kvs, function(x) {
                x$val <- x$val[seq_len(valn)]
                x
            })
        }
        for (x in kvs) {
            if (keyi > 0) {
                cols[i,1] <- x$key
                j <- 2
            }
            else {
                j <- 1
            }
            if (length(x$val) != valn) {
                orch.dlog.stop("wrong number of values at row#%d: %d != %d", 
                    i, length(x$val), valn)
            }
            for (v in x$val) {
                if (is.factor(v)) {
                    v <- as.character(v)
                }
                cols[i,j] <- v
                j <- j+1
            }
            i <- i+1
        }
        
        # "Raw" version of data frame.
        raw_df <- as.data.frame(cols)
        odf <- .apply.meta.data.frame(raw_df, meta, ifelse(keyi==0, -1, keyi))
        
        # "cols", "kvs", "input" objects might be large, try to keep memory 
        # usage as low as possible. Not sure this is very helpful though.
        if (object.size(cols) > .orch.env$force.gc) {
            orch.dlog.trace("enforcing garbage collector on cols=%s",
                mem2str(object.size(cols)))
            rm(cols)
            gc()
        }
        if (object.size(kvs) > .orch.env$force.gc) {
            orch.dlog.trace("enforcing garbage collector on kvs=%s",
                mem2str(object.size(cols)))
            rm(kvs)
            gc()
        }
        if (object.size(raw_df) > .orch.env$force.gc) {
            orch.dlog.trace("enforcing garbage collector on raw_df=%s",
                mem2str(object.size(raw_df)))
            rm(raw_df)
            gc()
        }
        
        # Conversion is done.
        odf
    }
    else if (is.data.frame(kvs)) {
        # nothing to do
        orch.dlog.debug('already a data.frame')
        kvs
    }
    else {
        orch.dlog.stop("unsupported input data type")
        NULL
    }
}

##
#' This function just applies ORCH metadata to an already loaded data.frame.
#' This will restore all the names (column and row), data types, attributes,
#' etc. of the original data.frame.
#' 
#' @param odf A "raw" data frame ready metadate recovery. Attention: must not 
#'     include an empty key column (if keyi=0).
#' @param meta Metadata to apply to the "raw" data frame.
#' @param keyi Key column index.
#' @return Restored from ORCH meta attributes data frame.
##
.apply.meta.data.frame <- function(odf, meta, keyi)
{
    # keyi identifies the existance and original position of key column.
    # If keyi == 0 -> key is empty, if keyi == -1, key is absent.
    if (missing(keyi)) {
        keyi <- meta$orch.keyi
        if (!is.null(keyi)) {
            keyi <- as.numeric(keyi)
            orch.dlog.debug('key field = %d', keyi)
        }
        else {
            keyi <- -1
            orch.dlog.warning('"keyi" meta field is missing, using -1')
        }
    }
    
    # Read and correct data dimensions.
    dfsTrim <- null.to(meta$orch.trim, FALSE)
    dfsColn <- null.to(meta$orch.dim[2], length(meta$orch.types))
    if (keyi == 0) {
        # keyi=0 means 1st column is an extra "" key
        dfsColn <- dfsColn + 1
    }
    rown <- nrow(odf)
    coln <- ncol(odf)
    orch.dlog.debug('dim(odf) = %d x %d', rown, coln)
    if (coln > dfsColn && dfsTrim) {
        odf <- odf[seq_len(dfsColn)]
        orch.dlogw("dropped %d tailing columns", coln-dfsColn)
        coln <- dfsColn
    }
    else if (coln != dfsColn) {
        orch.dloge("expected %d but got only %d column%s",
            dfsColn, coln, .s(coln), stop=T)
    }
    
    # Swap columns to re-position key columns.
    # This is required in case non-standard key column.
    if (keyi > 1) {
        if (keyi < coln) {
            odf <- odf[,c(
                2:keyi,
                1,
                (keyi+1):coln)]
        }
        else {
            odf <- odf[,c(
                2:coln,
                1)]
        }
    }
    else if (keyi == 0) {
        odf <- odf[-1]
    }
    
    .assert(coln == dim(odf)[2])
    rown <- dim(odf)[1]
    
    # Restore column names from meta attributes.
    names <- meta$orch.names
    if (!is.null(names)) {
        n <- length(names)
        if (coln == n) {
            if (n > 100) {
                # limit log size
                orch.dlog.debug('names{%d} = c(%s, ... {%g more value%s})',
                    n, toString(names[1:100]), n-100, .s(n-100))
            }
            else {
                orch.dlog.debug('names{%d} = c(%s)',
                    n, toString(names))
            }
            colnames(odf) <- names
        }
        else {
            # number of columns *must* match with meta data otherwise
            # it's a bug or data is corrupted. Rise an error.
            orch.dloge('names[%d] meta != data cols[%d], aborting', 
                n, coln, stop=T)
        }
    }   
    else {
        orch.dlog.debug('"names" meta is missing')
        if (keyi < 1) {
            # by default columns names "val1,val2..."
            names <- paste('val', 1:coln, sep='')
        }
        else {
            # by default columns names "key,val1..."
            names <- c()
            if (keyi > 1) {
                for (i in 1:(keyi-1)) {
                    n <- paste('val', i, sep='')
                    names <- c(names, n)
                }
            }
            names <- c(names, 'key')
            if (keyi < coln) {
                for (i in keyi:(coln-1)) {
                    n <- paste('val', i, sep='')
                    names <- c(names, n)
                }
            }
        }
        colnames(odf) <- names
    }
    
    # Restore column data types.
    types <- meta$orch.types
    n <- length(types)
    if (n > 100) {
        # limit log size
        orch.dlog.debug('types{%d} = c(%s, ... {%g value%s})',
            n, toString(types[1:100]), n-100, .s(n-100))
    }
    else {
        orch.dlog.debug('types{%d} = c(%s)', 
            n, toString(types))
    }
    drops <- c()
    for (i in 1:coln) {
        vt <- types[i]
        if (class(odf[[i]]) == vt) {
            # no need to convert
            next
        }
        if (vt == "character") {
            vec <- as.character(odf[[i]])
        }
        else if (vt == "factor") {
            vec <- as.factor(odf[[i]])
        }
        else if (vt == "numeric") {
            vec <- as.numeric.str(odf[[i]])
        }
        else if (vt == "integer") {
            vec <- as.integer.str(odf[[i]])
        }
        else if (vt == "logical") {
            vec <- as.logical(odf[[i]])
        }
        else if (vt == 'NULL') {
            orch.dlogd('dropping col #%d', i)
            drops <- c(drops, i)
            next
        }
        else {
            # metadata is screwed up most likely
            orch.dlog.stop("unknow type \"%s\"", vt)
        }
        odf[[i]] <- vec
    }
    if (length(drops) > 0) {
        odf <- subset(odf, select=-drops)
    }
    
    # And now restore row names of the data frame if they where stored
    # as an exta column in keyVal strucutre. Otherwise row names will be
    # just indexes 1:n.        
    rni <- meta$orch.rownamei
    if (is.null(rni)) {
        # optinal meta field, ignoring error
        orch.dlogw('"rownames" meta is missing')
    }
    else if (rni > 0 && !(rni %in% drops)) {
        rownames <- odf[[rni]]
        n <- length(rownames)
        if (n > 100) {
            # limit log size
            orch.dlog.debug('rownames{%d} = c(%s, ... {%g value%s})', 
                n, toString(rownames[1:100]), n-100, .s(n-100))
        }
        else {
            orch.dlog.debug('rownames{%d} = c(%s)', 
                n, toString(rownames))
        }
        odf <- odf[-rni]
        rownames(odf) <- rownames
    }
    else {
        orch.dlog.debug("no rownames stored with data")
    }
    
    # All good.
    odf
}

##
#' Converts a set of key-values into a matrix restoring all its original
#' attributes. Note that for to be able to restore attributes they must be
#' stored as ORCH meta attributes along with the [kvs] object.
#' 
#' @param kvs Key-values as a list with ORCH meta attributes.
#' @return A matrix or NULL if input \p kvs value can't be converted.
##
.keyvals.as.matrix <- function(kvs)
{
    .assert(attr(kvs, "orch.class") == "matrix" ||
            attr(kvs, "orch.class") == "vector" )
    
    if (.is.keyvals(kvs))
    {
        # extract metadata as list for easier access in the code
        meta <- attributes(kvs)
        
        # keyi identifies the existance and original position of key column.
        # If keyi == 0 -> key is empty, if keyi == -1, key is absent.
        keyi <- meta$orch.keyi
        if (!is.null(keyi)) {
            keyi <- as.numeric(keyi)
            orch.dlog.debug('key field = %d', keyi)
        }
        else {
            keyi <- -1
            orch.dlog.warning('"keyi" metafield is missing')
        }
        rown <- length(kvs)
        coln <- length(kvs[[1]]$val)
        if (keyi > 0) {
            coln <- coln + 1
        }
        orch.dlog.debug('kvs dim = %d x %d', rown, coln)
        
        # Restore the matrix from keyval.
        tab <- do.call(rbind, lapply(kvs, unlist))
        if (keyi == 0) {
            tab <- tab[,-1]
            if (is.vector(tab)) {
                    tab <- as.matrix(tab)
            }
        }
        valn <- coln - ifelse(keyi>0,1,0)
        if (meta$orch.trim) {
            tab <- tab[,1:valn]
        }
        .assert(rown == dim(tab)[1])
        .assert(coln == dim(tab)[2])
        
        # Swap columns to re-position key columns.
        # This is required in case non-standard key column.
        if (keyi > 1) {
            if (keyi < coln) {
                tab <- tab[,c(
                    2:keyi,
                    1,
                    (keyi+1):coln)]
            }
            else {
                tab <- tab[,c(
                    2:coln,
                    1)]
            }
        }
        
        # Restore column names from meta attributes.
        names <- meta$orch.names
        if (!is.null(names)) {
            n <- length(names)
            if (coln == n) {
                if (n > 100) {
                    # limit log size
                    orch.dlog.debug('names[%d] = %s, ...', n,
                        paste(names[1:100], collapse=','))
                }
                else {
                    orch.dlog.debug('names[%d] = %s', n, 
                        paste(names, collapse=','))
                }
                colnames(tab) <- names
            }
            else {
                # number of columns *must* match with meta data otherwise
                # it's a bug or data is corrupted. Rise an error.
                orch.dloge('names[%d] meta != data cols[%d], aborting', 
                    n, coln, stop=T)
            }
        }   
        else {
            orch.dlog.debug('"names" meta is missing')
            if (keyi < 1) {
                # by default columns names "val1,val2..."
                names <- paste('val', 1:coln, sep='')
            }
            else {
                # by default columns names "key,val1..."
                names <- c()
                if (keyi > 1) {
                    for (i in 1:(keyi-1)) {
                        n <- paste('val', i, sep='')
                        names <- c(names, n)
                    }
                }
                names <- c(names, 'key')
                if (keyi < coln) {
                    for (i in keyi:(coln-1)) {
                        n <- paste('val', i, sep='')
                        names <- c(names, n)
                    }
                }
            }
            colnames(tab) <- names
        }
        
        # And now restore row names of the data frame if they where stored
        # as an exta column in keyVal strucutre. Otherwise row names will be
        # just indexes 1:n.        
        rni <- meta$orch.rownamei
        if (rni > 0) {
            rownames <- tab[,rni]
            n <- length(rownames)
            if (n > 100) {
                # limit log size
                orch.dlog.debug('rownames[%d] = %s, ...', n,
                    paste(rownames[1:100], collapse=','))
            }
            else {
                orch.dlog.debug('rownames[%d] = %s', n,
                    paste(rownames, collapse=','))
            }
            tab <- subset(tab, select=-rni)
            rownames(tab) <- rownames
        }
        else {
            # optinal meta field, ignoring error
            orch.dlogw('"rownames" meta is missing')
        }
        
        # Restore data types.
        types <- meta$orch.types
        if (rni > 0) {
            types <- types[-rni]
        }
        if (any(types[1] != types)) {
            orch.dlog.stop("matrix types are not equal")
        }
        vt <- types[1]
        orch.dlog.debug('type = %s', vt)
        if (class(tab[1]) != vt) {
            if (vt == 'character') {
                vec <- as.character(tab)
            }
            else if (vt == 'factor') {
                vec <- as.factor(tab)
            }
            else if (vt == 'numeric') {
                vec <- as.numeric.str(tab)
            }
            else if (vt == 'integer') {
                vec <- as.integer.str(tab)
            }
            else if (vt == 'logical') {
                vec <- as.logical(tab)
            }
            else {
                # metadata is screwed up most likely
                orch.dlog.stop("unknow type \"%s\"", vt)
            }
            attributes(vec) <- attributes(tab)
            tab <- vec
        }
    }
    else if (is.matrix(kvs)) {
        # nothing to do
        orch.dlog.debug('already a matrix')
        tab <- kvs
    }
    else {
        orch.dlog.stop("unsupported input data type")
        tab <- NULL
    }
    
    # All done, people.
    .assert(is.matrix(tab))
    tab
}

##
#' Converts a set of key-values into a list restoring all its original
#' attributes and types. Note that for to be able to restore attributes they 
#' must be stored as ORCH meta attributes along with the [kvs] object.
#' 
#' @param kvs Key-values as a list with ORCH meta attributes.
#' @return A list or NULL if input \p kvs value can't be converted.
##
.keyvals.as.list <- function(kvs)
{
    # Only lists can be converted by this function.    
    .assert(attr(kvs, "orch.class") == "list")
    
    # We can reuse keyval to data.frame convertion code as it stored as "special" 
    # data.frames in HDFS. Resulting data.frame has only one data column and an 
    # auxiliary type column for back transformation.
    df <- .keyvals.as.data.frame(kvs)
    .assert(dim(df)[2] == 2)
    l <- Map(as.vector, df[[1]], as.character(df[[2]]))
    if (attr(kvs, "orch.rownamei") > 0) {
        names(l) <- rownames(df)
    }
    l
}

##
#' Converts a set of key-values into a vector restoring all its original
#' attributes and types. Note that for to be able to restore attributes they 
#' must be stored as ORCH meta attributes along with the [kvs] object.
#' 
#' @param kvs Key-values as a list with ORCH meta attributes.
#' @return A list or NULL if input \p kvs value can't be converted.
##
.keyvals.as.vector <- function(kvs)
{
    # Only vector can be converted by this function.    
    .assert(attr(kvs, "orch.class") == "vector")
    
    # We reuse matrix keyVal converter code as it's quite similar. Resulting 
    # matrix has only one row and binary compatible with vector.
    tab <- .keyvals.as.matrix(kvs)
    .assert(dim(tab)[2] == 1)
    v <- as.vector(tab)
    names(v) <- rownames(tab)
    v
}

##
#' Converts a keyVal object into the original R data type. Note that for to be 
#' able to restore attributes they must be stored as ORCH meta attributes along 
#' with the [kvs] object.
#' 
#' @attention It's better to call .keyvals.as.<data_type>() directly to avoid 
#'     switching between data types based on meta attributes.
#' 
#' @param kvs Key-values as a list with ORCH meta attributes.
#' @return An R object or NULL if input \p kvs value can't be converted.
##
.keyvals.as.any <- function(kvs)
{
    class <- attr(kvs, "orch.class", exact=T)
    if (class == "matrix") {
        .keyvals.as.matrix(kvs)
    }
    else if (class == "data.frame") {
        .keyvals.as.data.frame(kvs)
    }
    else if (class == "list") {
        .keyvals.as.list(kvs)
    }
    else if (class == "vector") {
        .keyvals.as.vector(kvs)
    }
    else {
        orch.dlog.stop("unknown data type", cat=T)
    }
}

##
#' Just creates an empty keyVal object with meta attributes for the specified
#' R object. This is a lightweight alternative to .any.as.keyval() function.
#' 
#' @param x R object to extract attributes from.
#' @param i Key column index
#' @param rownames
#' @return 
##
.get.meta <- function(x, i=0, rownames=FALSE)
{
    # Sample one row of the data to construct a "dummy" keyVal object
    # and extract metadata only. Metadata if fairly specific for each of
    # the input R type and it's better to reuse *.as.keyvals code.
    if (is.data.frame(x)) {
        kv <- .data.frame.as.keyvals(x[1,,drop=F], i, rownames)
        attr(kv, "orch.dim") <- attr(kv, "orch.dim") + c(dim(x)[1]-1, 0) 
    }
    else if (is.matrix(x)) {
        kv <- .matrix.as.keyvals(x[1,,drop=F], i, rownames)
        attr(kv, "orch.dim") <- attr(kv, "orch.dim") + c(dim(x)[1]-1, 0) 
    }
    else if (is.list(x)) {
        kv <- .list.as.keyvals(x[1], i, rownames)
        attr(kv, "orch.dim") <- attr(kv, "orch.dim") + c(length(x)-1, 0) 
    }
    else {
        kv <- .vector.as.keyvals(x[1], i, rownames)
        attr(kv, "orch.dim") <- attr(kv, "orch.dim") + c(length(x)-1, 0) 
    }
    
    # Now create an empty list with copy of the metadata just extracted.
    # This step can be dropped but kept for consistency (for now).
    meta <- list()
    attributes(meta) <- attributes(kv)
    meta
}

##
#' Converts a set of lines into keyVal structure.
#' 
#' @param key.sep key field separator character, "\t" default
#' @param val.sep value field separator character, "," default
##
.parse.keyval <- function(lines, key.sep, val.sep)
{
    .assert(val.sep != '')
    orch.dlogp(key.sep, val.sep)
    kvs <- lapply(lines,
        function(line) {
            if (key.sep != '') {
                line <- strsplit.one(line, key.sep, fixed=T)[[1]]
            }
            if (length(line) > 1) {
                key <- line[1]
                val <- strsplit.eol(line[2], val.sep, fixed=T)[[1]]
            }
            else {
                key <- NULL
                val <- strsplit.eol(line[1], val.sep, fixed=T)[[1]]
            }
            .make.keyval(
                key = key, 
                val = val)
        })
}

##
#' Returns TRUE if \p kvs is the result of .as.keyvals.
#' Example: .is.keyvals(.as.keyvals(cars)) == TRUE
##
.is.keyvals <- function(kvs)
{
    ret <- TRUE
    if (!is.list(kvs)) {
        ret <- FALSE
    }
    else {
        type <- attr(kvs, 'orch.kvs', exact=T)
        if (is.null(type) || !type) {
            ret <- FALSE
        }
    }
    (ret)
}
