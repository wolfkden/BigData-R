#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: lmf_jellyfish.R
#     Description: Demonstrates the main APIs related to the 
#                  LMF model fit using the "Jellyfish" based 
#                  algorithm, i.e. an "orch.lmf.jellyfish" model.
#
#

# Create a directory for this demo and set that as root
currroot <- hdfs.root()
hdfs.setroot("/tmp")
demoname <- "lmf_jellyfish"
newdir <- hdfs.mkdir(file.path("/", demoname))
hdfs.setroot(newdir)

## Setup the input (user, item, rating) entries
u <- sample(1:100, 300, replace=TRUE)
i <- sample(1:10, 300, replace=TRUE)
ui <- unique(cbind(u,i))
r <- sample(1:5, nrow(ui), replace=TRUE)
input <- cbind(ui,r)

# Fit an "orch.lmf.jellyfish" model
fit <- orch.lmf(input, latin=2, iterations=5, rank=3)
print(fit)

# Evaluate this "orch.lmf.jellyfish" model 
se.fit <- orch.evaluate(fit, fit$inputDir)
se.fit

# Export the model into R data frames
lr <- orch.export.fit(fit)
dim(lr$L)
dim(lr$R)

# Get the input on which predictions are desired
# This is a subset of u and subset of i used in the training data set
up <- sample(u, 10, replace=TRUE)
ip <- sample(i, 10, replace=TRUE)
pred.input <- cbind(up, ip)  

# Make the prediction using the orch.lmf.jellyfish model
pred.results <- predict(fit, newdata=pred.input)

# Get the predictions into R and display
preddf <- hdfs.get(hdfs.attach(pred.results$outputDir))
pj <- as.matrix(preddf)
pj

# Cleanup after the demo
hdfs.setroot("/tmp")
hdfs.rmdir(newdir, force=TRUE)
hdfs.setroot(currroot)

