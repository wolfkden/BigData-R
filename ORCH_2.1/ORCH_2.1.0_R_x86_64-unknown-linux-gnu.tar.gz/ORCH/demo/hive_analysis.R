#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_analysis.R
#     Description: Demonstrates basic analysis & data processing operations
#     The setup of a HIVE table is repeated in each script
#
#

## Set page width
options(width = 80)

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

#create a copy of the iris dataset
iris_temp <- iris

## ORCH-HIVE  does not support factors yet, convert the factor columns to 
## character
factfilt <- sapply(iris_temp, is.factor)
iris_temp[factfilt] <- data.frame(lapply(iris_temp[factfilt], as.character),
                                    stringsAsFactors = FALSE)

# Push the iris_temp data frame to HIVE
IRIS_TABLE <- ore.push(iris_temp)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Number of unique specifies
length(unique(iris_temp$Species))
length(unique(IRIS_TABLE$Species))

# What are the unique Species ?
unique(iris_temp$Species)
unique(IRIS_TABLE$Species)

# Count of observations with Species = "setosa"
nrow(iris_temp[iris_temp$Species == "setosa", ])
nrow(IRIS_TABLE[IRIS_TABLE$Species == "setosa", ])

# Count of rows where Species == "setosa" and Petal.Width=0.3
# Notice the use of a single & to represent a conjunction (AND)
nrow(iris_temp[iris_temp$Species == "setosa" & iris_temp$Petal.Width == 0.3, ])
nrow(IRIS_TABLE[IRIS_TABLE$Species == "setosa" &
                IRIS_TABLE$Petal.Width == 0.3, ])

# Exclude observations with Petal.Width > 0.3
iris_temp_new = iris_temp[iris_temp$Petal.Width <= 0.3, ]
nrow(iris_temp_new)
class(iris_temp_new)

# On an ore.frame the result is just a logical query
iris_temp_new = IRIS_TABLE[IRIS_TABLE$Petal.Width <= 0.3, ]
nrow(iris_temp_new)

# Look at the class of iris_temp_new to confirm that it is indeed
# a logical query
class(iris_temp_new)

# Missing is NA in R.
# Lets count observations where Petal.Length is missing
#

nrow(iris_temp[is.na(iris_temp$Petal.Length), ])
nrow(IRIS_TABLE[is.na(IRIS_TABLE$Petal.Length), ])

# Or the other way round..
nrow(iris_temp[!is.na(iris_temp$Petal.Length),])
nrow(IRIS_TABLE[!is.na(IRIS_TABLE$Petal.Length), ])

#cleanups
rm(iris_temp)

