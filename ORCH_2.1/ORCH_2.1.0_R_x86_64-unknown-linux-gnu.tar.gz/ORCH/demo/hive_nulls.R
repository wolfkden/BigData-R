#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_nulls
#     Description: Demonstrates handling of nulls in HQL vs. NAs in R
#
#
#

## Set page width
options(width = 80)

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

#create a copy of the airquality dataset
airquality_temp <- airquality

# Push the airquality_temp data frame to HIVE
AIRQUALITY <- ore.push(airquality_temp)

# Display the class of AIRQUALITY 
class(AIRQUALITY)

# Let us see what the behavior of R is with NAs
# Return all observations where ozone < 30
# Compare with explicit exclusion of NAs
nrow(airquality_temp[airquality_temp$Ozone < 30,])

# Explicit exclusion of NAs
nrow(airquality_temp[airquality_temp$Ozone < 30 & !is.na(airquality_temp$Ozone),])

# Default behavior on HIVE tables is excluding NULLS in output
nrow(AIRQUALITY[AIRQUALITY$Ozone < 30,])

# If you want R's NA behavior then request for it explicitly..
options(ore.na.extract = TRUE)
nrow(AIRQUALITY[AIRQUALITY$Ozone < 30,])

#cleanups
rm(airquality_temp)
