#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_aggregate.R
#     Description: Demonstrates aggregations
#
#
#

## Set page width
options(width = 80)

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

#create a copy of the iris dataset
iris_temp <- iris

## ORCH-HIVE  does not support factors yet, convert the factor columns to 
## character
factfilt <- sapply(iris_temp, is.factor)
iris_temp[factfilt] <- data.frame(lapply(iris_temp[factfilt], as.character),
                                    stringsAsFactors = FALSE)

# Push the iris_temp data frame to HIVE
IRIS_TABLE <- ore.push(iris_temp)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Select count(Petal.Length) group by Species
x = aggregate(IRIS_TABLE$Petal.Length,
              by = list(Species = IRIS_TABLE$Species),
              FUN = length)
class(x)
x

# Repeat FUN = summary, mean, min, max, sd, median, IQR
aggregate(IRIS_TABLE$Petal.Length, by = list(Species = IRIS_TABLE$Species),
          FUN = summary)
aggregate(IRIS_TABLE$Petal.Length, by = list(Species = IRIS_TABLE$Species),
          FUN = mean)
aggregate(IRIS_TABLE$Petal.Length, by = list(Species = IRIS_TABLE$Species),
          FUN = min)
aggregate(IRIS_TABLE$Petal.Length, by = list(Species = IRIS_TABLE$Species),
          FUN = max)
aggregate(IRIS_TABLE$Petal.Length, by = list(Species = IRIS_TABLE$Species),
          FUN = sd)
aggregate(IRIS_TABLE$Petal.Length, by = list(Species = IRIS_TABLE$Species),
          FUN = median)
aggregate(IRIS_TABLE$Petal.Length, by = list(Species = IRIS_TABLE$Species),
          FUN = IQR)

# More than one grouping column
x = aggregate(IRIS_TABLE$Petal.Length,
              by = list(Species = IRIS_TABLE$Species,
                        width = IRIS_TABLE$Petal.Width),
              FUN = length)
x

# Basic R summary functionality
summary(iris_temp)
summary(IRIS_TABLE)

# colMeans (for numeric columns only)
colMeans(iris_temp[,1:4])
colMeans(IRIS_TABLE[,1:4])

#cleanups
rm(iris_temp)
