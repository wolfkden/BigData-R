#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: nmf_NMFinteg.R
#     Description: Demonstrates integration of orch.nmf with the 
#                  framework in the R NMF package.
#
#

# Create a directory for this demo and change to this directory
currdir <- hdfs.pwd()
currroot <- hdfs.root()
hdfs.setroot("/tmp")
demoname <- "nmf_NMFinteg"
newdir <- hdfs.mkdir(file.path(hdfs.pwd(), demoname), cd=TRUE)

# Load the NMF framework package
#
# For more details on the NMF package, please see
#        Renaud Gaujoux, Cathal Seoighe (2010).
#        A flexible R package for nonnegative matrix factorization.
#        BMC Bioinformatics 2010, 11:367,
#        http://www.biomedcentral.com/1471-2105/11/367
#
# This requires the following R packages to be installed
#    NMF
#    Biobase
#    BiocGenerics
#    RColorBrewer
#

if (!all(require(NMF), require(Biobase), require(BiocGenerics), 
         require(RColorBrewer)))
  stop ("This demo requires these packages: NMF, Biobase, BiocGenerics and RColorBrewer")

# Use the Golub dataset on leukemia that is part of the NMF package
data(esGolub)

# Use orch.nmf.NMFalgo as the (custom) NMF algorithm
resorch <- nmf(esGolub, rank=3, orch.nmf.NMFalgo, iterations=70, regularizer=155, randSeed=123, step=0.001, decay=0.9, init=1)
resorch
W <- basis(resorch)
H <- coef(resorch)

# Plot metaprofiles (coefficients)
metaHeatmap(resorch)

# Plot metagenes (Basis components)
metaHeatmap(resorch, what='features')

# Cleanup after the demo
hdfs.cd()
hdfs.rmdir(newdir, force=TRUE)
hdfs.setroot(currroot)
hdfs.cd(currdir)
