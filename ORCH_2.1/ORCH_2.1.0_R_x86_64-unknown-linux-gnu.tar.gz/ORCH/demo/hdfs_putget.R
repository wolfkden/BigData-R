#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hdfs_putget
#     Description: Demonstrates data transfer between R frame and HDFS 
#
#
#

## Set page width
options(width = 80)

# Rmove any pre-existing directories
hdfs.rm("cars_dfs")

# Put cars data set into HDFS directory named "cars_dfs"  
x <- hdfs.put(cars, dfs.name="cars_dfs")

# Attach the the cars_dfs directory into the R session
y <- hdfs.attach("cars_dfs")

# Get the data into R session from HDFS
hdfs.get(x)
hdfs.get(y)

# Remove one of the R objects (y) representing the HDFS data
hdfs.rm(y)

# The other R object representing the above HDFS object  
# should be non existent as well
hdfs.exists(x)

# Put iris data set into HDFS and use 'Sepal.Length' as the key
dfs.iris <- hdfs.put(iris, key='Sepal.Length')

# describe the metadata of the above HDFS object
hdfs.describe(dfs.iris)

# Sample a subset (20 rows) of data from HDFS
hdfs.sample(dfs.iris, n = 20)

# Remove the HDFS data
hdfs.rm(dfs.iris)
