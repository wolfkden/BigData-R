#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_binning.R
#     Description: Demonstrates binning logic in R
#
#
#

## Set page width
options(width = 80)

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

#create a copy of the iris dataset
iris_temp <- iris

## ORCH-HIVE  does not support factors yet, convert the factor columns to 
## character
factfilt <- sapply(iris_temp, is.factor)
iris_temp[factfilt] <- data.frame(lapply(iris_temp[factfilt], as.character),
                                    stringsAsFactors = FALSE)

# Push the iris_temp data frame to HIVE
IRIS_TABLE <- ore.push(iris_temp)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Create bins based on Petal Length
iris_temp$PetalBins = ifelse(iris_temp$Petal.Length < 2.0, "SMALL PETALS",
                 ifelse(iris_temp$Petal.Length < 4.0, "MEDIUM PETALS",
                 ifelse(iris_temp$Petal.Length < 6.0, "MEDIUM LARGE PETALS",
                        "LARGE PETALS")))

# Look at the BINS now
iris_temp

# Repeat on ore.frame
IRIS_TABLE$PetalBins = ifelse(IRIS_TABLE$Petal.Length < 2.0, "SMALL PETALS",
                       ifelse(IRIS_TABLE$Petal.Length < 4.0, "MEDIUM PETALS",
                       ifelse(IRIS_TABLE$Petal.Length < 6.0,
                              "MEDIUM LARGE PETALS", "LARGE PETALS")))

IRIS_TABLE

# Reusable binning logic - a.l.a FORMATs in SAS
PetalBins = function(x)
{
    ifelse(x < 2.0, "SMALL PETALS",
    ifelse(x < 4.0, "MEDIUM PETALS",
    ifelse(x < 6.0, "MEDIUM LARGE PETALS", "LARGE PETALS")))
}

PetalBins(IRIS_TABLE$Petal.Length)
PetalBins(iris_temp$Petal.Length)

#cleanups
rm(iris_temp)

