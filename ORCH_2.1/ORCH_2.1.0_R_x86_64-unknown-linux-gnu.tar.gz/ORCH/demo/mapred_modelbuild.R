#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: mapred_basic
#     Description: Demonstrates running a mapper and a reducer to do a 
#                  parallel model build and save plots in HDFS in parallel
#
#
#

## Set page width
options(width = 80)

##
# Parallel model building and graph generation example. The predicted values 
# and png graphs are written in HDFS, which are then accessed from R.
##

# Put the iris data set into HDFS
dfs <- hdfs.put(iris, key='Species')
res <- NULL

dfs.res <- try(hadoop.run(
    dfs,
    mapper = function(key, vals) {
        orch.keyvals(key, vals)
    },
    reducer = function(key, vals) {
        mod = lm(Petal.Length ~ Sepal.Length+Petal.Width, data=vals)
        fname <- paste("fit-",key,".png",sep="")
        png(fname)
        plot(mod)
        dev.off()
        hdfs.dir <- file.path(pngdir, as.character(key))
        dfs.id   <- hdfs.id(hdfs.dir, force=T)
        #remove pre-existing directories
        if(hdfs.exists(dfs.id)) {
          hdfs.rmdir(dfs.id)
        }
        dfs.id <- hdfs.mkdir(dfs.id)
        x <- hdfs.upload(
            filename = fname,
            dfs.name = dfs.id, 
            split.size = 0, 
            overwrite = TRUE, 
            attach = FALSE)
        pred <- predict(mod, vals)
        orch.keyval(NULL, orch.pack(predict=pred, pngfile=x[1]))
    },
    export = orch.export(pngdir="/tmp/pngfiles"),
    config = new("mapred.config",
        job.name = "model-plot",
        hdfs.access = TRUE)
), silent = TRUE )

# In case of an error, cleanup and exit
if (inherits(dfs.res,"try-error")) {
 hdfs.rm(dfs)
 stop("execution error")
}

res <- hdfs.get(dfs.res)
finalres = list()
for (i in 1:nrow(res)) {
    finalres[[i]] <- orch.unpack(res[i,])
}
print(finalres)
# create dfs id from the dir paths
y <- hdfs.id(finalres[[1]]$pngfile)
# copy from HDFS to local disk
z <- hdfs.download(y)
# needs png library installed for plotting
if(require(png)) {
   if(exists("rasterImage")) {
     plot(1:2, type='n')
     img <- readPNG(z)
     rasterImage(img, 1.0, 1.07, 1.95, 1.9)
   }
}

#cleanups
hdfs.rm(dfs.res)
hdfs.rm(dfs)
