#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: orch_neural
#     Description: Demonstrates running ORCH's neural network algorithm
#     for model building 
#                 
#
#
#

## Set page width
options(width = 80)

# Put the iris dataset into HDFS
myData      <- hdfs.put(iris)

# Create the formula 
myFormula   <- formula('Petal.Width ~ I(Sepal.Length^3) + (Sepal.Width + Petal.Length)^2')

# Fit the model using the above formula in ORCH Neural Network
myFit       <- try(orch.neural(myFormula, myData, hiddenSize = 2, maxit = 5), 
                   silent = TRUE)

# In case of an error, cleanup and exit
if (inherits(myFit,"try-error")) {
 hdfs.rm(myData)
 stop("execution error")
}

# Predict the value
pred        <- try(predict(myFit, newdata = myData), silent = TRUE)

# In case of an error, cleanup and exit
if (inherits(pred,"try-error")) {
 hdfs.rm(myData)
 stop("execution error")
}

# Look at a sample  of the predicted values
hdfs.sample(pred, n = 10)

# Clean up.
hdfs.rm(myData)
hdfs.rm(pred)
