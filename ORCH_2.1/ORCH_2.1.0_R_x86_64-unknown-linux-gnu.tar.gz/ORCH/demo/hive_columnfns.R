#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_columnfns.R
#     Description: Demonstrates use of column functions
#
#
#

## Set page width
options(width = 80)

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

#create a copy of the iris dataset
iris_temp <- iris

## ORCH-HIVE  does not support factors yet, convert the factor columns to 
## character
factfilt <- sapply(iris_temp, is.factor)
iris_temp[factfilt] <- data.frame(lapply(iris_temp[factfilt], as.character),
                                    stringsAsFactors = FALSE)

# Push the iris_temp data frame to HIVE
IRIS_TABLE <- ore.push(iris_temp)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Select distinct(Species) from iris_temp_table
unique(IRIS_TABLE$Species)

# Select function(column) from iris_temp_table
# where function is one of
# min, max, sd, mean, fivenum, var, IQR, quantile
# etc shown below
min(IRIS_TABLE$Petal.Length)
max(IRIS_TABLE$Petal.Length)
sd(IRIS_TABLE$Petal.Length)
mean(IRIS_TABLE$Petal.Length)
fivenum(IRIS_TABLE$Petal.Length)
var(IRIS_TABLE$Petal.Length)
IQR(IRIS_TABLE$Petal.Length)
quantile(IRIS_TABLE$Petal.Length)

log(IRIS_TABLE$Petal.Length)
log10(IRIS_TABLE$Petal.Length)
log2(IRIS_TABLE$Petal.Length)

abs(IRIS_TABLE$Petal.Length)
sqrt(IRIS_TABLE$Petal.Length)

exp(IRIS_TABLE$Petal.Length)
expm1(IRIS_TABLE$Petal.Length)
round(IRIS_TABLE$Petal.Length)

# Frequency counts
# First bin Petal.Length for readability
IRIS_TABLE$PLBINS = ifelse(IRIS_TABLE$Petal.Length < 2, "SMALL",
                    ifelse(IRIS_TABLE$Petal.Length < 4, "MEDIUM",
                           "LARGE"))
table(IRIS_TABLE$Species, IRIS_TABLE$PLBINS)

# String Functions
substr(IRIS_TABLE$Species, 1, 2)
tolower(IRIS_TABLE$Species)
toupper(IRIS_TABLE$Species)
x = gsub("s", "v", IRIS_TABLE$Species)
x

#cleanups
rm(iris_temp)

