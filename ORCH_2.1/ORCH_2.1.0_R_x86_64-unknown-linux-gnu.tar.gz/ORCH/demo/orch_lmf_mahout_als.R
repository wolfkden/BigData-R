#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: lmf_mahout-als.R
#     Description: Demonstrates the main APIs related to the 
#                  LMF model fit using the Mahout ALS algorithm,
#                  i.e. an "orch.mahout.lmf.als" model
#
#

# Create a directory for this demo and set that as root
currroot <- hdfs.root()
hdfs.setroot("/tmp")
demoname <- "lmf_mahout-als"
newdir <- hdfs.mkdir(file.path("/", demoname))
hdfs.setroot(newdir)

## Setup the input (user, item, rating) entries
u <- sample(1:100, 300, replace=TRUE)
i <- sample(1:10, 300, replace=TRUE)
ui <- unique(cbind(u,i))
r <- sample(1:5, nrow(ui), replace=TRUE)
input <- cbind(ui,r)

# For "mahout-als", set up an input file
inputFile <- ORCHcore:::.orch.tmpfile()
write.table(input, file=inputFile, sep=",", col.names=FALSE, row.names=FALSE)

# Fit using "mahout-als"
fit <- orch.lmf(inputFile, method="mahout-als", rank=3, iterations=5)
print(fit)

# Evaluate this "mahout-als" model 
se.fit <- orch.evaluate(fit, fit$inputDir)
se.fit
 
# Recommend top 2 items per user
orch.recommend(fit, n=2, maxRating=5)

# Cleanup after the demo
hdfs.setroot("/tmp")
hdfs.rmdir(newdir, force=TRUE)
hdfs.setroot(currroot)
