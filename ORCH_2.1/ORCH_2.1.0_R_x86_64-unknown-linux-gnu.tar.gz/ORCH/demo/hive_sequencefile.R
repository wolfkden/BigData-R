#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_sequencefile
#     Description: Demonstrates creating and using HIVE tables stored as
#                  sequencefiles
#
#
#

## Set page width
options(width = 80)

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

# Create a HIVE table from R's cars dataset
ore.create(cars, table="cars_tab")

# Print the column named 'speed' of the cars dataset 
cars$speed

# Print the column named 'speed' for the cars_tab HIVE table
cars_tab$speed

# Use ore.exec to execute an HIVE DDL which creates an HIVE table 
# from cars_tab but stored as sequencefile
ore.exec("create table cars_seq stored as sequencefile as select * from cars_tab") 

# Sync in the table created above
ore.sync(table="cars_seq")

# Print the column named 'speed' for the cars_seq HIVE table
cars_seq$speed

# Add one to the above column
cars_seq$speed + 1

# Drop the above HIVE tables
ore.drop(table=c("cars_tab", "cars_seq"))
