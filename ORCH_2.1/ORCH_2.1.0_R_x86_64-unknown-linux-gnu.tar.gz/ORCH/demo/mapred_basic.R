#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: mapred_basic
#     Description: Demonstrates running a mapper and a reducer containing 
#                  R script in ORCH.
#
#
#


##
# A simple example of how to operate with key-values. Input dataset - cars.
# Filter cars with with "dist" > 30 in mapper and get mean "dist" for each 
# "speed" in reducer.
##

## Set page width
options(width = 80)

# Put the cars dataset into HDFS
cars.dfs <- hdfs.put(cars, key='speed')

# Submit the hadoop job with mapper and reducer R scripts
x <- try(hadoop.run(
    cars.dfs,
    mapper = function(key, val) {
            orch.keyvals(key[val$dist > 30], val[val$dist > 30,])
    },
    reducer = function(key, vals) {
        X <- sum(vals$dist)/nrow(vals)
        orch.keyval(key, X)
    },
    config = new("mapred.config",
        map.tasks = 1,
        reduce.tasks = 1
    )
), silent = TRUE)

# In case of errors, cleanup and return
if (inherits(x,"try-error")) {
 hdfs.rm(cars.dfs)
 stop("execution error")
}
 
# Print the results of the mapreduce job
print(hdfs.get(x))

# Remove the HDFS files created above
hdfs.rm(cars.dfs)
hdfs.rm(x)

