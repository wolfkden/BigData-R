#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: orch_lm
#     Description: Demonstrates running ORCH's lm algorithm
#     for model building 
#                 
#
#
#

## Set page width
options(width = 80)

# Utility function to compare R's model with ORCH's model
relDiff <- function(o1, o2) {
    if (length(o1) != length(o2)) {
        stop('Objects are of different lengths')
    }

    for (i in seq_len(length(o1))) {
        diff <- abs(o1[i] - o2[i]) / (abs(o2[i]) + 1)
        if (diff > 1E-7) {
            s <- sprintf('Components [%d] differ %E %E \n', i, o1[i], o2[i])
            warning(s)
        }
    }
}

# Put iris data set into HDFS
myData      <- hdfs.put(cbind(id=seq_len(nrow(iris)),iris))

# Create the formula for model prediction
myFormula   <- formula('Petal.Width ~ I(Sepal.Length^3) + (Sepal.Width + Petal.Length)^2')

# Fit the model using iris data set and ORCH's lm algorithm
myFit       <- try(orch.lm(myFormula, myData, nReducers = 2), silent = TRUE)

# In case of an error, cleanup and exit
if (inherits(myFit,"try-error")) {
 hdfs.rm(myData)
 stop("execution error")
}

# Fit the model using R's native lm 
lmFit       <- lm(myFormula, iris)

# Compare orch.lm() and lm() coefficients.
relDiff(myFit$coefficients, lmFit$coefficients)

# Generate model predictions for orch.lm()
pred        <- try(predict.orch.lm(myFit, newdata = myData), silent = TRUE)

# In case of an error, cleanup and exit
if (inherits(pred,"try-error")) {
 hdfs.rm(myData)
 stop("execution error")
}

# Pull in the prediction values into R memory
myPred      <- hdfs.get(pred)

# Generate model predictions for R's lm()
lmPred      <- predict(lmFit, newdata = iris)

# Compare orch.lm() and lm() predictions
# use the id column to order the hdfs output and allign the row ordering 
# to the in memory model scores
relDiff(myPred[order(myPred$id), ncol(myPred)], lmPred)

# Clean up.
hdfs.rm(myData)
hdfs.rm(pred)

