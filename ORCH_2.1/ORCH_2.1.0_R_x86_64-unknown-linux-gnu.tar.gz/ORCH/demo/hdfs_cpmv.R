#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hdfs_cpmv
#     Description: Demonstrates HDFS file/directory contents copy and move
#
#
#

## Set page width
options(width = 80)

# Put the cars data set into HDFS
x <- hdfs.put(cars)

# Create a directory named 'xyz'
# This directory will be create under pwd given by hdfs.pwd()
hdfs.mkdir("xyz")

# Copy the HDFS data of the cars data set into xyz HDFS directory
hdfs.cp(x, "xyz")

# List the directory contents
hdfs.ls("xyz")

# Remove everything under xyz
hdfs.rm("xyz/*", force=TRUE)

# List the directory contents
hdfs.ls("xyz")

# Create a directory named 'abc'
hdfs.mkdir("abc") 

# Move the cars data into xyz
hdfs.mv(x, "xyz")

# Check existence of src HDFS directory
hdfs.exists(x)

# Move all contents of xyz into abc
hdfs.mv("xyz/*", "abc", force=TRUE)

# List contents of abc
hdfs.ls("abc")

# Remove the directories
hdfs.rmdir("xyz")
hdfs.rmdir("abc")

