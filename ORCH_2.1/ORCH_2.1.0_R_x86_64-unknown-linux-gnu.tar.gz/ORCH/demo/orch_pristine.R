#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: orch_pristine
#     Description: Demonstrates cleaning of HDFS data using ORCH.
#
#
#


##
# A few simple examples of how to 'clean' HDFS files. In this demo we generate 
# some dummy HDFS files with missing values (NAs) and use ORCH's data 
# cleaning capability to remove/substitute those missing values
##

## Set page width
options(width = 80)
# Create a data.frame with some missing values
df <- data.frame(x=c(1,2,3,4,5,6), y=c(1,2,3,NA,NA,6))

# Transfer the above data.frame into HDFS 
df.dfs <- hdfs.put(df)

# Clean the input by substituting the NAs with 0s (default value)
df.dfs.clean <- hdfs.cleanInput(df.dfs)

# Print the tranformed output
print(hdfs.get(df.dfs.clean))

# Remove the HDFS data
hdfs.rm(df.dfs.clean)

# Clean the input by removing the rows with missing values (NAs)
df.dfs.clean <- hdfs.cleanInput(df.dfs, replace = FALSE)

# Print the tranformed output
print(hdfs.get(df.dfs.clean))

# Remove the HDFS data
hdfs.rm(df.dfs.clean)

# Remove the input data from HDFS
hdfs.rm(df.dfs)

# Create a data.frame with numeric and character columns containing 
# missing values
df <- data.frame(x=c(1,NA,NA,4,5,6),
                 y=c("abc","def","efg",NA,NA,"xyz"), stringsAsFactors=FALSE)

# Transfer the above data.frame into HDFS 
df.dfs <- hdfs.put(df)

# Clean the input by substituting the numeric NAs with -1 and character NAs
# with "abc"
df.dfs.clean <- hdfs.cleanInput(df.dfs, 
                     replace_val = data.frame(numeric=-1, character="abc",
                                              stringsAsFactors=FALSE))

# Print the tranformed output
print(hdfs.get(df.dfs.clean))

# Cleanups
# Remove the HDFS data
hdfs.rm(df.dfs.clean)
hdfs.rm(df.dfs)
