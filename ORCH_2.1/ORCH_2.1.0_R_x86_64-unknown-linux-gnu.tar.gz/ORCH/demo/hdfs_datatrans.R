#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hdfs_datatrans
#     Description: Demonstrates data transfer between HDFS and localfile system
#                  and between HDFS and Oracle DB
#
#
#

## Set page width
options(width = 80)

## Demonstrate data transfer between HDFS and local file system

# Create a temp file on local disk in the tmp directory 
tmpf <- tempfile(tmpdir='/tmp')

# Write out the cars dataset into this file
write.csv(cars, row.names=FALSE, file=tmpf)

# Upload this file into HDFS
dfs.id <- hdfs.upload(tmpf, header=TRUE)

# Remove the local file
unlink(tmpf)

# Describe the HDFS object
hdfs.describe(dfs.id)

# See the size of the HDFS file
hdfs.size(dfs.id)

# Print out the HDFS object
hdfs.get(dfs.id)

# Copy the above HDFS file into local disc
tmpf <- hdfs.download(dfs.id)

# Read the local file into the R session
loc.obj <- read.csv(tmpf, header=FALSE)

# Remove the file
unlink(tmpf)

# Remove HDFS data
hdfs.rm(dfs.id)

# Print the R in memory object
print(loc.obj)

## Demonstrate data transfer between HDFS and ORACLE DB
## NOTE: you have to be connected to an ORACLE instance before running 
## this demo. See documentation for ore.connect and orch.connect

if (!orch.connected()||!ore.is.connected())
  stop("Needs ORE and ORCH DB connection for hdfs.push/pull")

# Create a temp file on local disk in the tmp directory 
tmpf <- tempfile(tmpdir='/tmp')

# Write out the cars dataset into this file
write.table(
        file = tmpf,
        x = cars,
        row.names = FALSE,
        col.names = FALSE,
        sep = ",")

# remove and pre-existig hdfs directory before upload
hdfs.rm("cars_dfs")

# upload the data from local file into HDFS into a direcotry named "cars_dfs"
# use key.sep = "," since the ORCH default key separator is '\t'
cars.dfs <- hdfs.upload(filename = tmpf, 
                 dfs.name = "cars_dfs", 
                 overwrite = TRUE, key.sep=",")

# Describe the HDFS data
hdfs.describe(cars.dfs)

# Drop any pre-existing database table called CARS_TAB
# Move the cars data in HDFS to the DB table called CARS_TAB using sqoop (default)
hdfs.pull(dfs.id = cars.dfs, db.name = "CARS_TAB")

# Check the class of returned ORACLE DB object
class(cars.frame1)

# Print the contents
cars.frame1

# Push the cars data from Oracle DB into HDFS using sqoop
cars.dfs.id1 <- hdfs.push(
                    x = CARS_TAB,
                    dfs.name = "cars_dfs1",
                    split.by = "VAL1",
                    overwrite = TRUE)

# Describe the moved data in HDFS
hdfs.describe(cars.dfs.id1)

# Display the HDFS data 
hdfs.get(cars.dfs.id1)

# Pull the HDFS data into ORACLE DB using Oracle Loader for Hadoop (OLH)
# into a table called CARS_TAB1
# You need OLH for this to work
cars.frame2 <- hdfs.pull(
                dfs.id = cars.dfs,
                db.name = "CARS_TAB1",
                driver = "olh")

# check the class of retruned ORACLE DB object
class(cars.frame2)

# Print the contents
cars.frame2

# Cleanups
# Remove the HDFS objects
hdfs.rm(cars.dfs.id1)
hdfs.rm(cars.dfs)

# Remove Oracle DB tables
ore.drop(table=c("CARS_TAB", "CARS_TAB1"))

