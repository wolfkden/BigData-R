#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hdfs_dir
#     Description: Demonstrates HDFS directory related APIs in ORCH
#
#
#

## Set page width
options(width = 80)

# Check the present working directory
hdfs.pwd()

# Create a HDFS directory named 'xyz' 
hdfs.mkdir("xyz")

# Change directory into xyz
hdfs.cd("xyz")

# Create a HDFS directory named 'xxx' inside 'xyz' 
hdfs.mkdir("xxx")

# Change directory into xxx
hdfs.cd("xxx")

# List contents of the current directory (should be empty)
hdfs.ls()

# Go to the parent directory
hdfs.cd('..')

# List contents of the current directory
hdfs.ls()

# Go to the parent directory
hdfs.cd('..')

# Change directory using absolute path
hdfs.cd(file.path(hdfs.pwd(),'/xyz/xxx'))

# Change directory to the HDFS directory 'xyz'
hdfs.cd('..')

# try removing all the contents of xyz
hdfs.rmdir('*')

# List contents of the current directory
hdfs.ls()

# Use force to do the above (no prompt)
hdfs.rmdir('*', force=TRUE)

# Switch one directory above 'xyz'
hdfs.cd('..')

# save present working directory
savepwd <- hdfs.pwd()

# Change directory to hdfs root ('/')
hdfs.cd()

# Remove xyz using absolute path
try(hdfs.rmdir(file.path(savepwd,"xyz")), silent = TRUE)

# Restore the pwd()
hdfs.cd(savepwd)
