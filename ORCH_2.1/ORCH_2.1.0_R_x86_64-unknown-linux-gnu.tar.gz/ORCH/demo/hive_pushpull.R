#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_pushpull.R
#     Description: Demonstrates collaborative processing between
#                  HIVE and client R desktop

## Set page width
options(width = 80)

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

#create a copy of the iris dataset
iris_temp <- iris

## ORCH-HIVE  does not support factors yet, convert the factor columns to 
## character
factfilt <- sapply(iris_temp, is.factor)
iris_temp[factfilt] <- data.frame(lapply(iris_temp[factfilt], as.character),
                                    stringsAsFactors = FALSE)

# Push iris_temp data frame to HIVE
IRIS_TABLE <- ore.push(iris_temp)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Performing pre-processing, derivation of new columns,
# binning, aggregations etc  in HIVE
#
# For the example, we'll simply filter just one Species
IRIS_TABLE = IRIS_TABLE[IRIS_TABLE$Species == "setosa", ]

# Pull filtered rows to desktop R client memory
inmem_df = ore.pull(IRIS_TABLE)
class(inmem_df)

# Apply R's own lm on inmem_df
# Alternatively you may imagine using any CRAN package whose functionality
# is not supported by the HIVE on inmem_df
r_model = lm(Petal.Length ~ Petal.Width, inmem_df)
r_model

df = data.frame(residuals = residuals(r_model))

# Push df back to HIVE
RESIDUALS <- ore.push(df)
RESIDUALS

#cleanups
rm(iris_temp)

