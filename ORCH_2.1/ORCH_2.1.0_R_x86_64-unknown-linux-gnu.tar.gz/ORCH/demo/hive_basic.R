#
#     ORACLE R CONNECTOR FOR HADOOP DEMOS
#
#     Name: hive_basic.R
#     Description: Demonstrates basic connectivity to HIVE
#
#
#

## Set page width
options(width = 80)
options(error = expression(NULL))

# Connect to HIVE
ore.connect(type="HIVE")
# Attach the current envt. into search path of R
ore.attach()

#create a copy of the iris dataset
iris_temp <- iris

## ORCH-HIVE  does not support factors yet, convert the factor columns to 
## character
factfilt <- sapply(iris_temp, is.factor)
iris_temp[factfilt] <- data.frame(lapply(iris_temp[factfilt], as.character),
                                    stringsAsFactors = FALSE)
# Push the iris_temp data frame to HIVE
IRIS_TABLE <- ore.push(iris_temp)

# Display the class of IRIS_TABLE 
class(IRIS_TABLE)

# Basic commands

# Number of rows
nrow(iris_temp)
nrow(IRIS_TABLE)

# Column names of the data frame
names(iris_temp)
names(IRIS_TABLE)

# Number of columns of the data frame
length(iris_temp)
length(IRIS_TABLE)

# Head
head(iris_temp, n = 5)
head(IRIS_TABLE, n = 5)

# Vectors
class(iris_temp$Sepal.Length)
class(IRIS_TABLE$Sepal.Length)

class(iris_temp$Species)
class(IRIS_TABLE$Species)

# is variants
is.character(iris_temp$Species)
is.character(IRIS_TABLE$Species)
is.ore.character(IRIS_TABLE$Species)

# Number of characters in each column value
nchar(iris_temp$Species)
nchar(IRIS_TABLE$Species)

# HIVE does not support factors yet
as.factor(IRIS_TABLE$Species)

#cleanups
rm(iris_temp)

